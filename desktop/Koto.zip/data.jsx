/* global React */
// data.jsx — Koto mock data (RU)

// fake koto IDs (session-style: 05 + 64 hex chars)
const KOTO_CONTACTS = [
  { id: 'alina',  name: 'Алина Ким',       initials: 'АК', color: '#ff6b35', kotoId: '05a9f2c4e7b1d038f5c26e9a48103b5d7c91e2d64a58fc03bd917e4a62c85b71f0', phone: 'Koto ID', status: 'была в сети недавно' },
  { id: 'maks',   name: 'Максим Орлов',    initials: 'МО', color: '#7c5cff', kotoId: '05b74e8c09d1a2f36b59ac8f14d728503fc6e1b095a3d48f27eb906c1f8d542a37', phone: 'Koto ID', status: 'в сети' },
  { id: 'team',   name: 'Команда Koto',    initials: 'КК', color: '#00a676', kotoId: '05c18f3d72b49e5ac014826df5913a8b2e7c05149d36f8b2a07ec4d51f83627ab9', phone: 'группа · 8 участников', status: '3 онлайн' },
  { id: 'olya',   name: 'Оля Громова',     initials: 'ОГ', color: '#f0b400', kotoId: '05d4e8f29a0b315cf86147b2d50e93ca74812b936ef0a5d7c2148f36b9a0e5c28d', phone: 'Koto ID', status: 'была вчера' },
  { id: 'mama',   name: 'Мама',            initials: 'М',  color: '#e74c6f', kotoId: '05e0a3f87b62c41d5e98037af1b62d04e85c91f23a6bd8043e7c90f58a16d2c7b4', phone: 'Koto ID', status: 'в сети' },
  { id: 'nikita', name: 'Никита Вельт',    initials: 'НВ', color: '#3276ff', kotoId: '05f23b58a17d6e09c4e2f80b15a63d9e72c48b10f96ac3d74e58b20af19d63c8e04', phone: 'Koto ID', status: 'был в 15:24' },
  { id: 'lera',   name: 'Лера Станкевич',  initials: 'ЛС', color: '#13b3a5', kotoId: '0516acf3d872b04e15f9c38a67b2d051fc9e3a8b274d06f51e29ac38b475e16f2d9', phone: 'Koto ID', status: 'была в 12:10' },
  { id: 'pavel',  name: 'Павел Зотов',     initials: 'ПЗ', color: '#ff7a9a', kotoId: '0527d19fe3b48a5c62e901f7a3b8d46105ce2f98a6b3d4017e28f5c10b749e3d6a', phone: 'Koto ID', status: 'был вчера' },
  { id: 'doma',   name: 'Дом · чат 4',     initials: 'ДЧ', color: '#5b6ef5', kotoId: '0538e2ca71f9b0643d58e71ac2f930b41e72d6f09a3cb148f57e01c92a7b503db2', phone: 'группа · 4 участника', status: '' },
];

const KOTO_CHATS = [
  {
    id: 'alina', contactId: 'alina', time: '16:42', unread: 2, pinned: true, muted: false,
    preview: 'ок, тогда встречаемся у Koto 🐈',
    typing: false, lastSelf: false,
  },
  {
    id: 'maks', contactId: 'maks', time: '16:08', unread: 0, pinned: true, muted: false,
    preview: 'Вы: отправил проект на ревью',
    typing: false, lastSelf: true, status: 'read',
  },
  {
    id: 'team', contactId: 'team', time: '15:47', unread: 11, pinned: false, muted: true,
    preview: 'Максим: релиз сдвигается на четверг',
    typing: false, lastSelf: false,
  },
  {
    id: 'olya', contactId: 'olya', time: '14:20', unread: 0, pinned: false, muted: false,
    preview: 'печатает…',
    typing: true, lastSelf: false,
  },
  {
    id: 'mama', contactId: 'mama', time: '13:02', unread: 0, pinned: false, muted: false,
    preview: 'Вы: позвоню вечером',
    typing: false, lastSelf: true, status: 'delivered',
  },
  {
    id: 'nikita', contactId: 'nikita', time: 'вчера', unread: 0, pinned: false, muted: false,
    preview: 'спс, получил',
    typing: false, lastSelf: false,
  },
  {
    id: 'lera', contactId: 'lera', time: 'вчера', unread: 0, pinned: false, muted: false,
    preview: 'Вы: 📷 Фото',
    typing: false, lastSelf: true, status: 'read',
  },
  {
    id: 'pavel', contactId: 'pavel', time: 'пн', unread: 0, pinned: false, muted: true,
    preview: 'Исчезающее сообщение',
    typing: false, lastSelf: false, ephemeral: true,
  },
  {
    id: 'doma', contactId: 'doma', time: 'вс', unread: 0, pinned: false, muted: false,
    preview: 'Оля: забрала ключи',
    typing: false, lastSelf: false,
  },
];

// Conversation seed per chat
const KOTO_MESSAGES = {
  alina: [
    { id: 'm1', self: false, text: 'привет! как день?', time: '16:38' },
    { id: 'm2', self: true, text: 'всё ок, заканчиваю дизайн Koto. скинуть?', time: '16:39', status: 'read' },
    { id: 'm3', self: false, text: 'скидывай конечно', time: '16:40', reactions: ['🔥'] },
    { id: 'm4', self: true, text: 'смотри, пузыри, таймеры, всё как хотели', time: '16:41', status: 'read' },
    { id: 'm5', self: false, text: 'ок, тогда встречаемся у Koto 🐈', time: '16:42', firstOfGroup: true },
    { id: 'm6', self: false, text: 'я буду в 19', time: '16:42' },
  ],
  maks: [
    { id: 'mm1', self: false, text: 'ревью завтра?', time: '15:50' },
    { id: 'mm2', self: true, text: 'да, в 11 по мск', time: '15:52', status: 'read' },
    { id: 'mm3', self: true, text: 'отправил проект на ревью', time: '16:08', status: 'read' },
  ],
  team: [
    { id: 't1', self: false, author: 'Оля', authorColor: '#f0b400', text: 'когда релиз?', time: '15:40' },
    { id: 't2', self: false, author: 'Максим', authorColor: '#7c5cff', text: 'релиз сдвигается на четверг', time: '15:47' },
  ],
  olya: [
    { id: 'o1', self: true, text: 'купила билеты', time: '14:18', status: 'delivered' },
    { id: 'o2', self: false, typing: true, time: '14:20' },
  ],
  mama: [
    { id: 'ma1', self: false, text: 'как там?', time: '12:50' },
    { id: 'ma2', self: true, text: 'позвоню вечером', time: '13:02', status: 'delivered' },
  ],
  pavel: [
    { id: 'p1', self: false, text: 'секретные данные', time: '10:04', ephemeral: true, ephemeralPct: 0.35 },
    { id: 'p2', self: true, text: 'принял, удаляю', time: '10:05', status: 'read', ephemeral: true, ephemeralPct: 0.7 },
  ],
  default: [
    { id: 'd1', self: false, text: 'привет', time: '12:00' },
  ],
};

window.KOTO_CONTACTS = KOTO_CONTACTS;
window.KOTO_CHATS = KOTO_CHATS;
window.KOTO_MESSAGES = KOTO_MESSAGES;
window.getContact = (id) => KOTO_CONTACTS.find(c => c.id === id) || KOTO_CONTACTS[0];
