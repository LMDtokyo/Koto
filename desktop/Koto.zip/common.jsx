/* global React */
// common.jsx — Koto shared components: frame, avatar, bubble parts, typing, status

const { useState, useEffect, useRef, useMemo, useCallback } = React;

// ─── Device frame (custom, tighter than starter) ─────────────
function KotoFrame({ dark, children }) {
  return (
    <div style={{
      width: 402, height: 874, borderRadius: 55.5,
      position: 'relative', overflow: 'hidden',
      background: dark ? '#0b0b0c' : '#ffffff',
      boxShadow: `
        0 0 0 2px #1a1a1c,
        0 0 0 10px #2a2a2e,
        0 40px 80px -20px rgba(0,0,0,0.45),
        0 80px 120px -40px rgba(0,0,0,0.25)
      `,
      fontFamily: '-apple-system, BlinkMacSystemFont, "SF Pro Display", system-ui',
      color: dark ? '#fff' : '#0a0a0a',
    }}>
      {/* dynamic island */}
      <div style={{
        position: 'absolute', top: 11, left: '50%', transform: 'translateX(-50%)',
        width: 124, height: 36, borderRadius: 22, background: '#000', zIndex: 200,
      }} />
      {/* status bar */}
      <KotoStatusBar dark={dark} />
      {/* content slot */}
      <div style={{ position: 'absolute', inset: 0 }}>
        {children}
      </div>
      {/* home indicator */}
      <div style={{
        position: 'absolute', bottom: 8, left: '50%', transform: 'translateX(-50%)',
        width: 140, height: 5, borderRadius: 3,
        background: dark ? 'rgba(255,255,255,0.5)' : 'rgba(0,0,0,0.35)',
        zIndex: 300, pointerEvents: 'none',
      }} />
    </div>
  );
}

function KotoStatusBar({ dark }) {
  const c = dark ? '#fff' : '#000';
  return (
    <div style={{
      position: 'absolute', top: 0, left: 0, right: 0, zIndex: 150,
      height: 59, padding: '20px 32px 0',
      display: 'flex', justifyContent: 'space-between', alignItems: 'center',
      pointerEvents: 'none',
    }} className="no-select">
      <div style={{ fontSize: 17, fontWeight: 600, letterSpacing: -0.3, color: c, fontFamily: '-apple-system' }}>9:41</div>
      <div style={{ width: 124 }} />
      <div style={{ display: 'flex', gap: 6, alignItems: 'center' }}>
        <svg width="18" height="11" viewBox="0 0 18 11">
          <rect x="0" y="7" width="3" height="4" rx="0.6" fill={c}/>
          <rect x="4.5" y="5" width="3" height="6" rx="0.6" fill={c}/>
          <rect x="9" y="2.5" width="3" height="8.5" rx="0.6" fill={c}/>
          <rect x="13.5" y="0" width="3" height="11" rx="0.6" fill={c}/>
        </svg>
        <svg width="16" height="11" viewBox="0 0 17 12">
          <path d="M8.5 3.2C10.8 3.2 12.9 4.1 14.4 5.6L15.5 4.5C13.7 2.7 11.2 1.5 8.5 1.5C5.8 1.5 3.3 2.7 1.5 4.5L2.6 5.6C4.1 4.1 6.2 3.2 8.5 3.2Z" fill={c}/>
          <path d="M8.5 6.8C9.9 6.8 11.1 7.3 12 8.2L13.1 7.1C11.8 5.9 10.2 5.1 8.5 5.1C6.8 5.1 5.2 5.9 3.9 7.1L5 8.2C5.9 7.3 7.1 6.8 8.5 6.8Z" fill={c}/>
          <circle cx="8.5" cy="10.5" r="1.3" fill={c}/>
        </svg>
        <svg width="25" height="12" viewBox="0 0 27 13">
          <rect x="0.5" y="0.5" width="23" height="12" rx="3.5" stroke={c} strokeOpacity="0.35" fill="none"/>
          <rect x="2" y="2" width="17" height="9" rx="1.8" fill={c}/>
          <path d="M25 4.5V8.5C25.8 8.2 26.5 7.2 26.5 6.5C26.5 5.8 25.8 4.8 25 4.5Z" fill={c} fillOpacity="0.4"/>
        </svg>
      </div>
    </div>
  );
}

// ─── Avatar ──────────────────────────────────────────────────
function Avatar({ contact, size = 48, online, pulse }) {
  if (!contact) return null;
  const fontSize = size * 0.4;
  return (
    <div style={{ position: 'relative', width: size, height: size, flexShrink: 0 }}>
      <div
        className={pulse ? '' : ''}
        style={{
          width: size, height: size, borderRadius: '50%',
          background: `linear-gradient(135deg, ${contact.color} 0%, ${shade(contact.color, -18)} 100%)`,
          color: '#fff', display: 'flex', alignItems: 'center', justifyContent: 'center',
          fontWeight: 600, fontSize, letterSpacing: -0.5,
          animation: pulse ? 'pulseAvatar 2s infinite' : 'none',
        }}
      >
        {contact.initials}
      </div>
      {online && (
        <div style={{
          position: 'absolute', right: 0, bottom: 0,
          width: size * 0.28, height: size * 0.28, borderRadius: '50%',
          background: '#34c759', border: '2px solid var(--frame-bg)',
          boxShadow: '0 0 0 2px #fff',
        }} />
      )}
    </div>
  );
}

function shade(hex, pct) {
  const n = parseInt(hex.slice(1), 16);
  let r = (n >> 16) & 0xff, g = (n >> 8) & 0xff, b = n & 0xff;
  const f = pct < 0 ? 0 : 255;
  const p = Math.abs(pct) / 100;
  r = Math.round((f - r) * p + r); g = Math.round((f - g) * p + g); b = Math.round((f - b) * p + b);
  return `#${((1 << 24) + (r << 16) + (g << 8) + b).toString(16).slice(1)}`;
}

// ─── Delivery status icon ────────────────────────────────────
function Status({ status, dark, accent }) {
  const color = status === 'read' ? '#fff' : (dark ? 'rgba(255,255,255,0.55)' : 'rgba(255,255,255,0.75)');
  if (status === 'sending') {
    return <Ico.Clock size={13} color={color} />;
  }
  if (status === 'sent') {
    return <Ico.Check size={13} color={color} />;
  }
  // delivered / read -> double check; read is brighter
  return (
    <svg width="16" height="10" viewBox="0 0 16 10" fill="none">
      <path d="M1 5.5l2.5 2.5L8 3.5" stroke={color} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
      <path d="M6 8l1.5-1.5M8 6.5L14.5 0" stroke={color} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
  );
}

// ─── Typing dots ─────────────────────────────────────────────
function TypingDots({ color = 'var(--accent)', size = 5 }) {
  return (
    <span style={{ display: 'inline-flex', gap: 3, alignItems: 'flex-end', height: size + 4 }}>
      {[0, 1, 2].map(i => (
        <span key={i} style={{
          width: size, height: size, borderRadius: '50%',
          background: color, display: 'inline-block',
          animation: `dot 1.2s infinite ${i * 0.18}s`,
        }} />
      ))}
    </span>
  );
}

// ─── Ephemeral timer ring ────────────────────────────────────
function EphemeralRing({ pct = 0.5, size = 14, color }) {
  const r = (size - 2) / 2;
  const c = 2 * Math.PI * r;
  return (
    <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`} style={{ transform: 'rotate(-90deg)' }}>
      <circle cx={size/2} cy={size/2} r={r} stroke={color} strokeOpacity="0.25" strokeWidth="1.5" fill="none"/>
      <circle cx={size/2} cy={size/2} r={r} stroke={color} strokeWidth="1.5" fill="none"
        strokeDasharray={c} strokeDashoffset={c * (1 - pct)} strokeLinecap="round"/>
    </svg>
  );
}

window.KotoFrame = KotoFrame;
window.KotoStatusBar = KotoStatusBar;
window.Avatar = Avatar;
window.Status = Status;
window.TypingDots = TypingDots;
window.EphemeralRing = EphemeralRing;
window.shade = shade;
