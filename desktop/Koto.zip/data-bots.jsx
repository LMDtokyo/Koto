/* global React, KOTO_CONTACTS, KOTO_CHATS, KOTO_MESSAGES */
// data-bots.jsx — bot directory, conversations, web-apps

const KOTO_BOTS = [
  {
    id: 'pawket',
    name: 'Pawket',
    handle: '@pawket',
    initials: '🐾',
    color: '#ff6b35',
    glyph: 'paw',
    tagline: 'Кот-ассистент с ИИ. Заметки, погода, валюта, напоминания.',
    description: 'Pawket живёт у вас в кармане. Спросите голосом или текстом — ответит, найдёт, запомнит. Подключён к Claude Haiku.',
    category: 'AI · ассистенты',
    users: '128k',
    verified: true,
    canMessage: true,
    creator: 'Koto Foundation',
    builtin: true,
    webApp: { id: 'pawket-board', name: 'Доска', icon: 'board' },
    commands: [
      { c: '/weather', d: 'прогноз погоды' },
      { c: '/rates',   d: 'курсы валют' },
      { c: '/note',    d: 'сохранить заметку' },
      { c: '/remind',  d: 'напомнить о деле' },
      { c: '/ask',     d: 'спросить ИИ' },
    ],
  },
  {
    id: 'kassa',
    name: 'Касса',
    handle: '@kassa',
    initials: 'КС',
    color: '#7c5cff',
    glyph: 'ticket',
    tagline: 'Билеты на концерты, кино, спорт. Оплата за 2 тапа.',
    description: 'Найдите билет, выберите место, оплатите внутри Koto. Ваши билеты появятся в Кошельке.',
    category: 'Покупки',
    users: '54k',
    verified: true,
    canMessage: true,
    creator: 'Касса',
    builtin: true,
    webApp: { id: 'kassa-shop', name: 'Магазин', icon: 'ticket' },
    commands: [
      { c: '/concerts', d: 'концерты' },
      { c: '/movies',   d: 'кино' },
      { c: '/sport',    d: 'спорт' },
      { c: '/theatre',  d: 'театр' },
      { c: '/tickets',  d: 'мои билеты' },
    ],
  },
  {
    id: 'meow-quiz',
    name: 'Meow Quiz',
    handle: '@meow_quiz',
    initials: 'МQ',
    color: '#34c759',
    glyph: 'controller',
    tagline: 'Викторина прямо в чате. Бросьте вызов друзьям.',
    category: 'Игры',
    users: '12k',
    verified: false,
    canMessage: true,
    commands: [
      { c: '/start',  d: 'начать раунд' },
      { c: '/topics', d: 'выбрать темы' },
      { c: '/score',  d: 'рейтинг' },
    ],
  },
  {
    id: 'botforge',
    name: 'BotForge',
    handle: '@botforge',
    initials: 'BF',
    color: '#0a84ff',
    glyph: 'bolt',
    tagline: 'Создавайте и настраивайте ботов для Koto.',
    description: 'BotForge — сервис для разработчиков. Создавайте ботов, получайте токены, настраивайте команды и аватары.',
    category: 'Разработка',
    users: '218k',
    verified: true,
    canMessage: true,
    creator: 'Koto Foundation',
    builtin: true,
    commands: [
      { c: '/newbot',         d: 'создать нового бота' },
      { c: '/mybots',         d: 'мои боты' },
      { c: '/setname',        d: 'изменить имя' },
      { c: '/setdescription', d: 'изменить описание' },
      { c: '/setuserpic',     d: 'изменить аватар' },
      { c: '/token',          d: 'показать токен' },
      { c: '/deletebot',      d: 'удалить бота' },
      { c: '/help',           d: 'справка' },
    ],
  },
  {
    id: 'rates',
    name: 'Курсы валют',
    handle: '@rates',
    initials: '$₽',
    color: '#3276ff',
    glyph: 'chart',
    tagline: 'USD/EUR/CNY/RUB и крипта. Алерты и графики.',
    category: 'Финансы',
    users: '40k',
    verified: true,
    canMessage: true,
    commands: [
      { c: '/rates',  d: 'курсы ЦБ' },
      { c: '/crypto', d: 'крипта' },
      { c: '/alert',  d: 'создать алерт' },
      { c: '/chart',  d: 'график' },
    ],
  },
];

// Chat rows for bots (folded into chat list)
const KOTO_BOT_CHATS = [
  { id:'pawket', contactId:'pawket', isBot:true, time:'17:14', unread:0, pinned:false, muted:false, preview:'Pawket: ☀️ +14° • дождь к вечеру', typing:false, lastSelf:false },
  { id:'botforge', contactId:'botforge', isBot:true, time:'вчера', unread:0, pinned:false, muted:false, preview:'BotForge: Здравствуйте! Я помогу вам создать новых ботов…', typing:false, lastSelf:false },
];

// Initial seed conversations with bots
const KOTO_BOT_MESSAGES = {
  pawket: [
    { id:'pw0', self:false, isBotIntro:true, botId:'pawket', text:'Привет! Я Pawket — карманный кот-ассистент.\n\nПопробуй:', time:'09:00',
      buttons: [
        [{ label:'☀️  Погода', cmd:'/weather' }, { label:'💱 Курсы', cmd:'/rates' }],
        [{ label:'🗒  Заметка', cmd:'/note' }, { label:'⏰ Напомнить', cmd:'/remind' }],
        [{ label:'🧠 Открыть доску', webapp:'pawket-board' }],
      ]
    },
    { id:'pw1', self:true, text:'/weather', time:'09:14', status:'read' },
    { id:'pw2', self:false, botId:'pawket', card:{ kind:'weather', city:'Москва', temp:'+14°', cond:'☁️ облачно с прояснениями', hi:'+16°', lo:'+8°', hourly:[10,12,14,15,14,13,11,10] }, time:'09:14',
      buttons: [[{ label:'На неделю', cmd:'/weather week' }, { label:'Сменить город', cmd:'/city' }]] },
  ],
  kassa: [
    { id:'ka0', self:false, isBotIntro:true, botId:'kassa', text:'Здравствуйте! 🎫 Что ищете?', time:'12:00',
      buttons: [
        [{ label:'🎵 Концерты', cmd:'/concerts' }, { label:'🎬 Кино', cmd:'/movies' }],
        [{ label:'⚽ Спорт', cmd:'/sport' }, { label:'🎭 Театр', cmd:'/theatre' }],
        [{ label:'🛒 Открыть магазин', webapp:'kassa-shop', primary:true }],
      ]
    },
  ],
  'meow-quiz': [
    { id:'mq0', self:false, isBotIntro:true, botId:'meow-quiz', text:'Готовы к раунду? Тема — кино 90-х.', time:'18:30',
      buttons: [[{ label:'▶️ Старт', cmd:'/start' }, { label:'⚙️ Темы', cmd:'/topics' }]] },
  ],
  rates: [
    { id:'rt0', self:false, isBotIntro:true, botId:'rates', text:'Курсы на сегодня:', time:'09:00',
      buttons: [[{ label:'Алерт USD', cmd:'/alert usd' }, { label:'График', cmd:'/chart' }]] },
  ],
  botforge: [
    { id:'bf0', self:false, isBotIntro:true, botId:'botforge',
      text:'Здравствуйте! Я BotForge — помогу вам создать новых ботов и управлять существующими.\n\nВот, что я умею:\n\n/newbot — создать нового бота\n/mybots — мои боты\n/setname — имя бота\n/setdescription — описание\n/token — API-токен\n/help — справка',
      time:'вчера',
      buttons: [
        [{ label:'➕ /newbot', cmd:'/newbot', primary:true }, { label:'📋 /mybots', cmd:'/mybots' }],
        [{ label:'❓ /help', cmd:'/help' }],
      ]
    },
  ],
};

// Pawket "board" data — mini-app dashboard items
const PAWKET_BOARD = {
  notes: [
    { id:'n1', emoji:'🐾', title:'Купить корм',  body:'Whiskas, 1.5 кг + лоток' },
    { id:'n2', emoji:'📚', title:'Книги Q4',     body:'Snow Crash, Дзен'        },
    { id:'n3', emoji:'🎂', title:'ДР Алины',     body:'14 декабря · подарок'    },
  ],
  reminders: [
    { id:'r1', text:'Позвонить маме',     when:'сегодня · 19:00', dot:'#ff6b35' },
    { id:'r2', text:'Заплатить за интернет', when:'завтра · 12:00', dot:'#7c5cff' },
    { id:'r3', text:'Тренировка',         when:'пт · 18:30',     dot:'#34c759' },
  ],
  habits: [
    { id:'h1', name:'Вода 2л', streak: 7, week:[1,1,1,1,1,1,1] },
    { id:'h2', name:'Чтение 30м', streak: 3, week:[0,1,1,1,0,1,1] },
    { id:'h3', name:'Без сахара', streak: 12, week:[1,1,1,1,1,1,1] },
  ],
};

// Kassa events
const KASSA_EVENTS = [
  { id:'k1', kind:'Концерт', title:'Молчат Дома',     date:'5 декабря',  time:'20:00', venue:'Adrenaline',     city:'Москва',  price:3500, hot:true,  cover:'#1a1a2e' },
  { id:'k2', kind:'Стендап', title:'Comedy Club Live', date:'7 декабря',  time:'21:00', venue:'House of Comedy', city:'Москва',  price:1800, cover:'#2a1a1a' },
  { id:'k3', kind:'Кино',    title:'Дюна 3',           date:'8 декабря',  time:'19:30', venue:'Каро 11',         city:'Москва',  price:600,  cover:'#1a2a3a' },
  { id:'k4', kind:'Театр',   title:'Мастер и Маргарита', date:'10 декабря', time:'19:00', venue:'МХТ Чехова',     city:'Москва',  price:2400, cover:'#2a1a2a' },
  { id:'k5', kind:'Футбол',  title:'Спартак — ЦСКА',   date:'12 декабря', time:'18:30', venue:'Лукойл-арена',    city:'Москва',  price:2200, hot:true, cover:'#1a3a1a' },
];

window.KOTO_BOTS = KOTO_BOTS;
window.KOTO_BOT_CHATS = KOTO_BOT_CHATS;
window.KOTO_BOT_MESSAGES = KOTO_BOT_MESSAGES;
window.PAWKET_BOARD = PAWKET_BOARD;
window.KASSA_EVENTS = KASSA_EVENTS;
window.getBot = (id) => KOTO_BOTS.find(b => b.id === id);

// Augment data exposed earlier — chats list will fold bots into top
if (window.KOTO_CHATS && window.KOTO_BOT_CHATS) {
  window.KOTO_CHATS_WITH_BOTS = [...window.KOTO_BOT_CHATS, ...window.KOTO_CHATS];
}
// Mirror getContact to also resolve bots
const _origGetContact = window.getContact;
window.getContact = (id) => {
  const bot = KOTO_BOTS.find(b => b.id === id);
  if (bot) return { ...bot, isBot:true, status: bot.tagline, phone: bot.handle };
  return _origGetContact(id);
};
// Mirror messages
const _origMsgs = window.KOTO_MESSAGES;
window.KOTO_MESSAGES = new Proxy(_origMsgs, {
  get(t, k) {
    if (KOTO_BOT_MESSAGES[k]) return KOTO_BOT_MESSAGES[k];
    return t[k];
  }
});
