/* global React, Ico, Avatar, TypingDots, Status, EphemeralRing, KOTO_CHATS, KOTO_BOT_CHATS, getContact, VerifiedTick */
// ChatList.jsx — list + Archive screen + SwipeRow (left/right actions, Signal/Mail style)

function BotGlyph({ size = 20, color = '#0a0a0a' }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none">
      <rect x="4" y="7" width="16" height="12" rx="3" stroke={color} strokeWidth="1.7"/>
      <circle cx="9" cy="13" r="1.4" fill={color}/>
      <circle cx="15" cy="13" r="1.4" fill={color}/>
      <path d="M12 4v3M9 4h6" stroke={color} strokeWidth="1.7" strokeLinecap="round"/>
      <path d="M2 12v4M22 12v4" stroke={color} strokeWidth="1.7" strokeLinecap="round"/>
    </svg>
  );
}

const { useState: useStateCL, useRef: useRefCL, useEffect: useEffectCL } = React;

// ─────────── ChatListScreen ───────────
function ChatListScreen({
  dark, onOpenChat, onOpenSettings, onOpenNewChat, onOpenStories, onOpenCamera, onOpenBots,
  onOpenArchive, density = 72,
  // lifted state from parent so Archive screen stays in sync
  archived, setArchived, muted, setMuted, pinned, setPinned, readOverrides, setReadOverrides,
}) {
  const bg = dark ? '#0b0b0c' : '#ffffff';
  const surface = dark ? '#1a1a1c' : '#f2f2f2';
  const text = dark ? '#fff' : '#0a0a0a';
  const sec = dark ? '#9e9e9e' : '#707070';
  const sep = dark ? 'rgba(255,255,255,0.06)' : 'rgba(0,0,0,0.05)';

  const [tab, setTab] = useStateCL('all');
  const [query, setQuery] = useStateCL('');
  const [openRow, setOpenRow] = useStateCL(null); // id of row currently showing action tray

  const adjustedChats = [...(window.KOTO_BOT_CHATS || []), ...KOTO_CHATS].map(c => ({
    ...c,
    muted: muted[c.id] != null ? muted[c.id] : c.muted,
    pinned: pinned[c.id] != null ? pinned[c.id] : c.pinned,
    unread: readOverrides[c.id] === 'read' ? 0
          : readOverrides[c.id] === 'unread' ? Math.max(1, c.unread || 1)
          : c.unread,
  }));

  const archivedChats = adjustedChats.filter(c => archived[c.id]);
  const activeChats = adjustedChats.filter(c => !archived[c.id]);

  const filtered = activeChats.filter(c => {
    if (tab === 'unread' && c.unread === 0) return false;
    if (tab === 'groups' && !getContact(c.contactId)?.phone?.includes('группа')) return false;
    if (query) {
      const contact = getContact(c.contactId);
      return contact.name.toLowerCase().includes(query.toLowerCase())
          || c.preview.toLowerCase().includes(query.toLowerCase());
    }
    return true;
  });

  const pinnedList = filtered.filter(c => c.pinned);
  const restList = filtered.filter(c => !c.pinned);

  // close any open row if user clicks somewhere non-row
  useEffectCL(() => {
    const close = () => setOpenRow(null);
    if (openRow) {
      const t = setTimeout(() => window.addEventListener('click', close, { once:true }), 0);
      return () => { clearTimeout(t); window.removeEventListener('click', close); };
    }
  }, [openRow]);

  return (
    <div style={{ height: '100%', background: bg, color: text, display: 'flex', flexDirection: 'column' }}>
      {/* Header */}
      <div style={{ paddingTop: 59, flexShrink: 0 }}>
        <div style={{
          display: 'flex', alignItems: 'center', justifyContent: 'space-between',
          padding: '12px 20px 10px',
        }}>
          <button
            onClick={onOpenSettings}
            className="press"
            style={{ border: 0, background: 'transparent', padding: 0, cursor: 'pointer', position: 'relative' }}
          >
            <Avatar contact={{ initials: 'Я', color: 'var(--accent)' }} size={36} />
            <div style={{
              position: 'absolute', right: -2, top: -2, width: 10, height: 10, borderRadius: '50%',
              background: 'var(--accent)', border: `2px solid ${bg}`,
            }} />
          </button>
          <div style={{ display: 'flex', gap: 6 }}>
            <button onClick={onOpenBots} className="press" style={iconBtn(dark)} title="Боты">
              <BotGlyph size={20} color={text}/>
            </button>
            <button onClick={onOpenCamera} className="press" style={iconBtn(dark)}>
              <Ico.Camera size={22} color={text} />
            </button>
            <button onClick={onOpenNewChat} className="press" style={iconBtn(dark)}>
              <Ico.Pencil size={20} color={text} />
            </button>
          </div>
        </div>
        {/* Large title */}
        <div style={{
          padding: '2px 20px 8px',
          fontSize: 40, fontWeight: 800, letterSpacing: -1.4, lineHeight: 1,
          display: 'flex', alignItems: 'baseline', gap: 10,
        }}>
          Koto
          <span style={{ fontSize: 15, fontWeight: 500, color: sec, letterSpacing: -0.2 }}>
            {activeChats.reduce((s,c)=>s+c.unread,0)} новых
          </span>
        </div>
        {/* Search */}
        <div style={{ padding: '8px 16px 6px' }}>
          <div style={{
            height: 38, background: surface, borderRadius: 12,
            display: 'flex', alignItems: 'center', padding: '0 10px', gap: 8,
          }}>
            <Ico.Search size={17} color={sec} />
            <input
              value={query}
              onChange={e=>setQuery(e.target.value)}
              placeholder="Поиск по чатам и контактам"
              style={{
                flex: 1, border: 0, background: 'transparent', outline: 'none',
                color: text, fontSize: 15, fontFamily: 'inherit',
              }}
            />
          </div>
        </div>
        {/* Tabs */}
        <div style={{ display: 'flex', gap: 6, padding: '4px 16px 10px', overflowX: 'auto' }} className="koto-scroll">
          {[
            {id:'all', label:'Все'},
            {id:'unread', label:'Непрочитанные'},
            {id:'groups', label:'Группы'},
            {id:'stories', label:'Истории'},
          ].map(t => (
            <button
              key={t.id}
              onClick={()=>{ if (t.id==='stories') { onOpenStories(); return; } setTab(t.id); }}
              className="press"
              style={{
                border: 0, cursor: 'pointer', padding: '7px 14px', borderRadius: 999,
                fontSize: 13.5, fontWeight: 600, letterSpacing: -0.1,
                background: tab === t.id ? 'var(--accent)' : surface,
                color: tab === t.id ? '#fff' : text,
                flexShrink: 0,
              }}
            >{t.label}</button>
          ))}
        </div>
      </div>

      {/* List */}
      <div className="koto-scroll" style={{ flex: 1, overflowY: 'auto', paddingBottom: 100 }}>
        {/* Archive entry */}
        {archivedChats.length > 0 && (
          <button
            onClick={onOpenArchive}
            className="press"
            style={{
              display: 'flex', alignItems: 'center', gap: 12,
              width: '100%', border: 0, background: dark ? '#0b0b0c' : '#fff',
              padding: '10px 20px', cursor: 'pointer', color: text,
              fontFamily: 'inherit', textAlign: 'left',
              borderBottom: `0.5px solid ${sep}`,
            }}
          >
            <div style={{
              width: 44, height: 44, borderRadius: 22,
              background: dark ? '#1f1f22' : '#eef0f3',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              flexShrink: 0,
            }}>
              <Ico.Archive size={20} color={sec}/>
            </div>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ fontSize: 15.5, fontWeight: 600, letterSpacing: -0.2 }}>Архив</div>
              <div style={{ fontSize: 13, color: sec, marginTop: 2, overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap' }}>
                {archivedChats.slice(0,2).map(c => getContact(c.contactId).name).join(', ')}
                {archivedChats.length > 2 ? ` и ещё ${archivedChats.length-2}` : ''}
              </div>
            </div>
            <div style={{
              fontSize: 12, color: sec, fontVariantNumeric: 'tabular-nums',
              display:'flex', alignItems:'center', gap:4,
            }}>
              {archivedChats.reduce((s,c)=>s+c.unread,0) > 0 && (
                <div style={{
                  minWidth:20, height:20, padding:'0 6px', borderRadius:10,
                  background:sec, color:'#fff', fontSize:11, fontWeight:700,
                  display:'flex', alignItems:'center', justifyContent:'center',
                }}>{archivedChats.reduce((s,c)=>s+c.unread,0)}</div>
              )}
              <Ico.ChevronRight size={16} color={sec}/>
            </div>
          </button>
        )}

        {pinnedList.length > 0 && (
          <div style={{ padding: '6px 20px 4px', fontSize: 11, fontWeight: 600, color: sec, textTransform: 'uppercase', letterSpacing: 0.5 }}>
            Закреплены
          </div>
        )}
        {pinnedList.map((c,i) => (
          <SwipeRow
            key={c.id} chat={c} dark={dark} density={density}
            isLast={i===pinnedList.length-1 && restList.length===0}
            openRow={openRow} setOpenRow={setOpenRow}
            leftActions={leftActions(c, { muted, setMuted, pinned: pinned, setPinned, archived, setArchived })}
            rightActions={rightActions(c, { readOverrides, setReadOverrides })}
            onOpen={() => onOpenChat(c.id)}
          />
        ))}
        {restList.length > 0 && pinnedList.length > 0 && <div style={{ height: 8 }} />}
        {restList.map((c,i) => (
          <SwipeRow
            key={c.id} chat={c} dark={dark} density={density}
            isLast={i===restList.length-1}
            openRow={openRow} setOpenRow={setOpenRow}
            leftActions={leftActions(c, { muted, setMuted, pinned: pinned, setPinned, archived, setArchived })}
            rightActions={rightActions(c, { readOverrides, setReadOverrides })}
            onOpen={() => onOpenChat(c.id)}
          />
        ))}
        {filtered.length === 0 && archivedChats.length === 0 && (
          <div style={{ padding: '60px 20px', textAlign: 'center', color: sec, fontSize: 15 }}>Ничего не найдено</div>
        )}
      </div>
    </div>
  );
}

// ─────────── ArchiveScreen ───────────
function ArchiveScreen({
  dark, density, onBack, onOpenChat,
  archived, setArchived, muted, setMuted, pinnedMap, setPinnedMap, readOverrides, setReadOverrides,
}) {
  const bg = dark ? '#0b0b0c' : '#ffffff';
  const text = dark ? '#fff' : '#0a0a0a';
  const sec = dark ? '#9e9e9e' : '#707070';
  const sep = dark ? 'rgba(255,255,255,0.06)' : 'rgba(0,0,0,0.05)';

  const [openRow, setOpenRow] = useStateCL(null);

  const archivedChats = [...(window.KOTO_BOT_CHATS || []), ...KOTO_CHATS]
    .filter(c => archived[c.id])
    .map(c => ({
      ...c,
      muted: muted[c.id] != null ? muted[c.id] : c.muted,
      pinned: false, // no pin in archive
      unread: readOverrides[c.id] === 'read' ? 0
            : readOverrides[c.id] === 'unread' ? Math.max(1, c.unread || 1)
            : c.unread,
    }));

  useEffectCL(() => {
    const close = () => setOpenRow(null);
    if (openRow) {
      const t = setTimeout(() => window.addEventListener('click', close, { once:true }), 0);
      return () => { clearTimeout(t); window.removeEventListener('click', close); };
    }
  }, [openRow]);

  return (
    <div style={{ height:'100%', background:bg, color:text, display:'flex', flexDirection:'column' }}>
      <div style={{
        paddingTop: 59, flexShrink: 0,
        borderBottom: `0.5px solid ${sep}`,
      }}>
        <div style={{ display:'flex', alignItems:'center', padding:'6px 8px 12px' }}>
          <button onClick={onBack} className="press" style={{ border:0, background:'transparent', cursor:'pointer', padding:8, display:'flex', alignItems:'center', gap:2 }}>
            <Ico.Back size={26} color="var(--accent)"/>
            <span style={{ color:'var(--accent)', fontSize:17 }}>Чаты</span>
          </button>
          <div style={{ flex:1, textAlign:'center', fontSize:17, fontWeight:700, letterSpacing:-0.2, marginRight:50 }}>
            Архив
          </div>
        </div>
      </div>

      <div className="koto-scroll" style={{ flex:1, overflowY:'auto', paddingBottom: 40 }}>
        {archivedChats.length === 0 ? (
          <div style={{ padding: '80px 32px', textAlign:'center', color:sec }}>
            <div style={{
              width:72, height:72, borderRadius:36, margin:'0 auto 16px',
              background: dark?'#1a1a1c':'#f2f2f2',
              display:'flex', alignItems:'center', justifyContent:'center',
            }}>
              <Ico.Archive size={30} color={sec}/>
            </div>
            <div style={{ fontSize:17, fontWeight:600, color:text, marginBottom:6 }}>Архив пуст</div>
            <div style={{ fontSize:14, lineHeight:1.4 }}>
              Смахните чат влево на списке, чтобы отправить его сюда.
            </div>
          </div>
        ) : (
          <>
            <div style={{ padding:'14px 20px 6px', fontSize:13, color:sec, lineHeight:1.45 }}>
              Чаты в архиве не показываются в списке и не присылают звуки уведомлений. Новое сообщение вернёт чат обратно.
            </div>
            {archivedChats.map((c,i) => (
              <SwipeRow
                key={c.id} chat={c} dark={dark} density={density}
                isLast={i===archivedChats.length-1}
                openRow={openRow} setOpenRow={setOpenRow}
                leftActions={[{
                  id:'unarchive',
                  bg:'#34c759', color:'#fff',
                  icon:(sz,col)=><Ico.Unarchive size={sz} color={col}/>,
                  label:'Из архива',
                  commitOnFull:true,
                  onAction: () => setArchived(prev => { const n={...prev}; delete n[c.id]; return n; }),
                }]}
                rightActions={[
                  {
                    id:'read',
                    bg:'#0a84ff', color:'#fff',
                    icon:(sz,col)=>(c.unread>0
                      ? <Ico.CheckCircle size={sz} color={col}/>
                      : <Ico.DotCircle size={sz} color={col}/>),
                    label: c.unread > 0 ? 'Прочитано' : 'Не прочитано',
                    onAction: () => setReadOverrides(prev => ({ ...prev, [c.id]: c.unread>0 ? 'read' : 'unread' })),
                  },
                  {
                    id:'delete',
                    bg:'#ff3b30', color:'#fff',
                    icon:(sz,col)=><Ico.Trash size={sz} color={col}/>,
                    label:'Удалить',
                    commitOnFull: true,
                    onAction: () => setArchived(prev => { const n={...prev}; delete n[c.id]; return n; }),
                  },
                ]}
                onOpen={() => onOpenChat(c.id)}
              />
            ))}
          </>
        )}
      </div>
    </div>
  );
}

// ─────────── action factories used from ChatListScreen ───────────
function leftActions(c, { muted, setMuted, pinned, setPinned, archived, setArchived }) {
  return [
    {
      id:'pin',
      bg:'#ff9f0a', color:'#fff',
      icon:(sz,col)=><Ico.Pin size={sz} color={col}/>,
      label: c.pinned ? 'Открепить' : 'Закрепить',
      onAction: () => setPinned(prev => ({ ...prev, [c.id]: !c.pinned })),
    },
    {
      id:'mute',
      bg:'#8e8e93', color:'#fff',
      icon:(sz,col)=> c.muted
        ? <Ico.Bell size={sz} color={col}/>
        : <Ico.Mute size={sz} color={col}/>,
      label: c.muted ? 'Вкл. звук' : 'Без звука',
      onAction: () => setMuted(prev => ({ ...prev, [c.id]: !c.muted })),
    },
    {
      id:'archive',
      bg:'#c47a3a', color:'#fff',
      icon:(sz,col)=><Ico.Archive size={sz} color={col}/>,
      label:'Архив',
      commitOnFull: true,
      onAction: () => setArchived(prev => ({ ...prev, [c.id]: true })),
    },
  ];
}
function rightActions(c, { readOverrides, setReadOverrides }) {
  return [
    {
      id:'read',
      bg:'#0a84ff', color:'#fff',
      icon:(sz,col)=> c.unread>0
        ? <Ico.CheckCircle size={sz} color={col}/>
        : <Ico.DotCircle size={sz} color={col}/>,
      label: c.unread > 0 ? 'Прочитано' : 'Не прочитано',
      commitOnFull: true,
      onAction: () => setReadOverrides(prev => ({ ...prev, [c.id]: c.unread>0 ? 'read' : 'unread' })),
    },
  ];
}

// ─────────── SwipeRow ───────────
// Two-directional reveal with snap-open and full-swipe commit.
// leftActions are revealed by swiping RIGHT (action tray slides in from left).
// rightActions are revealed by swiping LEFT (action tray slides in from right).
const ACTION_W = 74;      // each action column width
const SNAP_BUFFER = 14;   // velocity buffer for snap
const FULL_SWIPE = 200;   // threshold for commit-on-full
function SwipeRow({ chat, dark, density, isLast, openRow, setOpenRow, leftActions = [], rightActions = [], onOpen }) {
  const contact = getContact(chat.contactId);
  const text = dark ? '#fff' : '#0a0a0a';
  const sec = dark ? '#9e9e9e' : '#707070';
  const sep = dark ? 'rgba(255,255,255,0.06)' : 'rgba(0,0,0,0.06)';

  const leftW = leftActions.length * ACTION_W;
  const rightW = rightActions.length * ACTION_W;

  // internal dragX — negative = tray right revealed (swipe left)
  const [dragX, setDragX] = useStateCL(0);
  const [dragging, setDragging] = useStateCL(false);
  const startX = useRefCL(null);
  const startY = useRefCL(null);
  const lockedAxis = useRefCL(null); // 'x' | 'y' | null
  const lastX = useRefCL(0);

  // Sync with openRow: if another row opens, snap this one back.
  useEffectCL(() => {
    if (openRow !== chat.id && dragX !== 0 && !dragging) {
      setDragX(0);
    }
  }, [openRow]);

  const snapTo = (x) => {
    setDragX(x);
    if (x === 0) {
      if (openRow === chat.id) setOpenRow(null);
    } else {
      setOpenRow(chat.id);
    }
  };

  const onStart = (e) => {
    const pt = e.touches ? e.touches[0] : e;
    startX.current = pt.clientX;
    startY.current = pt.clientY;
    lockedAxis.current = null;
    lastX.current = dragX;
    setDragging(true);
  };
  const onMove = (e) => {
    if (startX.current == null) return;
    const pt = e.touches ? e.touches[0] : e;
    const dx = pt.clientX - startX.current;
    const dy = pt.clientY - startY.current;
    if (lockedAxis.current == null) {
      if (Math.abs(dx) < 4 && Math.abs(dy) < 4) return;
      lockedAxis.current = Math.abs(dx) > Math.abs(dy) ? 'x' : 'y';
    }
    if (lockedAxis.current !== 'x') return;
    if (e.preventDefault && e.cancelable) e.preventDefault();
    let next = lastX.current + dx;
    // rubber-band past full swipe
    const maxL = leftActions.length ? Math.min(next, leftW + 60) : 0;
    const maxR = rightActions.length ? Math.max(next, -rightW - 60) : 0;
    if (next > 0) next = leftActions.length ? maxL : 0;
    else if (next < 0) next = rightActions.length ? maxR : 0;
    setDragX(next);
  };
  const onEnd = () => {
    if (startX.current == null) return;
    const wasDragging = lockedAxis.current === 'x';
    setDragging(false);
    startX.current = null; startY.current = null; lockedAxis.current = null;
    if (!wasDragging) return;

    // commit-on-full
    if (dragX > FULL_SWIPE) {
      const commit = leftActions.find(a => a.commitOnFull);
      if (commit) { commit.onAction(); snapTo(0); return; }
    }
    if (dragX < -FULL_SWIPE) {
      const commit = rightActions.find(a => a.commitOnFull);
      if (commit) { commit.onAction(); snapTo(0); return; }
    }
    // snap
    if (dragX > leftW / 2 + SNAP_BUFFER) snapTo(leftW);
    else if (dragX < -(rightW / 2 + SNAP_BUFFER)) snapTo(-rightW);
    else snapTo(0);
  };

  const onClickRow = (e) => {
    if (dragX !== 0) {
      e.stopPropagation();
      snapTo(0);
      return;
    }
    onOpen();
  };

  const handleActionClick = (a, e) => {
    e.stopPropagation();
    a.onAction();
    snapTo(0);
  };

  // When full-swiping and we'd commit, the primary action expands to full width
  const fullLeft = dragX > FULL_SWIPE && leftActions.some(a => a.commitOnFull);
  const fullRight = dragX < -FULL_SWIPE && rightActions.some(a => a.commitOnFull);

  return (
    <div
      style={{
        position: 'relative',
        background: dark ? '#0b0b0c' : '#fff',
        overflow: 'hidden',
        touchAction: 'pan-y',
      }}
    >
      {/* Left action tray (revealed by swiping right) */}
      {leftActions.length > 0 && (
        <div style={{
          position: 'absolute', top: 0, bottom: 0, left: 0,
          width: Math.max(0, dragX),
          display: 'flex', overflow: 'hidden',
          pointerEvents: dragX > 4 ? 'auto' : 'none',
        }}>
          {leftActions.map((a, i) => {
            const expand = fullLeft && a.commitOnFull;
            return (
              <button
                key={a.id}
                onClick={(e) => handleActionClick(a, e)}
                style={{
                  flex: expand ? 1 : 'none',
                  width: expand ? '100%' : ACTION_W,
                  background: a.bg, color: a.color,
                  border: 0, cursor: 'pointer',
                  display: 'flex', flexDirection: 'column',
                  alignItems: expand ? 'flex-start' : 'center', justifyContent: 'center',
                  gap: 4, padding: expand ? '0 20px' : 0,
                  fontFamily: 'inherit',
                  transition: expand ? 'flex 140ms linear, padding 140ms linear' : 'flex 140ms linear',
                }}
              >
                {a.icon(20, a.color)}
                <span style={{ fontSize: 12, fontWeight: 600, letterSpacing: -0.1 }}>{a.label}</span>
              </button>
            );
          })}
        </div>
      )}

      {/* Right action tray (revealed by swiping left) */}
      {rightActions.length > 0 && (
        <div style={{
          position: 'absolute', top: 0, bottom: 0, right: 0,
          width: Math.max(0, -dragX),
          display: 'flex', overflow: 'hidden',
          flexDirection: 'row-reverse',
          pointerEvents: dragX < -4 ? 'auto' : 'none',
        }}>
          {rightActions.map((a) => {
            const expand = fullRight && a.commitOnFull;
            return (
              <button
                key={a.id}
                onClick={(e) => handleActionClick(a, e)}
                style={{
                  flex: expand ? 1 : 'none',
                  width: expand ? '100%' : ACTION_W,
                  background: a.bg, color: a.color,
                  border: 0, cursor: 'pointer',
                  display: 'flex', flexDirection: 'column',
                  alignItems: expand ? 'flex-end' : 'center', justifyContent: 'center',
                  gap: 4, padding: expand ? '0 20px' : 0,
                  fontFamily: 'inherit',
                  transition: expand ? 'flex 140ms linear, padding 140ms linear' : 'flex 140ms linear',
                }}
              >
                {a.icon(20, a.color)}
                <span style={{ fontSize: 12, fontWeight: 600, letterSpacing: -0.1 }}>{a.label}</span>
              </button>
            );
          })}
        </div>
      )}

      {/* Foreground row */}
      <div
        onMouseDown={onStart} onMouseMove={dragging ? onMove : undefined}
        onMouseUp={onEnd} onMouseLeave={dragging ? onEnd : undefined}
        onTouchStart={onStart} onTouchMove={onMove} onTouchEnd={onEnd}
        onClick={onClickRow}
        className="no-select"
        style={{
          position: 'relative', zIndex: 1,
          transform: `translate3d(${dragX}px,0,0)`,
          transition: dragging ? 'none' : 'transform 260ms cubic-bezier(.2,.8,.2,1)',
          background: dark ? '#0b0b0c' : '#fff',
          minHeight: density, display: 'flex', alignItems: 'center',
          padding: '10px 16px 10px 20px', gap: 12, cursor: 'pointer',
        }}
      >
        <Avatar contact={contact} size={52} online={contact.status==='в сети'} />
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
            <div style={{ fontSize: 16, fontWeight: 600, letterSpacing: -0.3, color: text, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
              {contact.name}
            </div>
            {contact.isBot && (
              <span style={{
                background: contact.color, color:'#fff', fontSize:8, fontWeight:800,
                padding:'2px 5px', borderRadius:3, letterSpacing:0.4, lineHeight:1, flexShrink:0,
              }}>BOT</span>
            )}
            {contact.verified && typeof VerifiedTick === 'function' && <VerifiedTick color={contact.color}/>}
            {chat.muted && <Ico.Mute size={13} color={sec} />}
            {chat.ephemeral && <Ico.Timer size={13} color="var(--accent)" />}
            <div style={{ flex: 1 }} />
            <div style={{ fontSize: 12, color: chat.unread ? 'var(--accent)' : sec, fontWeight: chat.unread ? 600 : 500 }}>
              {chat.time}
            </div>
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginTop: 3 }}>
            {chat.lastSelf && !chat.typing && (
              <div style={{ color: chat.status==='read' ? 'var(--accent)' : sec }}>
                <Status status={chat.status || 'sent'} dark={dark} />
              </div>
            )}
            <div style={{
              flex: 1, fontSize: 14, lineHeight: '18px',
              color: chat.typing ? 'var(--accent)' : sec,
              fontStyle: chat.typing ? 'italic' : 'normal',
              overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap',
              fontWeight: chat.typing ? 500 : 400,
            }}>
              {chat.typing ? <span style={{display:'inline-flex', gap:6, alignItems:'center'}}><TypingDots size={4}/> печатает…</span> : chat.preview}
            </div>
            {chat.unread > 0 && (
              <div style={{
                minWidth: 22, height: 22, borderRadius: 11, padding: '0 7px',
                background: chat.muted ? sec : 'var(--accent)', color: '#fff',
                fontSize: 12, fontWeight: 700, display: 'flex', alignItems: 'center', justifyContent: 'center',
              }}>{chat.unread}</div>
            )}
            {chat.pinned && chat.unread === 0 && <Ico.Pin size={12} color={sec} />}
          </div>
        </div>
      </div>
      {!isLast && dragX === 0 && (
        <div style={{ height: 0.5, background: sep, marginLeft: 88 }} />
      )}
    </div>
  );
}

function iconBtn(dark) {
  return {
    width: 40, height: 40, borderRadius: '50%',
    background: dark ? '#1a1a1c' : '#f2f2f2',
    border: 0, cursor: 'pointer',
    display: 'flex', alignItems: 'center', justifyContent: 'center',
  };
}

window.ChatListScreen = ChatListScreen;
window.ArchiveScreen = ArchiveScreen;
