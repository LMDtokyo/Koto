/* global React, Ico, Avatar, getBot, KOTO_BOTS, PAWKET_BOARD, KASSA_EVENTS */
// Bots.jsx — BotForge, WebApps (Pawket Board, Kassa Shop), bot-message renderers, Bot Catalog

const { useState: useStateB, useEffect: useEffectB, useRef: useRefB } = React;

// ─── Bot intro card (sits at top of bot conversation) ─────
function BotIntroCard({ botId, dark, onCmd, onWebApp }) {
  const bot = getBot(botId);
  if (!bot) return null;
  const text = dark ? '#fff' : '#0a0a0a';
  const sec  = dark ? '#9e9e9e' : '#707070';
  const surface = dark ? '#15151a' : '#f6f6f7';
  const hairline = dark ? 'rgba(255,255,255,0.06)' : 'rgba(0,0,0,0.06)';

  // Short, bot-specific "what it does" bullets + example commands
  const perBot = {
    pawket: {
      abilities: [
        { icon:'☀️', t:'Прогноз погоды', d:'«/weather» или «погода в Москве»' },
        { icon:'💱', t:'Курсы валют и крипта', d:'«/rates», «USD», «BTC»' },
        { icon:'🗒',  t:'Заметки и напоминания', d:'«напомни в 18:00»' },
        { icon:'🧠', t:'Доска с ИИ-заметками', d:'мини-приложение внутри чата' },
      ],
      quick: [[{ label:'☀️ /weather', cmd:'/weather' }, { label:'💱 /rates', cmd:'/rates' }],
              [{ label:'🧠 Открыть доску', webapp:'pawket-board', primary:true }]],
    },
    kassa: {
      abilities: [
        { icon:'🎵', t:'Билеты на концерты', d:'подборки по жанрам и датам' },
        { icon:'🎬', t:'Кино', d:'ближайшие сеансы в вашем городе' },
        { icon:'⚽', t:'Спорт и театр', d:'матчи, спектакли, стендап' },
        { icon:'💳', t:'Оплата в 2 тапа', d:'билеты придут в Кошелёк Koto' },
      ],
      quick: [[{ label:'🎵 Концерты', cmd:'/concerts' }, { label:'🎬 Кино', cmd:'/movies' }],
              [{ label:'🛒 Открыть магазин', webapp:'kassa-shop', primary:true }]],
    },
    'meow-quiz': {
      abilities: [
        { icon:'🧩', t:'Викторина в чате', d:'раунды по 5 минут' },
        { icon:'👥', t:'Играйте с друзьями', d:'добавьте бота в группу' },
        { icon:'🏆', t:'Рейтинг и темы', d:'кино, наука, мемы, история' },
      ],
      quick: [[{ label:'▶️ Начать раунд', cmd:'/start', primary:true }]],
    },
    rates: {
      abilities: [
        { icon:'💵', t:'Курсы ЦБ', d:'USD, EUR, CNY, RUB — раз в час' },
        { icon:'₿',  t:'Криптовалюты', d:'BTC, ETH, SOL — в режиме реального времени' },
        { icon:'🔔', t:'Алерты', d:'сообщит когда курс пересечёт порог' },
      ],
      quick: [[{ label:'💵 /rates', cmd:'/rates' }, { label:'🔔 Алерт', cmd:'/alert' }]],
    },
  };
  const cfg = perBot[botId] || { abilities: [], quick: [] };

  return (
    <div style={{
      margin:'8px auto 16px', maxWidth:320,
      animation:'fadeInScale 360ms cubic-bezier(.2,.8,.2,1)',
    }}>
      {/* Hero */}
      <div style={{ textAlign:'center', padding:'4px 8px 16px' }}>
        <div style={{ position:'relative', display:'inline-block', marginBottom:12 }}>
          <div style={{
            position:'absolute', inset:-8, borderRadius:'50%',
            background:`radial-gradient(circle, ${bot.color}33, transparent 70%)`,
            filter:'blur(4px)', animation:'botGlow 3s ease-in-out infinite',
          }}/>
          <Avatar contact={bot} size={84}/>
          <div style={{
            position:'absolute', bottom:-2, right:-2,
            background: bot.color, color:'#fff', fontSize:9, fontWeight:800,
            padding:'3px 7px', borderRadius:6, letterSpacing:0.8,
            border:`2.5px solid ${dark?'#0b0b0c':'#fff'}`,
          }}>BOT</div>
        </div>
        <div style={{ fontSize:22, fontWeight:700, color:text, display:'inline-flex', alignItems:'center', gap:6, letterSpacing:-0.4 }}>
          {bot.name}
          {bot.verified && <VerifiedTick color={bot.color}/>}
        </div>
        <div style={{ fontSize:12.5, color:sec, marginTop:3, fontWeight:500 }}>
          {bot.handle} · 👤 {bot.users}
        </div>
        <div style={{ fontSize:14, color:text, marginTop:10, lineHeight:1.45, padding:'0 8px', textWrap:'pretty' }}>
          {bot.tagline}
        </div>
      </div>

      {/* Abilities */}
      {cfg.abilities.length > 0 && (
        <div style={{
          background:surface, borderRadius:14, overflow:'hidden',
          border:`1px solid ${hairline}`,
        }}>
          <div style={{
            padding:'10px 14px 8px', fontSize:11, fontWeight:700,
            color:sec, textTransform:'uppercase', letterSpacing:0.8,
          }}>Что умеет</div>
          {cfg.abilities.map((a, i) => (
            <div key={i} style={{
              display:'flex', alignItems:'flex-start', gap:12,
              padding:'10px 14px',
              borderTop: i===0 ? 'none' : `0.5px solid ${hairline}`,
            }}>
              <div style={{
                width:28, height:28, borderRadius:8,
                background: dark?'rgba(255,255,255,0.05)':'rgba(0,0,0,0.04)',
                display:'flex', alignItems:'center', justifyContent:'center',
                fontSize:15, flexShrink:0,
              }}>{a.icon}</div>
              <div style={{ flex:1, minWidth:0 }}>
                <div style={{ fontSize:13.5, fontWeight:600, color:text }}>{a.t}</div>
                <div style={{ fontSize:12, color:sec, marginTop:1, lineHeight:1.35 }}>{a.d}</div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* How to start */}
      <div style={{ marginTop:16, textAlign:'center' }}>
        <div style={{
          fontSize:11, fontWeight:700, color:sec,
          textTransform:'uppercase', letterSpacing:0.8, marginBottom:8,
        }}>Как начать</div>
        <div style={{ fontSize:13, color:sec, marginBottom:10, lineHeight:1.5 }}>
          Нажмите <span style={{ color:text, fontWeight:600 }}>«Запустить»</span> или<br/>напишите боту любое сообщение.
        </div>
      </div>

      {/* Big START button + quick actions */}
      <button className="press" onClick={() => onCmd && onCmd('/start', 'Запустить')} style={{
        width:'100%', padding:'14px', background:'var(--accent)', color:'#fff',
        border:0, borderRadius:14, fontSize:15, fontWeight:700, cursor:'pointer',
        boxShadow:'0 6px 20px rgba(255,107,53,0.35)',
        display:'flex', alignItems:'center', justifyContent:'center', gap:8,
        letterSpacing:-0.2,
      }}>
        ▶ Запустить бота
      </button>

      {cfg.quick.length > 0 && (
        <div style={{ marginTop:10 }}>
          <BotKeyboard buttons={cfg.quick} dark={dark} onCmd={onCmd} onWebApp={onWebApp}/>
        </div>
      )}

      {/* Fine print */}
      <div style={{
        marginTop:14, padding:'10px 12px', background: dark?'rgba(255,107,53,0.08)':'rgba(255,107,53,0.06)',
        borderRadius:10, fontSize:11.5, color:sec, lineHeight:1.4,
        display:'flex', gap:8,
      }}>
        <span style={{ flexShrink:0 }}>ⓘ</span>
        <span>Бот видит только ваши сообщения к нему. Личная переписка остаётся зашифрованной.</span>
      </div>
    </div>
  );
}

function VerifiedTick({ color = '#3276ff' }) {
  return (
    <svg width="14" height="14" viewBox="0 0 16 16">
      <path d="M8 1l1.6 1.4 2.1-.4.9 1.9 2 .9-.4 2.1L15.5 8l-1.4 1.6.4 2.1-1.9.9-.9 2-2.1-.4L8 15.5l-1.6-1.4-2.1.4-.9-1.9-2-.9.4-2.1L.5 8l1.4-1.6-.4-2.1 1.9-.9.9-2 2.1.4L8 .5z" fill={color}/>
      <path d="M5 8l2 2 4-4" stroke="#fff" strokeWidth="1.6" fill="none" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
  );
}

// ─── Bot inline keyboard (rows of buttons) ────────────────
function BotKeyboard({ buttons, dark, onCmd, onWebApp }) {
  if (!buttons) return null;
  const text = dark ? '#fff' : '#0a0a0a';
  const surface = dark ? 'rgba(255,255,255,0.08)' : 'rgba(0,0,0,0.05)';
  const surfaceHi = dark ? 'rgba(255,255,255,0.14)' : 'rgba(0,0,0,0.08)';

  return (
    <div style={{ display:'flex', flexDirection:'column', gap:4, marginTop:6 }}>
      {buttons.map((row, ri) => (
        <div key={ri} style={{ display:'flex', gap:4 }}>
          {row.map((b, bi) => (
            <button key={bi} className="press" onClick={() => {
              if (b.webapp) onWebApp && onWebApp(b.webapp);
              else onCmd && onCmd(b.cmd, b.label);
            }} style={{
              flex:1, background: b.primary ? 'var(--accent)' : (b.webapp ? surfaceHi : surface),
              color: b.primary ? '#fff' : text,
              border: 0, padding:'10px 12px', borderRadius:10, cursor:'pointer',
              fontSize:13.5, fontWeight: b.primary?600:500,
              display:'flex', alignItems:'center', justifyContent:'center', gap:6,
              transition:'background 160ms',
            }}>
              {b.webapp && <WebAppDot/>}
              {b.label}
            </button>
          ))}
        </div>
      ))}
    </div>
  );
}

function WebAppDot() {
  return <svg width="10" height="10" viewBox="0 0 10 10">
    <circle cx="5" cy="5" r="4" fill="currentColor" opacity="0.2"/>
    <circle cx="5" cy="5" r="2" fill="currentColor"/>
  </svg>;
}

// ─── Bot weather card ─────────────────────────────────────
function BotWeatherCard({ data, dark }) {
  const text = dark ? '#fff' : '#0a0a0a';
  const sec  = dark ? '#9e9e9e' : '#707070';
  const max = Math.max(...data.hourly), min = Math.min(...data.hourly);
  return (
    <div style={{
      background: dark
        ? 'linear-gradient(160deg, #1a2a4a 0%, #0a1428 100%)'
        : 'linear-gradient(160deg, #4a90e2 0%, #2c5aa0 100%)',
      borderRadius:14, padding:14, color:'#fff', minWidth:240,
      boxShadow: dark ? 'inset 0 1px 0 rgba(255,255,255,0.1)' : 'none',
    }}>
      <div style={{ fontSize:11, opacity:0.8, letterSpacing:0.5, textTransform:'uppercase', fontWeight:600 }}>{data.city}</div>
      <div style={{ display:'flex', alignItems:'baseline', gap:10, marginTop:4 }}>
        <div style={{ fontSize:42, fontWeight:300, lineHeight:1, letterSpacing:-1.5 }}>{data.temp}</div>
        <div style={{ fontSize:13, opacity:0.85 }}>{data.cond}</div>
      </div>
      <div style={{ fontSize:11, opacity:0.7, marginTop:2 }}>↑ {data.hi} ↓ {data.lo}</div>
      {/* hourly mini-chart */}
      <svg viewBox="0 0 220 50" style={{ width:'100%', height:44, marginTop:10, display:'block' }}>
        <defs>
          <linearGradient id="wgrad" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="rgba(255,255,255,0.4)"/>
            <stop offset="100%" stopColor="rgba(255,255,255,0)"/>
          </linearGradient>
        </defs>
        {(() => {
          const pts = data.hourly.map((v,i) => {
            const x = (i/(data.hourly.length-1))*220;
            const y = 50 - ((v-min)/(max-min || 1))*40 - 5;
            return [x, y];
          });
          const path = pts.map((p,i) => (i?'L':'M') + p.join(',')).join(' ');
          const fill = path + ` L 220,50 L 0,50 Z`;
          return <>
            <path d={fill} fill="url(#wgrad)"/>
            <path d={path} fill="none" stroke="#fff" strokeWidth="1.6"/>
            {pts.map(([x,y],i) => <circle key={i} cx={x} cy={y} r="1.8" fill="#fff"/>)}
          </>;
        })()}
      </svg>
    </div>
  );
}

// ─── Generic bot card dispatcher ──────────────────────────
function BotCard({ card, dark }) {
  if (card?.kind === 'weather') return <BotWeatherCard data={card} dark={dark}/>;
  return null;
}

// ─── PAWKET BOARD WebApp ──────────────────────────────────
function PawketBoardSheet({ dark, onClose }) {
  const [tab, setTab] = useStateB('notes');
  const [aiPrompt, setAiPrompt] = useStateB('');
  const [aiResp, setAiResp] = useStateB(null);
  const [aiBusy, setAiBusy] = useStateB(false);

  const text = dark ? '#fff' : '#0a0a0a';
  const sec  = dark ? '#9e9e9e' : '#707070';
  const bg   = dark ? '#0b0b0c' : '#fff';
  const surface = dark ? '#1a1a1c' : '#f6f6f7';

  const askAI = async () => {
    if (!aiPrompt.trim() || aiBusy) return;
    setAiBusy(true); setAiResp(null);
    try {
      const r = await window.claude.complete(
        `Ты — Pawket, дружелюбный кот-ассистент в мессенджере. Отвечай кратко (1-3 предложения), на русском, добавляй 1 emoji кота или лапки если уместно. Вопрос: ${aiPrompt}`
      );
      setAiResp(r.trim());
    } catch (e) {
      setAiResp('Мрр… что-то пошло не так. Попробуй ещё раз 🐾');
    }
    setAiBusy(false);
  };

  return (
    <WebAppSheet
      title="Доска · Pawket"
      subtitle="koto.app/p/pawket"
      botColor="#ff6b35"
      onClose={onClose}
      dark={dark}
    >
      {/* Segmented control */}
      <div style={{ padding:'10px 14px 4px', display:'flex', gap:4, background:surface, borderRadius:10, margin:'10px 14px 12px' }}>
        {[['notes','🗒  Заметки'], ['reminders','⏰ Напом.'], ['habits','🎯 Привычки'], ['ai','🧠 Спросить']].map(([k,l]) => (
          <button key={k} onClick={() => setTab(k)} className="press" style={{
            flex:1, background: tab===k ? bg : 'transparent', border:0, color:text,
            padding:'7px 4px', borderRadius:7, fontSize:12.5, fontWeight: tab===k?600:500, cursor:'pointer',
            boxShadow: tab===k ? '0 1px 4px rgba(0,0,0,0.1)' : 'none',
            transition:'background 180ms',
          }}>{l}</button>
        ))}
      </div>

      <div style={{ padding:'0 14px 24px', overflowY:'auto', flex:1 }} className="koto-scroll">
        {tab==='notes' && (
          <>
            <div style={{ fontSize:12, color:sec, marginBottom:10, textTransform:'uppercase', letterSpacing:0.5, fontWeight:600 }}>3 заметки</div>
            {PAWKET_BOARD.notes.map(n => (
              <div key={n.id} style={{
                background:surface, borderRadius:12, padding:'12px 14px', marginBottom:8,
                display:'flex', alignItems:'center', gap:12,
              }}>
                <div style={{
                  width:36, height:36, borderRadius:10, background:dark?'#27272a':'#fff',
                  display:'flex', alignItems:'center', justifyContent:'center', fontSize:18,
                }}>{n.emoji}</div>
                <div style={{ flex:1, minWidth:0 }}>
                  <div style={{ fontSize:14, fontWeight:600, color:text }}>{n.title}</div>
                  <div style={{ fontSize:12, color:sec, marginTop:1 }}>{n.body}</div>
                </div>
              </div>
            ))}
            <button className="press" style={{
              width:'100%', padding:'12px', background:'transparent', border:`1.5px dashed ${dark?'#3a3a3c':'#d8d8da'}`,
              borderRadius:12, color:sec, fontSize:13.5, fontWeight:500, cursor:'pointer', marginTop:4,
            }}>+ Новая заметка</button>
          </>
        )}

        {tab==='reminders' && (
          <>
            <div style={{ fontSize:12, color:sec, marginBottom:10, textTransform:'uppercase', letterSpacing:0.5, fontWeight:600 }}>Активные</div>
            {PAWKET_BOARD.reminders.map(r => (
              <div key={r.id} style={{
                background:surface, borderRadius:12, padding:'12px 14px', marginBottom:8,
                display:'flex', alignItems:'center', gap:12,
              }}>
                <div style={{ width:8, height:8, borderRadius:'50%', background:r.dot, flexShrink:0 }}/>
                <div style={{ flex:1 }}>
                  <div style={{ fontSize:14, fontWeight:500, color:text }}>{r.text}</div>
                  <div style={{ fontSize:12, color:sec, marginTop:1 }}>{r.when}</div>
                </div>
                <button className="press" style={{
                  width:24, height:24, borderRadius:'50%', border:`1.5px solid ${dark?'#3a3a3c':'#c8c8ca'}`,
                  background:'transparent', cursor:'pointer',
                }}/>
              </div>
            ))}
          </>
        )}

        {tab==='habits' && (
          <>
            <div style={{ fontSize:12, color:sec, marginBottom:10, textTransform:'uppercase', letterSpacing:0.5, fontWeight:600 }}>Эта неделя</div>
            {PAWKET_BOARD.habits.map(h => (
              <div key={h.id} style={{
                background:surface, borderRadius:12, padding:'12px 14px', marginBottom:8,
              }}>
                <div style={{ display:'flex', alignItems:'center', gap:10, marginBottom:8 }}>
                  <div style={{ flex:1, fontSize:14, fontWeight:600, color:text }}>{h.name}</div>
                  <div style={{ fontSize:11, color:'#ff6b35', fontWeight:700 }}>🔥 {h.streak} дн.</div>
                </div>
                <div style={{ display:'flex', gap:5 }}>
                  {h.week.map((v,i) => (
                    <div key={i} style={{
                      flex:1, height:22, borderRadius:5,
                      background: v ? '#ff6b35' : (dark?'#27272a':'#e4e4e7'),
                      opacity: v ? 1 : 0.6,
                    }}/>
                  ))}
                </div>
                <div style={{ display:'flex', justifyContent:'space-between', marginTop:5 }}>
                  {['П','В','С','Ч','П','С','В'].map((d,i) => (
                    <div key={i} style={{ flex:1, textAlign:'center', fontSize:10, color:sec }}>{d}</div>
                  ))}
                </div>
              </div>
            ))}
          </>
        )}

        {tab==='ai' && (
          <div style={{ display:'flex', flexDirection:'column', height:'100%' }}>
            <div style={{ fontSize:12, color:sec, marginBottom:10, textTransform:'uppercase', letterSpacing:0.5, fontWeight:600 }}>Спросите Pawket</div>
            <div style={{
              background:surface, borderRadius:14, padding:14, marginBottom:10,
              minHeight:120, display:'flex', flexDirection:'column', justifyContent:'center', textAlign:'center',
            }}>
              {aiBusy ? (
                <div style={{ display:'flex', flexDirection:'column', alignItems:'center', gap:10 }}>
                  <div style={{ fontSize:30 }}>🐾</div>
                  <div style={{ fontSize:13, color:sec }}>думаю…</div>
                </div>
              ) : aiResp ? (
                <div style={{ fontSize:14, lineHeight:1.5, color:text, whiteSpace:'pre-wrap', textAlign:'left' }}>{aiResp}</div>
              ) : (
                <div style={{ color:sec, fontSize:13 }}>Введите вопрос ниже — Pawket ответит через Claude.</div>
              )}
            </div>
            <textarea
              value={aiPrompt}
              onChange={e=>setAiPrompt(e.target.value)}
              placeholder="например: что приготовить из курицы?"
              rows={3}
              style={{
                width:'100%', padding:12, fontSize:14, color:text, background:surface,
                border:`1px solid ${dark?'#27272a':'#e4e4e7'}`, borderRadius:12, resize:'none',
                fontFamily:'inherit', outline:'none', boxSizing:'border-box', marginBottom:10,
              }}
            />
            <button className="press" onClick={askAI} disabled={aiBusy || !aiPrompt.trim()} style={{
              width:'100%', padding:'13px', background:'#ff6b35', color:'#fff', border:0,
              borderRadius:12, fontSize:14.5, fontWeight:600, cursor:'pointer',
              opacity: (aiBusy||!aiPrompt.trim()) ? 0.5 : 1,
            }}>{aiBusy ? 'думаю…' : 'Спросить Pawket 🧠'}</button>
          </div>
        )}
      </div>
    </WebAppSheet>
  );
}

// ─── KASSA SHOP WebApp ────────────────────────────────────
function KassaShopSheet({ dark, onClose }) {
  const [filter, setFilter] = useStateB('Все');
  const [selected, setSelected] = useStateB(null);
  const [bought, setBought] = useStateB(null);

  const text = dark ? '#fff' : '#0a0a0a';
  const sec  = dark ? '#9e9e9e' : '#707070';
  const bg   = dark ? '#0b0b0c' : '#fff';
  const surface = dark ? '#1a1a1c' : '#f6f6f7';

  const cats = ['Все','Концерт','Кино','Театр','Стендап','Футбол'];
  const events = filter==='Все' ? KASSA_EVENTS : KASSA_EVENTS.filter(e => e.kind === filter);

  if (bought) {
    return (
      <WebAppSheet title="Билет приобретён" subtitle="Касса" botColor="#7c5cff" onClose={onClose} dark={dark}>
        <div style={{ padding:'30px 20px', textAlign:'center', flex:1, overflow:'auto' }}>
          <div style={{
            width:80, height:80, borderRadius:'50%', background:'#34c759',
            margin:'0 auto 16px', display:'flex', alignItems:'center', justifyContent:'center',
            animation:'fadeInScale 380ms cubic-bezier(.2,.8,.2,1)',
          }}>
            <svg width="40" height="40" viewBox="0 0 24 24" fill="none">
              <path d="M5 12l4 4L19 7" stroke="#fff" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
          </div>
          <div style={{ fontSize:22, fontWeight:700, color:text, marginBottom:8 }}>Готово!</div>
          <div style={{ fontSize:14, color:sec, marginBottom:20 }}>Билет добавлен в Кошелёк Koto</div>
          <div style={{
            background: bought.cover, color:'#fff', padding:'18px 18px',
            borderRadius:14, textAlign:'left', position:'relative', overflow:'hidden',
          }}>
            <div style={{ fontSize:11, opacity:0.7, fontWeight:600, letterSpacing:0.5, textTransform:'uppercase' }}>{bought.kind}</div>
            <div style={{ fontSize:20, fontWeight:700, marginTop:4, marginBottom:14 }}>{bought.title}</div>
            <div style={{ display:'flex', gap:14 }}>
              <div>
                <div style={{ fontSize:10, opacity:0.6, letterSpacing:0.5, textTransform:'uppercase' }}>Дата</div>
                <div style={{ fontSize:14, marginTop:2, fontWeight:500 }}>{bought.date} · {bought.time}</div>
              </div>
              <div>
                <div style={{ fontSize:10, opacity:0.6, letterSpacing:0.5, textTransform:'uppercase' }}>Место</div>
                <div style={{ fontSize:14, marginTop:2, fontWeight:500 }}>{bought.venue}</div>
              </div>
            </div>
            {/* QR */}
            <div style={{
              marginTop:18, padding:14, background:'#fff', borderRadius:10, display:'flex', justifyContent:'center',
            }}>
              <FauxQR/>
            </div>
            <div style={{ position:'absolute', top:'50%', left:-6, width:12, height:12, borderRadius:'50%', background:bg }}/>
            <div style={{ position:'absolute', top:'50%', right:-6, width:12, height:12, borderRadius:'50%', background:bg }}/>
          </div>
          <button onClick={onClose} className="press" style={{
            width:'100%', marginTop:18, padding:'13px', background:'#7c5cff', color:'#fff', border:0,
            borderRadius:12, fontSize:15, fontWeight:600, cursor:'pointer',
          }}>Готово</button>
        </div>
      </WebAppSheet>
    );
  }

  if (selected) {
    return (
      <WebAppSheet title={selected.title} subtitle={`Касса · ${selected.kind}`} botColor="#7c5cff" onClose={onClose} dark={dark} onBack={() => setSelected(null)}>
        <div style={{ padding:'0 0 24px', flex:1, overflow:'auto' }} className="koto-scroll">
          <div style={{
            background: selected.cover, height:180, position:'relative',
            display:'flex', alignItems:'flex-end', padding:'18px 18px',
          }}>
            <div style={{ position:'absolute', inset:0, background:'linear-gradient(180deg, transparent 40%, rgba(0,0,0,0.6))' }}/>
            <div style={{ position:'relative', zIndex:1 }}>
              {selected.hot && <div style={{ display:'inline-block', background:'#ff3b30', color:'#fff', fontSize:10, fontWeight:800, padding:'3px 8px', borderRadius:4, letterSpacing:0.5, marginBottom:8 }}>🔥 РАСПРОДАЁТСЯ</div>}
              <div style={{ fontSize:11, color:'rgba(255,255,255,0.7)', textTransform:'uppercase', letterSpacing:0.5, fontWeight:600 }}>{selected.kind}</div>
              <div style={{ fontSize:24, fontWeight:800, color:'#fff', marginTop:2 }}>{selected.title}</div>
            </div>
          </div>
          <div style={{ padding:'18px' }}>
            <Row label="📅 Когда" val={`${selected.date} · ${selected.time}`} dark={dark}/>
            <Row label="📍 Где" val={`${selected.venue}, ${selected.city}`} dark={dark}/>
            <Row label="🎫 Цена" val={`от ${selected.price.toLocaleString('ru')} ₽`} dark={dark}/>

            <div style={{ marginTop:14, fontSize:12, color:sec, textTransform:'uppercase', letterSpacing:0.5, fontWeight:600 }}>Категория места</div>
            <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:8, marginTop:8 }}>
              {[
                ['Партер', selected.price+800, true],
                ['Танцпол', selected.price, false],
                ['Балкон', Math.round(selected.price*0.7), false],
                ['Vip', selected.price*2, false],
              ].map(([n,p,sel],i) => (
                <button key={i} className="press" style={{
                  background: sel ? 'rgba(124,92,255,0.15)' : surface,
                  border: sel ? '1.5px solid #7c5cff' : `1.5px solid ${dark?'#27272a':'#e4e4e7'}`,
                  borderRadius:10, padding:'10px 12px', textAlign:'left', cursor:'pointer',
                }}>
                  <div style={{ fontSize:13, fontWeight:600, color:text }}>{n}</div>
                  <div style={{ fontSize:12, color: sel?'#7c5cff':sec, marginTop:2, fontWeight:500 }}>{p.toLocaleString('ru')} ₽</div>
                </button>
              ))}
            </div>
          </div>
        </div>
        <div style={{ padding:'14px 18px 22px', borderTop:`1px solid ${dark?'#1a1a1c':'#ececee'}`, background:bg }}>
          <button onClick={() => setBought(selected)} className="press" style={{
            width:'100%', padding:'15px', background:'#7c5cff', color:'#fff', border:0,
            borderRadius:14, fontSize:15, fontWeight:700, cursor:'pointer',
            display:'flex', justifyContent:'space-between', alignItems:'center', padding:'15px 20px',
          }}>
            <span>Купить · 1 билет</span>
            <span>{(selected.price+800).toLocaleString('ru')} ₽</span>
          </button>
        </div>
      </WebAppSheet>
    );
  }

  return (
    <WebAppSheet title="Магазин · Касса" subtitle="koto.app/p/kassa" botColor="#7c5cff" onClose={onClose} dark={dark}>
      {/* Filter chips */}
      <div className="koto-scroll" style={{
        display:'flex', gap:6, padding:'10px 14px', overflowX:'auto', flexShrink:0,
        scrollbarWidth:'none',
      }}>
        {cats.map(c => (
          <button key={c} className="press" onClick={() => setFilter(c)} style={{
            background: filter===c ? '#7c5cff' : surface,
            color: filter===c ? '#fff' : text,
            border:0, padding:'7px 14px', borderRadius:18, fontSize:13, fontWeight:500,
            cursor:'pointer', whiteSpace:'nowrap', flexShrink:0,
          }}>{c}</button>
        ))}
      </div>
      <div className="koto-scroll" style={{ flex:1, overflowY:'auto', padding:'4px 14px 24px' }}>
        {events.map(ev => (
          <button key={ev.id} className="press" onClick={() => setSelected(ev)} style={{
            width:'100%', display:'flex', gap:12, background:surface, borderRadius:14, padding:12,
            marginBottom:10, cursor:'pointer', border:0, textAlign:'left',
          }}>
            <div style={{
              width:64, height:80, borderRadius:10, background:ev.cover, flexShrink:0,
              display:'flex', flexDirection:'column', alignItems:'center', justifyContent:'center', color:'#fff',
            }}>
              <div style={{ fontSize:20, fontWeight:800, lineHeight:1 }}>{ev.date.split(' ')[0]}</div>
              <div style={{ fontSize:9, opacity:0.8, marginTop:2, textTransform:'uppercase', letterSpacing:0.5 }}>{ev.date.split(' ')[1].slice(0,3)}</div>
            </div>
            <div style={{ flex:1, minWidth:0 }}>
              <div style={{ display:'flex', alignItems:'center', gap:6, marginBottom:2 }}>
                <span style={{ fontSize:10, color:sec, textTransform:'uppercase', letterSpacing:0.4, fontWeight:600 }}>{ev.kind}</span>
                {ev.hot && <span style={{ fontSize:9, background:'#ff3b30', color:'#fff', padding:'1px 5px', borderRadius:3, fontWeight:700 }}>🔥</span>}
              </div>
              <div style={{ fontSize:15, fontWeight:600, color:text, lineHeight:1.2, marginBottom:4 }}>{ev.title}</div>
              <div style={{ fontSize:12, color:sec, marginBottom:6 }}>{ev.venue} · {ev.time}</div>
              <div style={{ fontSize:13, fontWeight:700, color:'#7c5cff' }}>от {ev.price.toLocaleString('ru')} ₽</div>
            </div>
          </button>
        ))}
      </div>
    </WebAppSheet>
  );
}

function Row({ label, val, dark }) {
  return (
    <div style={{ display:'flex', justifyContent:'space-between', padding:'8px 0', borderBottom:`0.5px solid ${dark?'#27272a':'#ececee'}` }}>
      <div style={{ fontSize:13, color: dark?'#9e9e9e':'#707070' }}>{label}</div>
      <div style={{ fontSize:13, fontWeight:500, color: dark?'#fff':'#0a0a0a' }}>{val}</div>
    </div>
  );
}

function FauxQR() {
  // Pseudo-random fixed QR-like dots
  const cells = [];
  const pat = '1011010110100101101011010010110100101101011001011010110100101101';
  for (let y=0; y<10; y++) {
    for (let x=0; x<10; x++) {
      if (pat[(y*10+x)%pat.length] === '1') cells.push([x,y]);
    }
  }
  return (
    <svg width="120" height="120" viewBox="0 0 10 10">
      {cells.map(([x,y],i) => <rect key={i} x={x} y={y} width="0.95" height="0.95" fill="#0a0a0a"/>)}
      {/* corner blocks */}
      {[[0,0],[7,0],[0,7]].map(([x,y],i) => (
        <g key={i}>
          <rect x={x} y={y} width="3" height="3" fill="#0a0a0a"/>
          <rect x={x+0.6} y={y+0.6} width="1.8" height="1.8" fill="#fff"/>
          <rect x={x+1.2} y={y+1.2} width="0.6" height="0.6" fill="#0a0a0a"/>
        </g>
      ))}
    </svg>
  );
}

// ─── Generic WebApp sheet shell ───────────────────────────
function WebAppSheet({ title, subtitle, botColor, onClose, onBack, dark, children }) {
  return (
    <div style={{
      position:'absolute', inset:0, zIndex:80, animation:'sheetUp 320ms cubic-bezier(.2,.8,.2,1)',
    }}>
      {/* backdrop */}
      <div onClick={onClose} style={{ position:'absolute', inset:0, background:'rgba(0,0,0,0.4)', animation:'overlayIn 220ms' }}/>
      {/* sheet */}
      <div style={{
        position:'absolute', left:0, right:0, bottom:0, top:54,
        background: dark ? '#0b0b0c' : '#ffffff',
        borderRadius:'18px 18px 0 0', overflow:'hidden',
        display:'flex', flexDirection:'column',
        boxShadow:'0 -8px 32px rgba(0,0,0,0.3)',
      }}>
        {/* WebApp header — bot color stripe */}
        <div style={{
          padding:'10px 14px', display:'flex', alignItems:'center', gap:10,
          borderBottom:`1px solid ${dark?'#1a1a1c':'#ececee'}`,
          background: dark ? '#0b0b0c' : '#fff',
        }}>
          <div style={{ width:34, height:34, borderRadius:9, background:botColor, display:'flex', alignItems:'center', justifyContent:'center' }}>
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
              <rect x="3" y="6" width="18" height="14" rx="2" stroke="#fff" strokeWidth="1.8"/>
              <path d="M3 10h18" stroke="#fff" strokeWidth="1.8"/>
              <circle cx="6" cy="8" r="0.6" fill="#fff"/>
              <circle cx="8" cy="8" r="0.6" fill="#fff"/>
            </svg>
          </div>
          <div style={{ flex:1, minWidth:0 }}>
            <div style={{ fontSize:14, fontWeight:600, color:dark?'#fff':'#0a0a0a' }}>{title}</div>
            <div style={{ fontSize:11, color:dark?'#9e9e9e':'#707070', display:'flex', alignItems:'center', gap:4 }}>
              <Ico.Lock size={9} color={dark?'#9e9e9e':'#707070'}/>{subtitle}
            </div>
          </div>
          {onBack && (
            <button onClick={onBack} className="press" style={{ border:0, background:'transparent', cursor:'pointer', padding:6, color:botColor }}>
              <Ico.Back size={20} color={botColor}/>
            </button>
          )}
          <button onClick={onClose} className="press" style={{
            background: dark?'#27272a':'#ececee', border:0, padding:'6px 11px',
            borderRadius:14, fontSize:12.5, fontWeight:600, color:dark?'#fff':'#0a0a0a', cursor:'pointer',
          }}>Закрыть</button>
        </div>
        {children}
      </div>
    </div>
  );
}

// ─── BotForge — create your own bot ───────────────────────
function BotForgeScreen({ dark, onBack, onCreated }) {
  const [step, setStep] = useStateB(1); // 1 name → 2 username → 3 about → 4 done
  const [name, setName] = useStateB('');
  const [username, setUsername] = useStateB('');
  const [about, setAbout] = useStateB('');
  const [color, setColor] = useStateB('#ff6b35');
  const [token, setToken] = useStateB('');

  const text = dark ? '#fff' : '#0a0a0a';
  const sec  = dark ? '#9e9e9e' : '#707070';
  const bg   = dark ? '#0b0b0c' : '#fff';
  const surface = dark ? '#1a1a1c' : '#f6f6f7';

  const colors = ['#ff6b35','#7c5cff','#34c759','#3276ff','#ff2d55','#ffc940','#5ac8fa','#af52de'];

  const validUser = /^[a-z0-9_]{4,}_bot$/i.test(username);

  const finish = () => {
    // Generate fake bot token
    const t = '7' + Math.floor(Math.random()*1e9).toString().padStart(9,'0') + ':AAH-' +
      Array.from({length:24},()=>Math.random().toString(36)[2]||'a').join('');
    setToken(t);
    setStep(4);
  };

  return (
    <div style={{ height:'100%', background:bg, color:text, display:'flex', flexDirection:'column', overflow:'hidden' }}>
      {/* Header */}
      <div style={{ paddingTop:54, padding:'54px 14px 4px', display:'flex', alignItems:'center', gap:6 }}>
        <button onClick={onBack} className="press" style={{ border:0, background:'transparent', cursor:'pointer', padding:6, color:'var(--accent)', display:'flex', alignItems:'center' }}>
          <Ico.Back size={22} color="var(--accent)"/>
        </button>
        <div style={{ flex:1, fontSize:17, fontWeight:600, textAlign:'center', marginRight:34 }}>BotForge</div>
      </div>

      {/* Progress */}
      <div style={{ padding:'14px 20px 18px' }}>
        <div style={{ display:'flex', gap:6 }}>
          {[1,2,3,4].map(s => (
            <div key={s} style={{
              flex:1, height:3, borderRadius:2,
              background: s <= step ? 'var(--accent)' : (dark?'#27272a':'#e4e4e7'),
              transition:'background 280ms',
            }}/>
          ))}
        </div>
        <div style={{ fontSize:11, color:sec, marginTop:8, letterSpacing:0.4, textTransform:'uppercase', fontWeight:600 }}>Шаг {step} из 4</div>
      </div>

      <div className="koto-scroll" style={{ flex:1, overflowY:'auto', padding:'0 20px 24px' }}>
        {/* Step 1 — name */}
        {step===1 && (
          <div style={{ animation:'liftIn 360ms cubic-bezier(.2,.8,.2,1)' }}>
            <ForgeStepHeader emoji="🤖" title="Как назовём бота?" sub="Это имя увидят пользователи в чатах." dark={dark}/>
            <input value={name} onChange={e=>setName(e.target.value)} maxLength={32} placeholder="например: Pizza Bot"
              autoFocus
              style={inp(dark)}/>
            <div style={{ fontSize:11, color:sec, textAlign:'right', marginTop:4 }}>{name.length}/32</div>

            <div style={{ fontSize:13, color:sec, marginTop:18, marginBottom:8 }}>Цвет аватара</div>
            <div style={{ display:'flex', gap:10, flexWrap:'wrap' }}>
              {colors.map(c => (
                <button key={c} onClick={()=>setColor(c)} className="press" style={{
                  width:36, height:36, borderRadius:'50%', background:c, border:0, cursor:'pointer',
                  outline: color===c ? `2.5px solid ${dark?'#fff':'#0a0a0a'}` : 'none',
                  outlineOffset: 2,
                }}/>
              ))}
            </div>

            {/* Live preview */}
            {name && (
              <div style={{ marginTop:24, padding:14, background:surface, borderRadius:14, display:'flex', gap:12, alignItems:'center' }}>
                <Avatar contact={{ initials: name.slice(0,2).toUpperCase(), color }} size={48}/>
                <div style={{ flex:1 }}>
                  <div style={{ fontSize:14.5, fontWeight:600 }}>{name}</div>
                  <div style={{ fontSize:11.5, color:sec, marginTop:1, display:'flex', alignItems:'center', gap:4 }}>
                    <span style={{ background:color, color:'#fff', fontSize:8, fontWeight:800, padding:'1px 4px', borderRadius:3, letterSpacing:0.4 }}>BOT</span>
                    предпросмотр
                  </div>
                </div>
              </div>
            )}
          </div>
        )}

        {/* Step 2 — username */}
        {step===2 && (
          <div style={{ animation:'liftIn 360ms cubic-bezier(.2,.8,.2,1)' }}>
            <ForgeStepHeader emoji="@" title="Выберите username" sub="Должен оканчиваться на _bot. Используется в @упоминаниях." dark={dark}/>
            <div style={{ position:'relative' }}>
              <span style={{ position:'absolute', left:14, top:'50%', transform:'translateY(-50%)', color:sec, fontSize:16 }}>@</span>
              <input value={username} onChange={e=>setUsername(e.target.value.toLowerCase())} placeholder="pizza_bot"
                autoFocus
                style={{...inp(dark), paddingLeft:30}}/>
            </div>
            <div style={{ fontSize:11.5, color: username && !validUser ? '#ff3b30' : sec, marginTop:6 }}>
              {username && !validUser ? 'Только латиница/цифры/_, оканчивается на _bot, ≥4 знаков' : 'Например: pizza_bot, weather_bot'}
            </div>

            {validUser && (
              <div style={{
                marginTop:18, padding:'12px 14px', background:'rgba(52,199,89,0.1)',
                border:'1px solid rgba(52,199,89,0.3)', borderRadius:10,
                display:'flex', alignItems:'center', gap:10, fontSize:13, color:'#34c759',
              }}>
                <Ico.CheckCircle size={18} color="#34c759"/>
                username свободен
              </div>
            )}
          </div>
        )}

        {/* Step 3 — about */}
        {step===3 && (
          <div style={{ animation:'liftIn 360ms cubic-bezier(.2,.8,.2,1)' }}>
            <ForgeStepHeader emoji="📝" title="Описание" sub="Появится в карточке бота и при первом запуске." dark={dark}/>
            <textarea value={about} onChange={e=>setAbout(e.target.value)} maxLength={120} rows={4}
              placeholder="например: заказывает пиццу за 30 секунд."
              autoFocus
              style={{...inp(dark), minHeight:90, resize:'none', fontFamily:'inherit'}}/>
            <div style={{ fontSize:11, color:sec, textAlign:'right', marginTop:4 }}>{about.length}/120</div>
          </div>
        )}

        {/* Step 4 — done */}
        {step===4 && (
          <div style={{ animation:'liftIn 360ms cubic-bezier(.2,.8,.2,1)', textAlign:'center', paddingTop:10 }}>
            <div style={{
              width:96, height:96, borderRadius:24, background:color, margin:'0 auto 16px',
              display:'flex', alignItems:'center', justifyContent:'center',
              boxShadow:`0 16px 40px ${color}55`,
              animation:'fadeInScale 480ms cubic-bezier(.2,.8,.2,1)',
            }}>
              <div style={{ fontSize:40, color:'#fff', fontWeight:700 }}>{name.slice(0,2).toUpperCase()}</div>
            </div>
            <div style={{ fontSize:22, fontWeight:700 }}>Готово! 🎉</div>
            <div style={{ fontSize:14, color:sec, marginTop:6, marginBottom:18 }}>Ваш бот @{username} создан</div>
            <div style={{
              background:surface, borderRadius:12, padding:'14px', textAlign:'left',
              border:`1px solid ${dark?'#27272a':'#e4e4e7'}`,
            }}>
              <div style={{ fontSize:11, color:sec, textTransform:'uppercase', letterSpacing:0.5, fontWeight:600, marginBottom:6 }}>Bot Token</div>
              <div className="mono" style={{ fontSize:11, lineHeight:1.5, wordBreak:'break-all', color:text, padding:'8px 10px', background:dark?'#0b0b0c':'#fff', borderRadius:8 }}>{token}</div>
              <div style={{ fontSize:11.5, color:'#ff3b30', marginTop:8, display:'flex', gap:5 }}>
                <span>⚠️</span><span>Никому не показывайте этот токен. С его помощью можно управлять ботом.</span>
              </div>
            </div>
            <div style={{ display:'flex', gap:8, marginTop:18 }}>
              <button className="press" style={{
                flex:1, padding:'12px', background:surface, color:text, border:0,
                borderRadius:12, fontSize:13.5, fontWeight:500, cursor:'pointer',
              }}>Скопировать токен</button>
              <button className="press" style={{
                flex:1, padding:'12px', background:surface, color:text, border:0,
                borderRadius:12, fontSize:13.5, fontWeight:500, cursor:'pointer',
              }}>Открыть docs</button>
            </div>
          </div>
        )}
      </div>

      {/* CTA */}
      {step < 4 && (
        <div style={{ padding:'10px 20px 22px', borderTop:`1px solid ${dark?'#1a1a1c':'#ececee'}` }}>
          <button className="press"
            disabled={(step===1 && !name.trim()) || (step===2 && !validUser)}
            onClick={() => step===3 ? finish() : setStep(step+1)}
            style={{
              width:'100%', padding:14, background:'var(--accent)', color:'#fff', border:0,
              borderRadius:14, fontSize:15, fontWeight:600, cursor:'pointer',
              opacity: ((step===1 && !name.trim()) || (step===2 && !validUser)) ? 0.4 : 1,
            }}>{step===3 ? 'Создать бота' : 'Дальше'}</button>
        </div>
      )}
      {step===4 && (
        <div style={{ padding:'10px 20px 22px', borderTop:`1px solid ${dark?'#1a1a1c':'#ececee'}` }}>
          <button className="press" onClick={() => onCreated && onCreated({ name, username, color, about })} style={{
            width:'100%', padding:14, background:'var(--accent)', color:'#fff', border:0,
            borderRadius:14, fontSize:15, fontWeight:600, cursor:'pointer',
          }}>Открыть чат с ботом</button>
        </div>
      )}
    </div>
  );
}

function ForgeStepHeader({ emoji, title, sub, dark }) {
  return (
    <div style={{ marginBottom:16 }}>
      <div style={{ fontSize:34, marginBottom:6 }}>{emoji}</div>
      <div style={{ fontSize:22, fontWeight:700, letterSpacing:-0.5 }}>{title}</div>
      <div style={{ fontSize:13.5, color: dark?'#9e9e9e':'#707070', marginTop:4, lineHeight:1.4 }}>{sub}</div>
    </div>
  );
}

const inp = (dark) => ({
  width:'100%', padding:'13px 14px', fontSize:16,
  background: dark?'#1a1a1c':'#f6f6f7',
  border:`1px solid ${dark?'#27272a':'#e4e4e7'}`, borderRadius:12,
  color: dark?'#fff':'#0a0a0a', outline:'none', boxSizing:'border-box',
  fontFamily:'inherit',
});

// ─── Bot Catalog (browse + open) ──────────────────────────
function BotCatalogScreen({ dark, onBack, onOpenBot, onOpenForge }) {
  const text = dark ? '#fff' : '#0a0a0a';
  const sec  = dark ? '#9e9e9e' : '#707070';
  const bg   = dark ? '#0b0b0c' : '#fff';
  const surface = dark ? '#1a1a1c' : '#f6f6f7';

  return (
    <div style={{ height:'100%', background:bg, color:text, display:'flex', flexDirection:'column' }}>
      <div style={{ paddingTop:54, padding:'54px 14px 4px', display:'flex', alignItems:'center' }}>
        <button onClick={onBack} className="press" style={{ border:0, background:'transparent', cursor:'pointer', padding:6, color:'var(--accent)', display:'flex', alignItems:'center' }}>
          <Ico.Back size={22} color="var(--accent)"/>
        </button>
        <div style={{ flex:1 }}/>
      </div>
      <div style={{ padding:'4px 20px 16px' }}>
        <div style={{ fontSize:30, fontWeight:800, letterSpacing:-0.8 }}>Боты</div>
        <div style={{ fontSize:13, color:sec, marginTop:2 }}>Расширьте Koto под себя</div>
      </div>
      <div className="koto-scroll" style={{ flex:1, overflowY:'auto', padding:'0 14px 80px' }}>
        {/* Build your own CTA */}
        <button onClick={onOpenForge} className="press" style={{
          width:'100%', display:'flex', alignItems:'center', gap:14, padding:'14px',
          background:'linear-gradient(135deg, #ff6b35, #ff2d55)', color:'#fff',
          border:0, borderRadius:14, cursor:'pointer', marginBottom:14, textAlign:'left',
          boxShadow:'0 8px 24px rgba(255,107,53,0.25)',
        }}>
          <div style={{ width:46, height:46, borderRadius:12, background:'rgba(255,255,255,0.18)', display:'flex', alignItems:'center', justifyContent:'center', fontSize:24 }}>🛠</div>
          <div style={{ flex:1 }}>
            <div style={{ fontSize:15, fontWeight:700 }}>Создать своего бота</div>
            <div style={{ fontSize:12, opacity:0.85, marginTop:2 }}>BotForge · 30 сек до первого токена</div>
          </div>
          <Ico.ChevronRight size={18} color="#fff"/>
        </button>

        <div style={{ fontSize:11, color:sec, padding:'10px 6px 6px', textTransform:'uppercase', letterSpacing:0.5, fontWeight:600 }}>Популярные</div>
        {KOTO_BOTS.map(bot => (
          <button key={bot.id} onClick={() => onOpenBot && onOpenBot(bot.id)} className="press" style={{
            width:'100%', display:'flex', alignItems:'center', gap:12, padding:'12px',
            background:surface, border:0, borderRadius:14, cursor:'pointer', marginBottom:8, textAlign:'left',
          }}>
            <Avatar contact={bot} size={48}/>
            <div style={{ flex:1, minWidth:0 }}>
              <div style={{ fontSize:14.5, fontWeight:600, color:text, display:'flex', alignItems:'center', gap:4 }}>
                {bot.name}
                {bot.verified && <VerifiedTick color={bot.color}/>}
                <span style={{ background:bot.color, color:'#fff', fontSize:8, fontWeight:800, padding:'1px 4px', borderRadius:3, letterSpacing:0.4, marginLeft:2 }}>BOT</span>
              </div>
              <div style={{ fontSize:12, color:sec, marginTop:2, lineHeight:1.3, overflow:'hidden', textOverflow:'ellipsis', display:'-webkit-box', WebkitLineClamp:2, WebkitBoxOrient:'vertical' }}>{bot.tagline}</div>
              <div style={{ fontSize:11, color:sec, marginTop:4, display:'flex', gap:8 }}>
                <span>{bot.category}</span>
                <span>·</span>
                <span>{bot.users}</span>
              </div>
            </div>
          </button>
        ))}
      </div>
    </div>
  );
}

window.BotIntroCard = BotIntroCard;
window.BotKeyboard = BotKeyboard;
window.BotCard = BotCard;
window.PawketBoardSheet = PawketBoardSheet;
window.KassaShopSheet = KassaShopSheet;
window.BotForgeScreen = BotForgeScreen;
window.BotCatalogScreen = BotCatalogScreen;
window.VerifiedTick = VerifiedTick;
