/* global React, Ico, IC, Avatar, getContact */
// Settings.jsx — multi-section settings (Signal-style)

const { useState: useStateS } = React;

function SettingsScreen({ dark, onBack, onToggleTheme, onOpenSection, profile, onLogout }) {
  const bg = dark ? '#0b0b0c' : '#f2f2f2';
  const card = dark ? '#1a1a1c' : '#ffffff';
  const text = dark ? '#fff' : '#0a0a0a';
  const sec = dark ? '#9e9e9e' : '#707070';

  return (
    <div style={{ height: '100%', background: bg, color: text, overflow: 'auto' }} className="koto-scroll">
      <div style={{ paddingTop: 59, padding: '59px 16px 0', display: 'flex', alignItems: 'center', gap: 4, paddingRight: 16 }}>
        <button onClick={onBack} className="press" style={{ border:0, background:'transparent', padding:'10px 6px', cursor:'pointer', display:'flex', alignItems:'center', gap:2, color:'var(--accent)' }}>
          <Ico.Back size={26} color="var(--accent)" />
          <span style={{ fontSize: 17, fontWeight: 400 }}>Чаты</span>
        </button>
        <div style={{ flex: 1 }} />
        <button onClick={onToggleTheme} className="press" style={{
          width: 38, height: 38, borderRadius: '50%', border: 0, background: card, cursor: 'pointer',
          display: 'flex', alignItems: 'center', justifyContent: 'center', color: text, fontSize: 16,
        }}>
          {dark ? '☀' : '◐'}
        </button>
      </div>

      <div style={{ padding: '6px 20px 20px' }}>
        <div style={{ fontSize: 34, fontWeight: 800, letterSpacing: -1, lineHeight: 1.05 }}>Настройки</div>
      </div>

      <div
        onClick={() => onOpenSection('profile')}
        className="press"
        style={{
          margin: '0 16px 16px', background: card, borderRadius: 18,
          padding: '16px 14px', display: 'flex', alignItems: 'center', gap: 12, cursor: 'pointer',
        }}
      >
        <Avatar contact={{ initials: (profile?.name?.[0] || 'Я').toUpperCase(), color: 'var(--accent)' }} size={60} />
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ fontSize: 19, fontWeight: 700, letterSpacing: -0.3 }}>{profile?.name || 'Дмитрий К.'}</div>
          <div className="mono" style={{ fontSize: 11, color: sec, marginTop: 4, letterSpacing: 0.3, overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap' }}>
            {(profile?.kotoId || '05a9f2c4e7b1d038f5c26e9a48103b5d7c91e2d64a58fc03bd917e4a62c85b71f0').slice(0,16)}…
          </div>
          <div style={{ fontSize: 12, color: 'var(--accent)', marginTop: 6, display: 'flex', alignItems: 'center', gap: 4 }}>
            <Ico.Lock size={10} color="var(--accent)"/> ключи на устройстве
          </div>
        </div>
      </div>

      <Section label="Аккаунт" dark={dark}>
        <Row ic={<IC.KotoId/>} title="Мой Koto ID" detail="скопировать" onClick={() => onOpenSection('kotoid')} dark={dark} />
        <Row ic={<IC.Seed/>} title="Фраза восстановления" detail="13 слов" onClick={() => onOpenSection('seed')} dark={dark} />
        <Row ic={<IC.Devices/>} title="Связанные устройства" detail="2" onClick={() => onOpenSection('devices')} dark={dark} />
        <Row ic={<IC.Username/>} title="Имя пользователя" detail="@dmitry" isLast onClick={() => onOpenSection('username')} dark={dark} />
      </Section>

      <Section label="Приватность" dark={dark}>
        <Row ic={<IC.Privacy/>} title="Приватность" detail="стандартно" onClick={() => onOpenSection('privacy')} dark={dark} />
        <Row ic={<IC.Ephemeral/>} title="Исчезающие сообщения" detail="выкл" onClick={() => onOpenSection('ephemeral')} dark={dark} />
        <Row ic={<IC.ScreenLock/>} title="Блокировка экрана" detail="Face ID" onClick={() => onOpenSection('screenlock')} dark={dark} />
        <Row ic={<IC.Safety/>} title="Проверка безопасности" onClick={() => onOpenSection('safety')} dark={dark} />
        <Row ic={<IC.Sealed/>} title="Закрытые отправители" detail="вкл" isLast onClick={() => onOpenSection('sealed')} dark={dark} />
      </Section>

      <Section label="Данные и хранилище" dark={dark}>
        <Row ic={<IC.Storage/>} title="Хранилище" detail="2.4 ГБ" onClick={() => onOpenSection('storage')} dark={dark} />
        <Row ic={<IC.Network/>} title="Использование сети" detail="12.8 МБ / мес" onClick={() => onOpenSection('network')} dark={dark} />
        <Row ic={<IC.AutoDL/>} title="Автозагрузка" detail="Wi-Fi · Фото" isLast onClick={() => onOpenSection('auto')} dark={dark} />
      </Section>

      <Section label="Внешний вид" dark={dark}>
        <Row ic={<IC.Theme/>} title="Тема и цвет" detail={dark ? 'Тёмная' : 'Светлая'} onClick={() => onOpenSection('theme')} dark={dark} />
        <Row ic={<IC.Font/>} title="Размер шрифта" detail="обычный" onClick={() => onOpenSection('font')} dark={dark} />
        <Row ic={<IC.Wallpaper/>} title="Обои чатов" detail="Koto · оранжевый" isLast onClick={() => onOpenSection('wallpaper')} dark={dark} />
      </Section>

      <Section label="Уведомления и звонки" dark={dark}>
        <Row ic={<IC.Bell/>} title="Уведомления" detail="вкл" onClick={() => onOpenSection('notifications')} dark={dark} />
        <Row ic={<IC.Calls/>} title="Звонки" detail="Koto + iOS" isLast onClick={() => onOpenSection('calls')} dark={dark} />
      </Section>

      <Section label="Поддержка" dark={dark}>
        <Row ic={<IC.Help/>} title="Справка" onClick={() => onOpenSection('help')} dark={dark} />
        <Row ic={<IC.About/>} title="О Koto" detail="26.4.1" isLast onClick={() => onOpenSection('about')} dark={dark} />
      </Section>

      <Section label="" dark={dark}>
        <Row ic={<IC.Logout/>} title="Выйти из Koto ID" danger isLast onClick={onLogout} dark={dark} />
      </Section>

      <div style={{ textAlign: 'center', padding: '12px 20px 32px', color: sec, fontSize: 12.5 }}>
        Koto 26.4.1 · защита от края до края
      </div>
    </div>
  );
}

function Section({ label, children, dark }) {
  const sec = dark ? '#9e9e9e' : '#707070';
  const card = dark ? '#1a1a1c' : '#ffffff';
  return (
    <div style={{ marginBottom: 22 }}>
      {label && <div style={{ padding: '0 24px 6px', fontSize: 12, fontWeight: 600, color: sec, textTransform: 'uppercase', letterSpacing: 0.6 }}>{label}</div>}
      <div style={{ margin: '0 16px', background: card, borderRadius: 16, overflow: 'hidden' }}>
        {children}
      </div>
    </div>
  );
}

function Row({ ic, title, detail, isLast, onClick, dark, danger }) {
  const text = dark ? '#fff' : '#0a0a0a';
  const sec = dark ? '#9e9e9e' : '#707070';
  const sep = dark ? 'rgba(255,255,255,0.06)' : 'rgba(0,0,0,0.06)';
  return (
    <div onClick={onClick} className="press" style={{
      display: 'flex', alignItems: 'center', gap: 12,
      padding: '10px 14px', cursor: 'pointer', minHeight: 48, position: 'relative',
    }}>
      {ic}
      <div style={{ flex: 1, fontSize: 15.5, color: danger ? '#ff453a' : text, letterSpacing: -0.2 }}>{title}</div>
      {detail && <div style={{ fontSize: 14, color: sec, letterSpacing: -0.1 }}>{detail}</div>}
      <Ico.Chevron size={14} color={dark ? '#5e5e62' : '#c7c7cc'} />
      {!isLast && <div style={{ position: 'absolute', bottom: 0, left: 56, right: 0, height: 0.5, background: sep }} />}
    </div>
  );
}

window.SettingsScreen = SettingsScreen;
