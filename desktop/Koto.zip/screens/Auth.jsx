/* global React, Ico, Avatar, getContact */
// Auth screens: Welcome, Register (seed words), Login (paste recovery)

const { useState: useStateAu, useEffect: useEffectAu, useRef: useRefAu } = React;

// BIP39-ish-looking Russian word pool (original, not the real BIP39 list)
const KOTO_WORDS = [
  'абрикос','берёза','ветер','гранит','дождь','ёлка','жёлудь','звезда',
  'игла','йогурт','кедр','лавина','метель','нить','облако','парус',
  'ракита','солнце','туман','ураган','фиалка','хвоя','цапля','чайка',
  'шалфей','щавель','эхо','юла','ясень','алмаз','бриз','волна',
  'гроза','дюна','ель','жасмин','заря','ива','камыш','луна',
  'мята','норка','осина','пихта','река','снег','терн','утёс',
  'фонарь','холм','цветок','череда','шишка','щегол','эфир','ягель',
];

function pickSeed(n = 13) {
  const pool = [...KOTO_WORDS];
  const out = [];
  for (let i = 0; i < n; i++) {
    const idx = Math.floor(Math.random() * pool.length);
    out.push(pool.splice(idx, 1)[0]);
  }
  return out;
}

// Derive a fake Koto ID (66 hex-like chars) from seed words
function deriveKotoId(words) {
  let h = 0;
  const joined = words.join(' ');
  for (let i = 0; i < joined.length; i++) h = ((h << 5) - h + joined.charCodeAt(i)) | 0;
  const chars = '0123456789abcdef';
  let s = '05'; // session-style prefix
  let x = Math.abs(h);
  for (let i = 0; i < 64; i++) {
    x = (x * 1103515245 + 12345 + i * 7) & 0x7fffffff;
    s += chars[x & 0xf];
  }
  return s;
}

// Shared textured background layer for auth screens
function AuthBackdrop({ dark }) {
  const base = dark
    ? 'radial-gradient(120% 80% at 50% 0%, #2a1a12 0%, #141013 45%, #0a0809 100%)'
    : 'radial-gradient(120% 80% at 50% 0%, #ffe3d3 0%, #fff6ef 40%, #f4ece3 100%)';
  const glowA = dark ? 'rgba(255,107,53,0.22)' : 'rgba(255,107,53,0.30)';
  const glowB = dark ? 'rgba(124,92,255,0.14)' : 'rgba(124,92,255,0.16)';
  const gridCol = dark ? 'rgba(255,255,255,0.035)' : 'rgba(10,10,10,0.035)';

  return (
    <div style={{ position:'absolute', inset:0, overflow:'hidden', pointerEvents:'none' }}>
      {/* base */}
      <div style={{ position:'absolute', inset:0, background: base }}/>
      {/* soft color blobs */}
      <div style={{
        position:'absolute', width:360, height:360, left:-110, top:-60, borderRadius:'50%',
        background:`radial-gradient(circle at center, ${glowA} 0%, transparent 65%)`,
        filter:'blur(8px)',
      }}/>
      <div style={{
        position:'absolute', width:340, height:340, right:-130, top:180, borderRadius:'50%',
        background:`radial-gradient(circle at center, ${glowB} 0%, transparent 65%)`,
        filter:'blur(10px)',
      }}/>
      {/* subtle grid */}
      <div style={{
        position:'absolute', inset:0, opacity: dark?0.5:0.7,
        backgroundImage:`linear-gradient(${gridCol} 1px, transparent 1px), linear-gradient(90deg, ${gridCol} 1px, transparent 1px)`,
        backgroundSize:'28px 28px',
        maskImage:'radial-gradient(120% 90% at 50% 40%, #000 50%, transparent 100%)',
        WebkitMaskImage:'radial-gradient(120% 90% at 50% 40%, #000 50%, transparent 100%)',
      }}/>
      {/* grain */}
      <div style={{
        position:'absolute', inset:0, opacity: dark?0.22:0.18, mixBlendMode:'overlay',
        backgroundImage:"url(\"data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='200' height='200'><filter id='n'><feTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='2' stitchTiles='stitch'/><feColorMatrix values='0 0 0 0 0  0 0 0 0 0  0 0 0 0 0  0 0 0 0.6 0'/></filter><rect width='100%25' height='100%25' filter='url(%23n)'/></svg>\")",
      }}/>
    </div>
  );
}

// Koto logo — cat image on a rounded tile
function KotoLogo({ size=96 }) {
  return (
    <div style={{
      width:size, height:size, borderRadius: size*0.26,
      background:'linear-gradient(160deg, #ff8656 0%, #ff6b35 60%, #e5531e 100%)',
      display:'flex', alignItems:'center', justifyContent:'center',
      boxShadow:'0 18px 44px rgba(255,107,53,0.45), 0 2px 0 rgba(255,255,255,0.25) inset, 0 -2px 0 rgba(0,0,0,0.1) inset',
      animation:'fadeScaleIn 560ms cubic-bezier(.2,.8,.2,1)',
      position:'relative', overflow:'hidden',
    }}>
      <img src="assets/koto-cat.png" alt="Koto" style={{
        width: size*0.82, height: size*0.82, objectFit:'contain',
        filter:'drop-shadow(0 3px 6px rgba(0,0,0,0.25))',
      }}/>
    </div>
  );
}

// ─── Welcome ─────────────────────────────────────────────
function WelcomeScreen({ dark, onCreate, onRestore }) {
  const text = dark ? '#fff' : '#0a0a0a';
  const sec = dark ? '#c9b9ad' : '#7a6b60';

  return (
    <div style={{
      position:'relative',
      height:'100%', color:text,
      display:'flex', flexDirection:'column',
      padding: '0 28px',
    }}>
      <AuthBackdrop dark={dark}/>

      <div style={{ position:'relative', flex: 1, display:'flex', flexDirection:'column', alignItems:'center', justifyContent:'center', textAlign:'center' }}>
        <KotoLogo size={104}/>
        <div style={{ fontSize:46, fontWeight:800, letterSpacing:-1.6, lineHeight:1.02, marginTop:26 }}>
          Koto.
        </div>
        <div style={{ fontSize:18, fontWeight:500, color:sec, letterSpacing:-0.3, marginTop:12, lineHeight:1.35 }}>
          Без телефона.<br/>
          Без e-mail.<br/>
          <span style={{ color: text }}>Только ваш Koto&nbsp;ID.</span>
        </div>
        <div style={{
          marginTop:26, padding:'11px 14px', borderRadius:14,
          background: dark?'rgba(20,16,19,0.6)':'rgba(255,255,255,0.7)',
          backdropFilter:'blur(14px)', WebkitBackdropFilter:'blur(14px)',
          border:`0.5px solid ${dark?'rgba(255,107,53,0.35)':'rgba(255,107,53,0.4)'}`,
          display:'inline-flex', alignItems:'center', gap:10,
        }}>
          <Ico.Lock size={14} color="var(--accent)"/>
          <div style={{ fontSize:12, color:text, lineHeight:1.4, letterSpacing:-0.1 }}>
            ключи генерируются на устройстве
          </div>
        </div>
      </div>

      <div style={{ position:'relative', padding:'0 0 44px', display:'flex', flexDirection:'column', gap:10 }}>
        <button onClick={onCreate} className="press" style={{
          border:0, cursor:'pointer',
          background:'var(--accent)', color:'#fff',
          padding:'16px 18px', borderRadius:16,
          fontSize:16, fontWeight:600, letterSpacing:-0.2,
          boxShadow:'0 8px 22px rgba(255,107,53,0.45)',
        }}>Создать новый Koto ID</button>
        <button onClick={onRestore} className="press" style={{
          border:0, cursor:'pointer',
          background: dark?'rgba(255,255,255,0.06)':'rgba(255,255,255,0.6)',
          backdropFilter:'blur(14px)', WebkitBackdropFilter:'blur(14px)',
          color:'var(--accent)',
          padding:'15px 18px', borderRadius:16,
          fontSize:15.5, fontWeight:600,
        }}>Восстановить по фразе</button>
        <div style={{ textAlign:'center', fontSize:11.5, color:sec, marginTop:6, lineHeight:1.5 }}>
          создавая аккаунт, вы соглашаетесь с тем,<br/>
          что ключи хранятся только у вас
        </div>
      </div>
    </div>
  );
}

// ─── Register ────────────────────────────────────────────
function RegisterScreen({ dark, onBack, onDone }) {
  const bg = dark ? '#0b0b0c' : '#ffffff';
  const surface = dark ? '#1a1a1c' : '#f2f2f2';
  const text = dark ? '#fff' : '#0a0a0a';
  const sec = dark ? '#9e9e9e' : '#707070';

  const [step, setStep] = useStateAu(0); // 0 display seed, 1 confirm, 2 name
  const [seed] = useStateAu(() => pickSeed(13));
  const kotoId = deriveKotoId(seed);

  // confirm step — user must tap three positions in right order
  const positions = [2, 6, 10];
  const [confirmed, setConfirmed] = useStateAu([]);
  const [confirmWrong, setConfirmWrong] = useStateAu(false);
  const choices = React.useMemo(() => {
    const targetWord = seed[positions[confirmed.length]];
    if (!targetWord) return [];
    const fakes = KOTO_WORDS.filter(w => !seed.includes(w)).sort(()=>Math.random()-0.5).slice(0,3);
    return [targetWord, ...fakes].sort(()=>Math.random()-0.5);
  }, [confirmed.length]);

  const [name, setName] = useStateAu('');
  const [copied, setCopied] = useStateAu(false);

  const pickConfirm = (w) => {
    const expected = seed[positions[confirmed.length]];
    if (w === expected) {
      const next = [...confirmed, w];
      setConfirmed(next);
      setConfirmWrong(false);
      if (next.length === positions.length) setTimeout(()=>setStep(2), 400);
    } else {
      setConfirmWrong(true);
      setTimeout(()=>setConfirmWrong(false), 600);
    }
  };

  const cardBg = dark ? 'rgba(20,16,19,0.72)' : 'rgba(255,255,255,0.78)';
  const cardBorder = dark ? 'rgba(255,255,255,0.08)' : 'rgba(10,10,10,0.06)';

  return (
    <div style={{ position:'relative', height:'100%', color:text, display:'flex', flexDirection:'column' }}>
      <AuthBackdrop dark={dark}/>

      <div style={{ position:'relative', paddingTop:59, padding:'59px 12px 4px', display:'flex', alignItems:'center' }}>
        <button onClick={step>0 ? () => setStep(step-1) : onBack} className="press" style={{ border:0, background:'transparent', cursor:'pointer', padding:8, color:'var(--accent)', display:'flex', alignItems:'center' }}>
          <Ico.Back size={24} color="var(--accent)"/>
        </button>
        <div style={{ flex:1, textAlign:'center', fontSize:13, fontWeight:600, color:sec, letterSpacing:0.3, textTransform:'uppercase' }}>
          шаг {step+1} из 3
        </div>
        <div style={{ width:40 }}/>
      </div>
      {/* progress */}
      <div style={{ position:'relative', padding:'6px 24px 0', display:'flex', gap:6 }}>
        {[0,1,2].map(i => (
          <div key={i} style={{
            flex:1, height:3, borderRadius:2,
            background: i <= step ? 'var(--accent)' : (dark?'rgba(255,255,255,0.10)':'rgba(10,10,10,0.10)'),
            transition:'background 280ms',
          }}/>
        ))}
      </div>

      <div className="koto-scroll" style={{
        position:'relative', flex:1, overflow:'auto',
        padding:'24px 20px 24px',
        display:'flex', flexDirection:'column', alignItems:'center', justifyContent:'flex-start',
      }}>
        <div style={{ width:'100%', maxWidth:340, display:'flex', flexDirection:'column', alignItems:'center' }}>

        {step === 0 && (
          <>
            <KotoLogo size={64}/>
            <div style={{ fontSize:26, fontWeight:800, letterSpacing:-0.8, lineHeight:1.12, marginTop:18, textAlign:'center' }}>
              Ваша фраза<br/>восстановления
            </div>
            <div style={{ fontSize:13, color:sec, marginTop:10, lineHeight:1.5, textAlign:'center', maxWidth:300 }}>
              13 слов — это и есть ваш аккаунт. Запишите их по порядку. Кто знает фразу — управляет Koto&nbsp;ID.
            </div>

            <div style={{
              width:'100%',
              marginTop:20, background:cardBg,
              backdropFilter:'blur(14px)', WebkitBackdropFilter:'blur(14px)',
              border:`1px solid ${cardBorder}`,
              borderRadius:18, padding:16,
              display:'grid', gridTemplateColumns:'1fr 1fr', gap:'10px 14px',
              boxShadow:'0 10px 30px rgba(0,0,0,0.08)',
            }}>
              {seed.map((w,i) => (
                <div key={i} style={{ display:'flex', alignItems:'baseline', gap:7 }}>
                  <span className="mono" style={{ fontSize:10.5, color:sec, width:16, textAlign:'right' }}>{i+1}</span>
                  <span style={{ fontSize:15, fontWeight:600, letterSpacing:-0.1 }}>{w}</span>
                </div>
              ))}
            </div>

            <button onClick={()=>{ navigator.clipboard && navigator.clipboard.writeText(seed.join(' ')); setCopied(true); setTimeout(()=>setCopied(false),1500); }}
              className="press"
              style={{
                marginTop:8, border:0, cursor:'pointer',
                background:'transparent', color:'var(--accent)',
                padding:'10px', fontSize:14, fontWeight:500,
              }}>
              {copied ? '✓ скопировано' : 'скопировать фразу'}
            </button>

            <div style={{
              width:'100%',
              marginTop:6, padding:'12px 14px', borderRadius:12,
              background: dark?'rgba(255,59,48,0.12)':'rgba(255,59,48,0.09)',
              border:`0.5px solid ${dark?'rgba(255,100,92,0.35)':'rgba(255,59,48,0.3)'}`,
              fontSize:12.5, color: dark?'#ffaaa0':'#c42e24', lineHeight:1.45,
              display:'flex', gap:8,
            }}>
              <div style={{ fontSize:16, lineHeight:1 }}>⚠</div>
              <div>Никогда не пересылайте фразу в чатах, почте или облаке. Восстановление невозможно.</div>
            </div>
          </>
        )}

        {step === 1 && (
          confirmed.length < positions.length ? (
            <>
              <div style={{ fontSize:26, fontWeight:800, letterSpacing:-0.8, lineHeight:1.12, marginTop:4, textAlign:'center' }}>
                Сверим фразу
              </div>
              <div style={{ fontSize:13, color:sec, marginTop:10, lineHeight:1.5, textAlign:'center', maxWidth:300 }}>
                Выберите слово, которое стоит на указанной позиции.
              </div>

              <div style={{
                width:'100%',
                marginTop:22, padding:'22px 18px', borderRadius:20,
                background:cardBg, backdropFilter:'blur(14px)', WebkitBackdropFilter:'blur(14px)',
                border:`1px solid ${cardBorder}`,
                textAlign:'center',
                boxShadow:'0 10px 30px rgba(0,0,0,0.08)',
              }}>
                <div style={{ fontSize:11, fontWeight:600, color:sec, textTransform:'uppercase', letterSpacing:1.1 }}>слово</div>
                <div style={{ fontSize:52, fontWeight:800, color:'var(--accent)', letterSpacing:-1.5, marginTop:2, lineHeight:1 }}>
                  #{positions[confirmed.length]+1}
                </div>
                <div style={{ fontSize:12, color:sec, marginTop:6 }}>
                  {confirmed.length}/{positions.length} подтверждено
                </div>
              </div>

              <div style={{
                width:'100%',
                marginTop:14, display:'flex', flexDirection:'column', gap:10,
                animation: confirmWrong ? 'bubblePop 260ms' : 'none',
              }}>
                {choices.map((w,i) => (
                  <button key={i} onClick={()=>pickConfirm(w)} className="press" style={{
                    border: `1px solid ${cardBorder}`, cursor:'pointer',
                    background: confirmWrong ? 'rgba(255,59,48,0.10)' : cardBg,
                    backdropFilter:'blur(14px)', WebkitBackdropFilter:'blur(14px)',
                    color:text, padding:'16px 18px', borderRadius:14,
                    fontSize:16, fontWeight:600, textAlign:'center',
                    letterSpacing:-0.2,
                    transition:'background 160ms',
                  }}>{w}</button>
                ))}
              </div>
              {confirmWrong && (
                <div style={{ marginTop:10, color:'#ff3b30', fontSize:13, fontWeight:500, textAlign:'center' }}>
                  не совпадает, попробуйте ещё раз
                </div>
              )}
            </>
          ) : (
            <div style={{ textAlign:'center', paddingTop:60 }}>
              <div style={{
                width:72, height:72, borderRadius:'50%', background:'#00a676',
                display:'inline-flex', alignItems:'center', justifyContent:'center',
                boxShadow:'0 12px 32px rgba(0,166,118,0.45)',
                animation:'fadeScaleIn 300ms',
              }}>
                <Ico.Check size={34} color="#fff"/>
              </div>
              <div style={{ fontSize:22, fontWeight:700, marginTop:16, letterSpacing:-0.4 }}>фраза подтверждена</div>
              <div style={{ fontSize:13, color:sec, marginTop:6 }}>Koto ID готов к использованию</div>
            </div>
          )
        )}

        {step === 2 && (
          <>
            <KotoLogo size={64}/>
            <div style={{ fontSize:26, fontWeight:800, letterSpacing:-0.8, lineHeight:1.12, marginTop:18, textAlign:'center' }}>
              Как вас зовут?
            </div>
            <div style={{ fontSize:13, color:sec, marginTop:10, lineHeight:1.5, textAlign:'center', maxWidth:300 }}>
              Имя видят только те, кому вы пишете. На серверах — никогда.
            </div>

            <div style={{
              width:'100%',
              marginTop:26, display:'flex', alignItems:'center', gap:14,
              padding:14, borderRadius:18,
              background:cardBg, backdropFilter:'blur(14px)', WebkitBackdropFilter:'blur(14px)',
              border:`1px solid ${cardBorder}`,
              boxShadow:'0 10px 30px rgba(0,0,0,0.08)',
            }}>
              <Avatar contact={{ initials: (name||'?')[0].toUpperCase(), color:'var(--accent)' }} size={56}/>
              <input
                value={name}
                onChange={e=>setName(e.target.value.slice(0,32))}
                placeholder="Ваше имя"
                autoFocus
                style={{
                  flex:1, minWidth:0, border:0,
                  background:'transparent', outline:'none',
                  color:text, fontSize:20, fontWeight:600, letterSpacing:-0.4,
                  padding:'8px 0', fontFamily:'inherit',
                }}
              />
            </div>

            <div style={{
              width:'100%',
              marginTop:14, padding:14, borderRadius:14,
              background: dark?'rgba(20,16,19,0.5)':'rgba(255,255,255,0.55)',
              backdropFilter:'blur(14px)', WebkitBackdropFilter:'blur(14px)',
              border:`1px solid ${cardBorder}`,
            }}>
              <div style={{ fontSize:10.5, fontWeight:700, color:sec, textTransform:'uppercase', letterSpacing:1 }}>ваш koto id</div>
              <div className="mono" style={{
                fontSize:12, wordBreak:'break-all', marginTop:8,
                color:text, lineHeight:1.55, letterSpacing:0.2,
              }}>{kotoId}</div>
            </div>
          </>
        )}

        </div>
      </div>

      {/* Bottom action */}
      <div style={{ position:'relative', padding:'10px 24px 34px' }}>
        {step === 0 && (
          <button onClick={()=>setStep(1)} className="press" style={actionBtn()}>
            я записал фразу
          </button>
        )}
        {step === 1 && confirmed.length === positions.length && (
          <button onClick={()=>setStep(2)} className="press" style={actionBtn()}>
            продолжить
          </button>
        )}
        {step === 2 && (
          <button
            disabled={!name.trim()}
            onClick={()=>onDone({ name: name.trim(), kotoId })}
            className="press"
            style={{ ...actionBtn(), opacity: name.trim()?1:0.4 }}>
            войти в Koto
          </button>
        )}
      </div>
    </div>
  );
}

function actionBtn() {
  return {
    width:'100%', border:0, cursor:'pointer',
    background:'var(--accent)', color:'#fff',
    padding:'16px 18px', borderRadius:16,
    fontSize:16, fontWeight:600, letterSpacing:-0.2,
    boxShadow:'0 6px 18px rgba(255,107,53,0.28)',
  };
}

// ─── Login / restore ─────────────────────────────────────
function LoginScreen({ dark, onBack, onDone }) {
  const bg = dark ? '#0b0b0c' : '#ffffff';
  const surface = dark ? '#1a1a1c' : '#f2f2f2';
  const text = dark ? '#fff' : '#0a0a0a';
  const sec = dark ? '#9e9e9e' : '#707070';

  const [words, setWords] = useStateAu(Array(13).fill(''));
  const refs = useRefAu([]);

  const paste = (e) => {
    const text = (e.clipboardData || window.clipboardData).getData('text');
    const parts = text.trim().split(/\s+/).slice(0, 13);
    if (parts.length >= 6) {
      e.preventDefault();
      const next = [...words];
      parts.forEach((p,i) => next[i] = p.toLowerCase());
      setWords(next);
    }
  };

  const setAt = (i, v) => {
    const next = [...words];
    next[i] = v.toLowerCase().replace(/[^а-яёa-z]/g, '');
    setWords(next);
    if (v.endsWith(' ') && i < 12) refs.current[i+1] && refs.current[i+1].focus();
  };

  const complete = words.every(w => w.length >= 2);
  const invalidWords = words.map(w => w && !KOTO_WORDS.includes(w));

  const cardBg = dark ? 'rgba(20,16,19,0.72)' : 'rgba(255,255,255,0.78)';
  const cardBorder = dark ? 'rgba(255,255,255,0.08)' : 'rgba(10,10,10,0.06)';
  const fieldBg = dark ? 'rgba(10,8,9,0.6)' : 'rgba(255,255,255,0.75)';

  return (
    <div style={{ position:'relative', height:'100%', color:text, display:'flex', flexDirection:'column' }}>
      <AuthBackdrop dark={dark}/>

      <div style={{ position:'relative', paddingTop:59, padding:'59px 12px 4px', display:'flex', alignItems:'center' }}>
        <button onClick={onBack} className="press" style={{ border:0, background:'transparent', cursor:'pointer', padding:8, color:'var(--accent)', display:'flex', alignItems:'center' }}>
          <Ico.Back size={24} color="var(--accent)"/>
        </button>
        <div style={{ flex:1, textAlign:'center', fontSize:15, fontWeight:600, letterSpacing:-0.2 }}>Восстановление</div>
        <div style={{ width:40 }}/>
      </div>

      <div className="koto-scroll" style={{
        position:'relative', flex:1, overflow:'auto',
        padding:'14px 20px 24px',
        display:'flex', flexDirection:'column', alignItems:'center',
      }}>
        <div style={{ width:'100%', maxWidth:340, display:'flex', flexDirection:'column', alignItems:'center' }}>
          <KotoLogo size={56}/>
          <div style={{ fontSize:24, fontWeight:800, letterSpacing:-0.6, lineHeight:1.12, marginTop:16, textAlign:'center' }}>
            Введите 13 слов<br/>вашей фразы
          </div>
          <div style={{ fontSize:13, color:sec, marginTop:10, lineHeight:1.5, textAlign:'center', maxWidth:300 }}>
            Порядок важен. Можно вставить всю фразу сразу — нажмите и удерживайте любое поле.
          </div>

          <div style={{
            width:'100%',
            marginTop:18, background:cardBg,
            backdropFilter:'blur(14px)', WebkitBackdropFilter:'blur(14px)',
            border:`1px solid ${cardBorder}`,
            borderRadius:18, padding:12,
            display:'grid', gridTemplateColumns:'1fr 1fr', gap:'8px 10px',
            boxShadow:'0 10px 30px rgba(0,0,0,0.08)',
          }}>
            {words.map((w,i) => (
              <div key={i} style={{
                display:'flex', alignItems:'center', gap:6,
                background: fieldBg,
                borderRadius:10, padding:'8px 10px',
                border: `1px solid ${invalidWords[i] ? '#ff3b30' : 'transparent'}`,
              }}>
                <span className="mono" style={{ fontSize:10.5, color:sec, width:16, textAlign:'right' }}>{i+1}</span>
                <input
                  ref={el => refs.current[i] = el}
                  value={w}
                  onChange={e => setAt(i, e.target.value)}
                  onPaste={paste}
                  placeholder="—"
                  style={{
                    flex:1, minWidth:0, border:0, background:'transparent', outline:'none',
                    color: invalidWords[i] ? '#ff3b30' : text,
                    fontSize:14, fontWeight:500, fontFamily:'inherit',
                    padding:'2px 0',
                  }}
                />
              </div>
            ))}
          </div>

          {invalidWords.some(Boolean) && (
            <div style={{ marginTop:10, fontSize:12.5, color:'#ff3b30', alignSelf:'flex-start' }}>
              некоторые слова не из словаря Koto
            </div>
          )}
        </div>
      </div>

      <div style={{ position:'relative', padding:'10px 24px 34px' }}>
        <button
          disabled={!complete}
          onClick={()=>onDone({ name: 'Восстановлен', kotoId: deriveKotoId(words) })}
          className="press"
          style={{ ...actionBtn(), opacity: complete?1:0.4 }}>
          {complete ? 'продолжить' : `введено ${words.filter(w=>w.length>=2).length}/13`}
        </button>
      </div>
    </div>
  );
}

window.WelcomeScreen = WelcomeScreen;
window.RegisterScreen = RegisterScreen;
window.LoginScreen = LoginScreen;
window.deriveKotoId = deriveKotoId;
