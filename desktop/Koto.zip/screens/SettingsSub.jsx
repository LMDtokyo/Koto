/* global React, Ico, IC, Avatar, getContact, KOTO_CONTACTS */
// SettingsSub.jsx — all Settings sub-screens

const { useState: useStateSS, useEffect: useEffectSS, useRef: useRefSS } = React;

// ═══════════════════════ Shared chrome ═══════════════════════
function SubShell({ title, dark, onBack, children, backLabel = 'Настройки' }) {
  const bg = dark ? '#0b0b0c' : '#f2f2f2';
  const text = dark ? '#fff' : '#0a0a0a';
  const sep = dark ? 'rgba(255,255,255,0.06)' : 'rgba(0,0,0,0.05)';
  const bar = dark ? 'rgba(11,11,12,0.85)' : 'rgba(242,242,242,0.85)';

  return (
    <div style={{ height:'100%', background:bg, color:text, display:'flex', flexDirection:'column' }}>
      <div style={{
        paddingTop:59, flexShrink:0, zIndex:10,
        background: bar, backdropFilter:'blur(20px)', WebkitBackdropFilter:'blur(20px)',
        borderBottom:`0.5px solid ${sep}`,
      }}>
        <div style={{ display:'flex', alignItems:'center', padding:'6px 8px 12px' }}>
          <button onClick={onBack} className="press" style={{ border:0, background:'transparent', cursor:'pointer', padding:8, display:'flex', alignItems:'center', gap:2 }}>
            <Ico.Back size={26} color="var(--accent)"/>
            <span style={{ color:'var(--accent)', fontSize:17 }}>{backLabel}</span>
          </button>
          <div style={{ flex:1, textAlign:'center', fontSize:17, fontWeight:700, letterSpacing:-0.2, marginRight:90 + (backLabel.length*6) - 140 }}>
            {title}
          </div>
        </div>
      </div>
      <div className="koto-scroll" style={{ flex:1, overflowY:'auto', paddingBottom:32 }}>
        {children}
      </div>
    </div>
  );
}

function Group({ label, footer, children, dark }) {
  const sec = dark ? '#9e9e9e' : '#707070';
  const card = dark ? '#1a1a1c' : '#ffffff';
  return (
    <div style={{ marginBottom: 22 }}>
      {label && <div style={{ padding:'14px 24px 6px', fontSize:12, fontWeight:600, color:sec, textTransform:'uppercase', letterSpacing:0.6 }}>{label}</div>}
      <div style={{ margin:'0 16px', background:card, borderRadius:14, overflow:'hidden' }}>
        {children}
      </div>
      {footer && <div style={{ padding:'8px 24px 0', fontSize:12.5, color:sec, lineHeight:1.45 }}>{footer}</div>}
    </div>
  );
}

function LineRow({ title, detail, onClick, chevron, trailing, danger, isLast, subtitle, dark }) {
  const text = dark ? '#fff' : '#0a0a0a';
  const sec = dark ? '#9e9e9e' : '#707070';
  const sep = dark ? 'rgba(255,255,255,0.06)' : 'rgba(0,0,0,0.06)';
  return (
    <div onClick={onClick} className={onClick?'press':''} style={{
      display:'flex', alignItems:'center', gap:10,
      padding:'12px 14px', cursor: onClick?'pointer':'default', minHeight:48, position:'relative',
    }}>
      <div style={{ flex:1, minWidth:0 }}>
        <div style={{ fontSize:15.5, color: danger?'#ff453a':text, letterSpacing:-0.2 }}>{title}</div>
        {subtitle && <div style={{ fontSize:12.5, color:sec, marginTop:2, lineHeight:1.4 }}>{subtitle}</div>}
      </div>
      {detail && <div style={{ fontSize:14, color:sec, letterSpacing:-0.1 }}>{detail}</div>}
      {trailing}
      {chevron && onClick && <Ico.Chevron size={14} color={dark?'#5e5e62':'#c7c7cc'}/>}
      {!isLast && <div style={{ position:'absolute', bottom:0, left:14, right:0, height:0.5, background:sep }}/>}
    </div>
  );
}

// Toggle component (stateful value/setter from parent)
function Toggle({ value, onChange, dark }) {
  const on = !!value;
  return (
    <button
      onClick={(e) => { e.stopPropagation(); onChange(!on); }}
      style={{
        width:50, height:30, borderRadius:15, border:0, cursor:'pointer',
        background: on ? '#34c759' : (dark?'#3a3a3c':'#d6d6d9'),
        position:'relative', padding:0, transition:'background 180ms',
        flexShrink:0,
      }}
    >
      <div style={{
        width:26, height:26, borderRadius:13, background:'#fff',
        position:'absolute', top:2, left: on?22:2,
        boxShadow:'0 2px 4px rgba(0,0,0,0.2)',
        transition:'left 180ms cubic-bezier(.2,.8,.2,1)',
      }}/>
    </button>
  );
}

// Radio list inside a Group
function RadioList({ value, onChange, options, dark }) {
  return options.map((o,i) => (
    <div key={o.v} onClick={()=>onChange(o.v)} className="press" style={{
      display:'flex', alignItems:'flex-start', gap:12,
      padding:'14px 16px', cursor:'pointer', minHeight:56, position:'relative',
    }}>
      <div style={{ flex:1, minWidth:0 }}>
        <div style={{ fontSize:15.5, letterSpacing:-0.2, color: dark?'#fff':'#0a0a0a' }}>{o.l}</div>
        {o.s && <div style={{ fontSize:12.5, color: dark?'#9e9e9e':'#707070', marginTop:3, lineHeight:1.4 }}>{o.s}</div>}
      </div>
      <div style={{
        width:22, height:22, borderRadius:11, flexShrink:0, marginTop:1,
        border: `2px solid ${value===o.v?'var(--accent)':(dark?'#3a3a3c':'#d0d0d3')}`,
        display:'flex', alignItems:'center', justifyContent:'center',
        background: value===o.v ? 'var(--accent)' : 'transparent',
        transition:'all 140ms',
      }}>
        {value===o.v && <div style={{ width:8, height:8, borderRadius:4, background:'#fff' }}/>}
      </div>
      {i < options.length-1 && <div style={{ position:'absolute', bottom:0, left:16, right:0, height:0.5, background: dark?'rgba(255,255,255,0.06)':'rgba(0,0,0,0.06)' }}/>}
    </div>
  ));
}

// ═══════════════════════ 1. DEVICES ═══════════════════════
function DevicesScreen({ dark, onBack }) {
  const sec = dark ? '#9e9e9e' : '#707070';
  const [devices, setDevices] = useStateSS([
    { id:'d1', name:'iPhone 15 Pro', sub:'Этот телефон · основное устройство', current:true, platform:'phone', lastSeen:'сейчас' },
    { id:'d2', name:'MacBook Pro', sub:'Привязан 11 нояб. · Koto Desktop 4.2', current:false, platform:'laptop', lastSeen:'5 мин назад' },
    { id:'d3', name:'iPad mini', sub:'Привязан 2 окт. · Koto 26.4', current:false, platform:'tablet', lastSeen:'3 дня назад' },
  ]);

  const unlink = (id) => setDevices(ds => ds.filter(d => d.id !== id));

  return (
    <SubShell title="Устройства" dark={dark} onBack={onBack}>
      <div style={{ padding:'16px 24px 8px', fontSize:13.5, color:sec, lineHeight:1.45 }}>
        {devices.length} устройства используют ваш Koto ID. Ключи хранятся только локально — сервер не может расшифровать сообщения.
      </div>
      <Group dark={dark}>
        {devices.map((d,i) => (
          <div key={d.id} style={{
            display:'flex', alignItems:'center', gap:12,
            padding:'12px 14px', minHeight:60, position:'relative',
          }}>
            <DeviceGlyph platform={d.platform} dark={dark}/>
            <div style={{ flex:1, minWidth:0 }}>
              <div style={{ display:'flex', alignItems:'center', gap:6 }}>
                <div style={{ fontSize:15.5, fontWeight:600, letterSpacing:-0.2 }}>{d.name}</div>
                {d.current && <div style={{
                  fontSize:10.5, color:'#34c759', background:dark?'rgba(52,199,89,0.15)':'rgba(52,199,89,0.12)',
                  padding:'2px 6px', borderRadius:6, fontWeight:600, letterSpacing:0.2, textTransform:'uppercase',
                }}>Сейчас</div>}
              </div>
              <div style={{ fontSize:12.5, color:dark?'#9e9e9e':'#707070', marginTop:2 }}>{d.sub}</div>
              <div style={{ fontSize:11.5, color:dark?'#6e6e72':'#999', marginTop:2 }}>{d.lastSeen}</div>
            </div>
            {!d.current && (
              <button onClick={()=>unlink(d.id)} className="press" style={{
                border:0, cursor:'pointer', padding:'6px 10px', borderRadius:8,
                background: dark?'rgba(255,69,58,0.15)':'rgba(255,69,58,0.1)',
                color:'#ff453a', fontSize:13, fontWeight:600, fontFamily:'inherit',
              }}>Отвязать</button>
            )}
            {i < devices.length-1 && <div style={{ position:'absolute', bottom:0, left:62, right:0, height:0.5, background: dark?'rgba(255,255,255,0.06)':'rgba(0,0,0,0.06)' }}/>}
          </div>
        ))}
      </Group>
      <Group dark={dark}>
        <LineRow
          dark={dark} isLast onClick={()=>{}}
          title={<span style={{ color:'var(--accent)', display:'flex', alignItems:'center', gap:8 }}>
            <Ico.Qr size={18} color="var(--accent)"/> Привязать новое устройство
          </span>}
          subtitle="Отсканируйте QR на koto.app/link с нового устройства"
        />
      </Group>
    </SubShell>
  );
}

function DeviceGlyph({ platform, dark }) {
  const bg = dark ? '#242428' : '#eceef2';
  const stroke = dark ? '#fff' : '#2a2a2e';
  const size = 44;
  const glyphs = {
    phone: <svg width="22" height="22" viewBox="0 0 24 24" fill="none"><rect x="6" y="2" width="12" height="20" rx="3" stroke={stroke} strokeWidth="1.6"/><circle cx="12" cy="18" r="1" fill={stroke}/></svg>,
    laptop: <svg width="22" height="22" viewBox="0 0 24 24" fill="none"><rect x="4" y="5" width="16" height="11" rx="1.5" stroke={stroke} strokeWidth="1.6"/><path d="M2 19h20" stroke={stroke} strokeWidth="1.6" strokeLinecap="round"/></svg>,
    tablet: <svg width="22" height="22" viewBox="0 0 24 24" fill="none"><rect x="5" y="3" width="14" height="18" rx="2" stroke={stroke} strokeWidth="1.6"/><path d="M10 18h4" stroke={stroke} strokeWidth="1.6" strokeLinecap="round"/></svg>,
  };
  return (
    <div style={{ width:size, height:size, borderRadius:22, background:bg, display:'flex', alignItems:'center', justifyContent:'center', flexShrink:0 }}>
      {glyphs[platform] || glyphs.phone}
    </div>
  );
}

// ═══════════════════════ 2. USERNAME ═══════════════════════
function UsernameScreen({ dark, onBack }) {
  const sec = dark ? '#9e9e9e' : '#707070';
  const text = dark ? '#fff' : '#0a0a0a';
  const card = dark ? '#1a1a1c' : '#ffffff';
  const [u, setU] = useStateSS('dmitry');
  const taken = ['team','alina','maks','olya','koto','admin','support'];
  const re = /^[a-z0-9_]{3,24}$/;
  const status = !u ? 'empty' : !re.test(u) ? 'invalid' : taken.includes(u) ? 'taken' : 'ok';
  const statusMap = {
    empty: { col:sec, text:'Имя от 3 до 24 символов, только a-z, 0-9, _' },
    invalid: { col:'#ff9f0a', text:'Только латиница, цифры, нижнее подчёркивание' },
    taken: { col:'#ff453a', text:`@${u} уже занято` },
    ok: { col:'#34c759', text:`@${u} доступно` },
  };
  const st = statusMap[status];

  return (
    <SubShell title="Имя пользователя" dark={dark} onBack={onBack}>
      <div style={{ padding:'18px 24px 6px', fontSize:13.5, color:sec, lineHeight:1.45 }}>
        Другие могут найти вас по @username без обмена Koto ID. Имя можно изменить в любой момент.
      </div>
      <Group dark={dark}>
        <div style={{ padding:'12px 14px', display:'flex', alignItems:'center', gap:6 }}>
          <div style={{
            fontSize:18, fontWeight:600, color: status==='ok'?'var(--accent)':(status==='taken'||status==='invalid'?'#ff453a':sec),
            letterSpacing:-0.3, minWidth:14,
          }}>@</div>
          <input
            value={u} onChange={(e)=>setU(e.target.value.toLowerCase())}
            placeholder="username"
            style={{
              flex:1, border:0, background:'transparent', outline:'none',
              fontSize:18, fontWeight:600, color:text, fontFamily:'inherit', letterSpacing:-0.3,
              padding:'6px 0', minWidth:0,
            }}
          />
          {status==='ok' && <Ico.CheckCircle size={22} color="#34c759"/>}
          {status==='taken' && <Ico.Close size={22} color="#ff453a"/>}
        </div>
      </Group>
      <div style={{ padding:'4px 24px 14px', fontSize:13, color:st.col, lineHeight:1.4, display:'flex', alignItems:'center', gap:6 }}>
        <div style={{ width:6, height:6, borderRadius:3, background:st.col }}/> {st.text}
      </div>

      <Group label="Ссылка-приглашение" dark={dark}
        footer="Поделитесь этой ссылкой. Она откроет новый чат с вами, не раскрывая Koto ID.">
        <LineRow dark={dark} isLast
          title="koto.me/dmitry"
          trailing={<Ico.Copy size={18} color="var(--accent)"/>}
          onClick={()=>{}}
        />
      </Group>

      <Group label="Кто может найти по @username" dark={dark}>
        <RadioList value={'everyone'} onChange={()=>{}} dark={dark} options={[
          { v:'everyone', l:'Все', s:'Любой с вашим @username откроет чат' },
          { v:'contacts', l:'Только контакты', s:'Другие увидят «пользователь не найден»' },
          { v:'nobody', l:'Никто', s:'Только через Koto ID или QR' },
        ]}/>
      </Group>
    </SubShell>
  );
}

// ═══════════════════════ 3. PRIVACY ═══════════════════════
function PrivacyScreen({ dark, onBack }) {
  const [st, setSt] = useStateSS({
    readReceipts: true, typing: true, lastSeen: 'contacts', profile:'everyone',
    blockUnknown: false, disappearingDefault: 0, screenshotsAlert: true,
  });
  const up = (k,v) => setSt(s => ({...s, [k]:v}));
  return (
    <SubShell title="Приватность" dark={dark} onBack={onBack}>
      <Group label="Чтение и активность" dark={dark}
        footer="Работает в обе стороны: если выключить, вы не будете видеть отметки у других.">
        <LineRow dark={dark} title="Отчёты о прочтении" subtitle="Показывать двойную галочку" trailing={<Toggle dark={dark} value={st.readReceipts} onChange={(v)=>up('readReceipts',v)}/>}/>
        <LineRow dark={dark} title="Индикатор печати" subtitle="Показывать «…печатает»" isLast trailing={<Toggle dark={dark} value={st.typing} onChange={(v)=>up('typing',v)}/>}/>
      </Group>
      <Group label="Кто видит" dark={dark}>
        <LineRow dark={dark} chevron onClick={()=>{}} title="Последнюю активность" detail={st.lastSeen==='everyone'?'все':st.lastSeen==='contacts'?'контакты':'никто'}/>
        <LineRow dark={dark} chevron onClick={()=>{}} title="Фото профиля" detail={st.profile==='everyone'?'все':st.profile==='contacts'?'контакты':'никто'}/>
        <LineRow dark={dark} chevron onClick={()=>{}} title="Имя и описание" isLast detail="все"/>
      </Group>
      <Group label="Сообщения" dark={dark}>
        <LineRow dark={dark} title="Блокировать незнакомцев" subtitle="Автоматически блокировать Koto ID не из контактов" trailing={<Toggle dark={dark} value={st.blockUnknown} onChange={(v)=>up('blockUnknown',v)}/>}/>
        <LineRow dark={dark} title="Уведомлять о скриншотах" subtitle="Появляется системное сообщение в чате" isLast trailing={<Toggle dark={dark} value={st.screenshotsAlert} onChange={(v)=>up('screenshotsAlert',v)}/>}/>
      </Group>
      <Group label="Заблокированные" dark={dark}>
        <LineRow dark={dark} chevron onClick={()=>{}} isLast title="Список заблокированных" detail="3"/>
      </Group>
    </SubShell>
  );
}

// ═══════════════════════ 4. EPHEMERAL (default) ═══════════════════════
function EphemeralSettings({ dark, onBack }) {
  const sec = dark ? '#9e9e9e' : '#707070';
  const [v, setV] = useStateSS(0);
  return (
    <SubShell title="Исчезающие сообщения" dark={dark} onBack={onBack}>
      <div style={{ padding:'18px 24px 8px', fontSize:13.5, color:sec, lineHeight:1.45 }}>
        Применяется ко всем новым чатам. В существующих — настраивается отдельно.
      </div>
      <Group label="Таймер по умолчанию" dark={dark}>
        <RadioList value={v} onChange={setV} dark={dark} options={[
          { v:0, l:'Выключено', s:'Сообщения не удаляются' },
          { v:30, l:'30 секунд' },
          { v:300, l:'5 минут' },
          { v:3600, l:'1 час' },
          { v:86400, l:'24 часа' },
          { v:604800, l:'7 дней' },
          { v:2592000, l:'30 дней' },
        ]}/>
      </Group>
      <div style={{ padding:'0 24px', fontSize:12.5, color:sec, lineHeight:1.45 }}>
        Таймер начинается от момента прочтения. Получатель увидит значок исчезновения рядом с сообщением.
      </div>
    </SubShell>
  );
}

// ═══════════════════════ 5. SCREEN LOCK ═══════════════════════
function ScreenLockSettings({ dark, onBack }) {
  const [st, setSt] = useStateSS({
    enabled: true, method: 'face', timeout:'immediate',
    hideContent: true, hidePreviews: true, lockOnExit: true,
  });
  const up = (k,v) => setSt(s => ({...s, [k]:v}));
  return (
    <SubShell title="Блокировка экрана" dark={dark} onBack={onBack}>
      <div style={{ padding:'22px 24px 10px', display:'flex', flexDirection:'column', alignItems:'center' }}>
        <div style={{
          width:72, height:72, borderRadius:20,
          background: st.enabled
            ? 'linear-gradient(135deg, #34c759, #30b350)'
            : (dark?'#2a2a2e':'#d8d8dc'),
          display:'flex', alignItems:'center', justifyContent:'center',
          boxShadow: st.enabled ? '0 8px 24px rgba(52,199,89,0.3)' : 'none',
        }}>
          <svg width="36" height="36" viewBox="0 0 24 24" fill="none">
            <rect x="5" y="11" width="14" height="10" rx="2" stroke="#fff" strokeWidth="1.8"/>
            <path d="M8 11V7a4 4 0 018 0v4" stroke="#fff" strokeWidth="1.8"/>
            <circle cx="12" cy="16" r="1.4" fill="#fff"/>
          </svg>
        </div>
        <div style={{ marginTop:14, fontSize:17, fontWeight:700 }}>
          {st.enabled ? 'Koto защищён' : 'Блокировка выключена'}
        </div>
      </div>

      <Group dark={dark}>
        <LineRow dark={dark} isLast title="Блокировать Koto" subtitle="Требовать подтверждение при открытии" trailing={<Toggle dark={dark} value={st.enabled} onChange={(v)=>up('enabled',v)}/>}/>
      </Group>

      {st.enabled && (
        <>
          <Group label="Метод" dark={dark}>
            <RadioList value={st.method} onChange={(v)=>up('method',v)} dark={dark} options={[
              { v:'face', l:'Face ID', s:'Рекомендуется — безопасно и быстро' },
              { v:'passcode', l:'Код-пароль', s:'4–8 цифр' },
              { v:'both', l:'Face ID + код', s:'Код запрашивается при рестарте' },
            ]}/>
          </Group>
          <Group label="Запрашивать" dark={dark}>
            <RadioList value={st.timeout} onChange={(v)=>up('timeout',v)} dark={dark} options={[
              { v:'immediate', l:'Сразу' },
              { v:'1m', l:'Через 1 минуту' },
              { v:'15m', l:'Через 15 минут' },
              { v:'1h', l:'Через 1 час' },
            ]}/>
          </Group>
          <Group label="Система" dark={dark}>
            <LineRow dark={dark} title="Скрыть содержимое в переключателе" subtitle="iOS покажет плашку вместо последнего экрана" trailing={<Toggle dark={dark} value={st.hideContent} onChange={(v)=>up('hideContent',v)}/>}/>
            <LineRow dark={dark} title="Скрыть текст в уведомлениях" subtitle={`Показывать «Новое сообщение» вместо текста`} trailing={<Toggle dark={dark} value={st.hidePreviews} onChange={(v)=>up('hidePreviews',v)}/>}/>
            <LineRow dark={dark} title="Блокировать при выходе" isLast trailing={<Toggle dark={dark} value={st.lockOnExit} onChange={(v)=>up('lockOnExit',v)}/>}/>
          </Group>
        </>
      )}
    </SubShell>
  );
}

// ═══════════════════════ 6. SEALED SENDER ═══════════════════════
function SealedScreen({ dark, onBack }) {
  const [st, setSt] = useStateSS({ enabled:true, unknown:true, indicator:false });
  const up = (k,v) => setSt(s => ({...s, [k]:v}));
  const sec = dark ? '#9e9e9e' : '#707070';
  return (
    <SubShell title="Закрытые отправители" dark={dark} onBack={onBack}>
      <div style={{ padding:'18px 24px 8px', fontSize:13.5, color:sec, lineHeight:1.45 }}>
        В обычной переписке сервер Koto знает, кто кому отправляет сообщение. Закрытые отправители шифруют также и отправителя — сервер видит только получателя.
      </div>
      <Group dark={dark} footer="Рекомендуется: работает с контактами и теми, с кем вы уже обменивались сообщениями.">
        <LineRow dark={dark} title="Включить для контактов" isLast trailing={<Toggle dark={dark} value={st.enabled} onChange={(v)=>up('enabled',v)}/>}/>
      </Group>
      <Group dark={dark} footer="Может использоваться спамерами. Отключите, если получаете нежелательные сообщения.">
        <LineRow dark={dark} title="Принимать от незнакомцев" subtitle="Koto ID не в ваших контактах" isLast trailing={<Toggle dark={dark} value={st.unknown} onChange={(v)=>up('unknown',v)}/>}/>
      </Group>
      <Group dark={dark}>
        <LineRow dark={dark} title="Показывать индикатор в чате" subtitle="Значок 🔒 рядом с входящими" isLast trailing={<Toggle dark={dark} value={st.indicator} onChange={(v)=>up('indicator',v)}/>}/>
      </Group>
    </SubShell>
  );
}

// ═══════════════════════ 7. STORAGE ═══════════════════════
function StorageScreen({ dark, onBack }) {
  const text = dark ? '#fff' : '#0a0a0a';
  const sec = dark ? '#9e9e9e' : '#707070';
  const card = dark ? '#1a1a1c' : '#ffffff';

  const cats = [
    { id:'photo', l:'Фото', v:1.42, c:'#ff6b35' },
    { id:'video', l:'Видео', v:0.68, c:'#7c5cff' },
    { id:'voice', l:'Голосовые', v:0.12, c:'#00a676' },
    { id:'doc',   l:'Документы', v:0.14, c:'#3276ff' },
    { id:'sticker', l:'Стикеры · GIF', v:0.06, c:'#f0b400' },
  ];
  const total = cats.reduce((s,c)=>s+c.v, 0);

  return (
    <SubShell title="Хранилище" dark={dark} onBack={onBack}>
      <div style={{ padding:'22px 24px 10px', textAlign:'center' }}>
        <div style={{ fontSize:14, color:sec, letterSpacing:-0.1 }}>Занято на устройстве</div>
        <div style={{ fontSize:42, fontWeight:800, letterSpacing:-1.5, marginTop:2 }}>
          {total.toFixed(1)} <span style={{ fontSize:18, color:sec, fontWeight:500 }}>ГБ</span>
        </div>
      </div>
      <div style={{ margin:'12px 24px 20px' }}>
        <div style={{ display:'flex', height:10, borderRadius:5, overflow:'hidden', background: dark?'#232327':'#e2e2e6' }}>
          {cats.map(c => (
            <div key={c.id} style={{ width: `${(c.v/total)*100}%`, background:c.c }}/>
          ))}
        </div>
        <div style={{ display:'flex', flexWrap:'wrap', gap:'10px 16px', marginTop:12 }}>
          {cats.map(c => (
            <div key={c.id} style={{ display:'flex', alignItems:'center', gap:6, fontSize:13, color:text }}>
              <div style={{ width:8, height:8, borderRadius:4, background:c.c }}/>
              {c.l} <span style={{ color:sec, fontVariantNumeric:'tabular-nums' }}>{c.v.toFixed(2)} ГБ</span>
            </div>
          ))}
        </div>
      </div>

      <Group label="По чатам" dark={dark}>
        {KOTO_CONTACTS.slice(0,5).map((c,i,a) => (
          <div key={c.id} className="press" style={{
            display:'flex', alignItems:'center', gap:12, padding:'10px 14px', cursor:'pointer', minHeight:52, position:'relative',
          }}>
            <Avatar contact={c} size={36}/>
            <div style={{ flex:1, minWidth:0 }}>
              <div style={{ fontSize:15, fontWeight:600 }}>{c.name}</div>
              <div style={{ fontSize:12, color:sec, marginTop:1 }}>{Math.random()<0.5?'8 фото · 2 видео':'156 сообщений'}</div>
            </div>
            <div style={{ fontSize:13, color:sec, fontVariantNumeric:'tabular-nums' }}>
              {(Math.random()*0.8+0.05).toFixed(2)} ГБ
            </div>
            <Ico.Chevron size={14} color={dark?'#5e5e62':'#c7c7cc'}/>
            {i < a.length-1 && <div style={{ position:'absolute', bottom:0, left:60, right:0, height:0.5, background: dark?'rgba(255,255,255,0.06)':'rgba(0,0,0,0.06)' }}/>}
          </div>
        ))}
      </Group>

      <Group label="Очистить" dark={dark} footer="Медиа можно перезагрузить из чатов при подключении к сети. Тексты сообщений всегда хранятся в зашифрованной базе.">
        <LineRow dark={dark} chevron onClick={()=>{}} title="Очистить кэш" detail="420 МБ"/>
        <LineRow dark={dark} chevron onClick={()=>{}} title="Удалить медиа старше 30 дней"/>
        <LineRow dark={dark} chevron onClick={()=>{}} isLast danger title="Стереть всю историю"/>
      </Group>
    </SubShell>
  );
}

// ═══════════════════════ 8. NETWORK ═══════════════════════
function NetworkScreen({ dark, onBack }) {
  const text = dark ? '#fff' : '#0a0a0a';
  const sec = dark ? '#9e9e9e' : '#707070';
  // Faux last-30-days bars
  const days = Array.from({length:30},(_,i)=> ({ d:i, up: 2 + Math.abs(Math.sin(i*0.7))*8 + (i%5===0?6:0), down: 3 + Math.abs(Math.cos(i*0.5))*12 }));
  const max = Math.max(...days.map(d=>d.up+d.down));

  const [st, setSt] = useStateSS({ lowData:false, proxy:false, censorship:false });
  const up = (k,v) => setSt(s => ({...s, [k]:v}));

  return (
    <SubShell title="Использование сети" dark={dark} onBack={onBack}>
      <div style={{ padding:'22px 24px 6px' }}>
        <div style={{ fontSize:14, color:sec }}>Последние 30 дней</div>
        <div style={{ display:'flex', alignItems:'baseline', gap:10, marginTop:2 }}>
          <div style={{ fontSize:34, fontWeight:800, letterSpacing:-1, lineHeight:1 }}>128 МБ</div>
          <div style={{ fontSize:13, color:'#34c759' }}>−18% к пред. месяцу</div>
        </div>
      </div>

      <div style={{ margin:'14px 20px 8px', padding:'14px', background: dark?'#1a1a1c':'#fff', borderRadius:14 }}>
        <div style={{ display:'flex', alignItems:'flex-end', gap:3, height:100 }}>
          {days.map((d,i) => (
            <div key={i} style={{ flex:1, display:'flex', flexDirection:'column', justifyContent:'flex-end', gap:1 }}>
              <div style={{ height: `${(d.up/max)*100}%`, background:'var(--accent)', borderRadius:'2px 2px 0 0', opacity:0.9 }}/>
              <div style={{ height: `${(d.down/max)*100}%`, background: dark?'#2e2e32':'#e2e2e6', borderRadius:'0 0 2px 2px' }}/>
            </div>
          ))}
        </div>
        <div style={{ display:'flex', justifyContent:'space-between', marginTop:10, fontSize:12, color:sec }}>
          <div style={{ display:'flex', alignItems:'center', gap:5 }}><div style={{ width:8,height:8,borderRadius:2,background:'var(--accent)' }}/> Отправлено <span style={{ color:text, fontVariantNumeric:'tabular-nums' }}>52 МБ</span></div>
          <div style={{ display:'flex', alignItems:'center', gap:5 }}><div style={{ width:8,height:8,borderRadius:2,background: dark?'#2e2e32':'#d0d0d3' }}/> Получено <span style={{ color:text, fontVariantNumeric:'tabular-nums' }}>76 МБ</span></div>
        </div>
      </div>

      <Group label="Экономия" dark={dark}>
        <LineRow dark={dark} title="Режим низкого трафика" subtitle="Меньше качество медиа, реже синхронизация" trailing={<Toggle dark={dark} value={st.lowData} onChange={(v)=>up('lowData',v)}/>}/>
        <LineRow dark={dark} title="Только звонки на Wi-Fi" subtitle="Koto-вызовы блокируются на мобильных данных" isLast trailing={<Toggle dark={dark} value={false} onChange={()=>{}}/>}/>
      </Group>

      <Group label="Обход блокировок" dark={dark} footer="Если Koto недоступен в вашей сети, включите прокси. Сервер не увидит содержимого — шифрование остаётся end-to-end.">
        <LineRow dark={dark} title="Использовать прокси" trailing={<Toggle dark={dark} value={st.proxy} onChange={(v)=>up('proxy',v)}/>}/>
        {st.proxy && (
          <LineRow dark={dark} chevron onClick={()=>{}} title="Сервер прокси" detail="proxy.koto.app"/>
        )}
        <LineRow dark={dark} title="Режим устойчивости" subtitle="Маскирует трафик под HTTPS" isLast trailing={<Toggle dark={dark} value={st.censorship} onChange={(v)=>up('censorship',v)}/>}/>
      </Group>
    </SubShell>
  );
}

// ═══════════════════════ 9. AUTO-DOWNLOAD ═══════════════════════
function AutoDLScreen({ dark, onBack }) {
  const [wifi, setWifi] = useStateSS({ photo:true, video:true, audio:true, doc:false });
  const [cell, setCell] = useStateSS({ photo:true, video:false, audio:true, doc:false });
  const [roam, setRoam] = useStateSS({ photo:false, video:false, audio:false, doc:false });

  const Cat = ({ obj, setObj }) => (
    <>
      <LineRow dark={dark} title="Фото" trailing={<Toggle dark={dark} value={obj.photo} onChange={(v)=>setObj({...obj,photo:v})}/>}/>
      <LineRow dark={dark} title="Видео" trailing={<Toggle dark={dark} value={obj.video} onChange={(v)=>setObj({...obj,video:v})}/>}/>
      <LineRow dark={dark} title="Голосовые" trailing={<Toggle dark={dark} value={obj.audio} onChange={(v)=>setObj({...obj,audio:v})}/>}/>
      <LineRow dark={dark} title="Документы" isLast trailing={<Toggle dark={dark} value={obj.doc} onChange={(v)=>setObj({...obj,doc:v})}/>}/>
    </>
  );

  return (
    <SubShell title="Автозагрузка" dark={dark} onBack={onBack}>
      <Group label="Wi-Fi" dark={dark}>
        <Cat obj={wifi} setObj={setWifi}/>
      </Group>
      <Group label="Мобильные данные" dark={dark}>
        <Cat obj={cell} setObj={setCell}/>
      </Group>
      <Group label="В роуминге" dark={dark} footer="Отключено по умолчанию во всех категориях, чтобы избежать расходов.">
        <Cat obj={roam} setObj={setRoam}/>
      </Group>
    </SubShell>
  );
}

// ═══════════════════════ 10. THEME ═══════════════════════
function ThemeScreen({ dark, onBack, accent, onAccent, onToggleTheme }) {
  const [mode, setMode] = useStateSS(dark ? 'dark' : 'light');
  useEffectSS(() => {
    const want = mode==='system' ? (window.matchMedia('(prefers-color-scheme: dark)').matches?'dark':'light') : mode;
    if ((want==='dark') !== dark) onToggleTheme();
  }, [mode]);

  const swatches = ['#ff6b35','#ff3b30','#ff9f0a','#ffcc00','#34c759','#00a676','#0a84ff','#3276ff','#7c5cff','#af52de','#e74c6f','#13b3a5'];

  return (
    <SubShell title="Тема и цвет" dark={dark} onBack={onBack}>
      {/* Preview */}
      <div style={{ padding:'20px 20px 4px' }}>
        <div style={{
          borderRadius:18, padding:'16px 14px', background: dark?'#1a1a1c':'#fff',
          border: `0.5px solid ${dark?'rgba(255,255,255,0.06)':'rgba(0,0,0,0.06)'}`,
        }}>
          <div style={{ display:'flex', justifyContent:'flex-start', marginBottom:6 }}>
            <div style={{ background: dark?'#27272a':'#ececec', color: dark?'#fff':'#0a0a0a', padding:'8px 12px', borderRadius:'16px 16px 16px 4px', fontSize:14.5, maxWidth:'70%' }}>
              Привет, как новый цвет?
            </div>
          </div>
          <div style={{ display:'flex', justifyContent:'flex-end' }}>
            <div style={{ background:accent, color:'#fff', padding:'8px 12px', borderRadius:'16px 4px 16px 16px', fontSize:14.5, maxWidth:'70%' }}>
              Отлично, живо!
            </div>
          </div>
        </div>
      </div>

      <Group label="Режим" dark={dark}>
        <RadioList value={mode} onChange={setMode} dark={dark} options={[
          { v:'light', l:'Светлая' },
          { v:'dark', l:'Тёмная' },
          { v:'system', l:'Как в системе' },
        ]}/>
      </Group>

      <Group label="Акцент" dark={dark} footer="Акцент меняет цвет кнопок, ссылок и ваших сообщений в чатах.">
        <div style={{ padding:'14px 14px', display:'grid', gridTemplateColumns:'repeat(6, 1fr)', gap:10 }}>
          {swatches.map(c => (
            <button key={c} onClick={()=>onAccent(c)} className="press" style={{
              aspectRatio:'1', border:0, cursor:'pointer', background:'transparent', padding:0,
              display:'flex', alignItems:'center', justifyContent:'center',
            }}>
              <div style={{
                width:'100%', aspectRatio:'1', borderRadius:'50%', background:c,
                border: accent.toLowerCase()===c.toLowerCase() ? `3px solid ${dark?'#fff':'#000'}` : `3px solid transparent`,
                outline: accent.toLowerCase()===c.toLowerCase() ? `2px solid ${c}` : 'none',
                outlineOffset:2,
                boxShadow: `0 4px 12px ${c}40`,
                transition:'transform 140ms',
              }}/>
            </button>
          ))}
        </div>
      </Group>
    </SubShell>
  );
}

// ═══════════════════════ 11. FONT ═══════════════════════
function FontScreen({ dark, onBack }) {
  const [size, setSize] = useStateSS(16);
  const [weight, setWeight] = useStateSS('regular');
  const names = [14, 15, 16, 17, 18, 20];
  const labelFor = (s) => s<=14?'компактно':s<=16?'обычно':s<=18?'крупно':'очень крупно';
  const accentMult = size/16;

  return (
    <SubShell title="Размер шрифта" dark={dark} onBack={onBack}>
      {/* Live preview bubble */}
      <div style={{ padding:'20px 20px 0' }}>
        <div style={{
          borderRadius:18, padding:14, background: dark?'#1a1a1c':'#fff',
          border:`0.5px solid ${dark?'rgba(255,255,255,0.06)':'rgba(0,0,0,0.06)'}`,
        }}>
          <div style={{ display:'flex', gap:10 }}>
            <Avatar contact={{ initials:'А', color:'#7c5cff' }} size={32}/>
            <div style={{
              background: dark?'#27272a':'#ececec', color: dark?'#fff':'#0a0a0a',
              padding:'10px 12px', borderRadius:'16px 16px 16px 4px',
              fontSize: size, lineHeight: 1.3, fontWeight: weight==='bold'?600:weight==='medium'?500:400,
              letterSpacing: -0.2 * accentMult,
              maxWidth:'75%',
            }}>
              Так будет выглядеть текст в чатах.
            </div>
          </div>
        </div>
      </div>

      <Group label="Размер" dark={dark}>
        <div style={{ padding:'16px 16px 10px', display:'flex', alignItems:'center', gap:12 }}>
          <span style={{ fontSize:12, fontWeight:600, color: dark?'#fff':'#0a0a0a' }}>A</span>
          <div style={{ flex:1, position:'relative', height:24, display:'flex', alignItems:'center' }}>
            <div style={{ position:'absolute', left:0, right:0, height:2, background: dark?'#2e2e32':'#e2e2e6', borderRadius:1 }}/>
            <div style={{ position:'absolute', left:0, width:`${((size-14)/(20-14))*100}%`, height:2, background:'var(--accent)', borderRadius:1 }}/>
            {names.map(s => (
              <button key={s} onClick={()=>setSize(s)} style={{
                position:'absolute', left:`calc(${((s-14)/(20-14))*100}% - 10px)`,
                width:20, height:20, borderRadius:10,
                background: size===s?'var(--accent)':(dark?'#fff':'#fff'),
                border: size===s ? `2px solid var(--accent)` : `2px solid ${dark?'#2e2e32':'#d0d0d3'}`,
                cursor:'pointer', padding:0,
                boxShadow:'0 2px 4px rgba(0,0,0,0.15)',
              }}/>
            ))}
          </div>
          <span style={{ fontSize:22, fontWeight:600, color: dark?'#fff':'#0a0a0a' }}>A</span>
        </div>
        <div style={{ padding:'0 16px 14px', fontSize:12.5, color: dark?'#9e9e9e':'#707070', textAlign:'center' }}>
          {size}px · {labelFor(size)}
        </div>
      </Group>

      <Group label="Начертание" dark={dark}>
        <RadioList value={weight} onChange={setWeight} dark={dark} options={[
          { v:'regular', l:'Обычный' },
          { v:'medium', l:'Средний' },
          { v:'bold', l:'Жирный' },
        ]}/>
      </Group>
    </SubShell>
  );
}

// ═══════════════════════ 12. WALLPAPER ═══════════════════════
function WallpaperScreen({ dark, onBack }) {
  const [sel, setSel] = useStateSS('koto');
  const wallpapers = [
    { id:'koto',   name:'Koto · оранжевый', bg:'radial-gradient(circle at 30% 20%, #ffe1d0, #fff)', bgDark:'radial-gradient(circle at 30% 20%, #2a1a10, #0b0b0c)' },
    { id:'plain',  name:'Без обоев',        bg:'#ffffff', bgDark:'#0b0b0c' },
    { id:'linen',  name:'Холст',            bg:'repeating-linear-gradient(45deg, #f4efe7 0 4px, #ecece0 4px 8px)', bgDark:'repeating-linear-gradient(45deg, #1a1a1c 0 4px, #222226 4px 8px)' },
    { id:'mist',   name:'Туман',            bg:'linear-gradient(160deg, #e8f2ff, #fbe8ff)', bgDark:'linear-gradient(160deg, #162235, #271a2f)' },
    { id:'sage',   name:'Шалфей',           bg:'linear-gradient(160deg, #dff0dd, #e8eedd)', bgDark:'linear-gradient(160deg, #1c2820, #212418)' },
    { id:'ink',    name:'Графит',           bg:'linear-gradient(160deg, #2a2a2e, #0a0a0c)', bgDark:'linear-gradient(160deg, #1a1a1e, #000)' },
    { id:'dots',   name:'Точки',            bg:'radial-gradient(#d4d4d8 0.8px, transparent 1.2px) 0 0 / 14px 14px, #fff', bgDark:'radial-gradient(#2a2a2e 0.8px, transparent 1.2px) 0 0 / 14px 14px, #0b0b0c' },
    { id:'grid',   name:'Сетка',            bg:'linear-gradient(#e6e6ea 1px, transparent 1px) 0 0 / 24px 24px, linear-gradient(90deg, #e6e6ea 1px, transparent 1px) 0 0 / 24px 24px, #fff', bgDark:'linear-gradient(#1c1c20 1px, transparent 1px) 0 0 / 24px 24px, linear-gradient(90deg, #1c1c20 1px, transparent 1px) 0 0 / 24px 24px, #0b0b0c' },
  ];
  const sec = dark ? '#9e9e9e' : '#707070';
  const current = wallpapers.find(w => w.id===sel);

  return (
    <SubShell title="Обои чатов" dark={dark} onBack={onBack}>
      {/* Preview */}
      <div style={{ margin:'18px 16px 8px', borderRadius:18, overflow:'hidden', position:'relative', aspectRatio:'16/10',
        background: dark ? current.bgDark : current.bg,
        border:`0.5px solid ${dark?'rgba(255,255,255,0.08)':'rgba(0,0,0,0.06)'}`,
      }}>
        <div style={{ position:'absolute', left:16, top:20, background: dark?'#27272a':'#fff', color: dark?'#fff':'#0a0a0a', padding:'7px 11px', borderRadius:'16px 16px 16px 4px', fontSize:13.5, maxWidth:'70%', boxShadow:'0 1px 2px rgba(0,0,0,0.08)' }}>
          Превью обоев
        </div>
        <div style={{ position:'absolute', right:16, top:64, background:'var(--accent)', color:'#fff', padding:'7px 11px', borderRadius:'16px 4px 16px 16px', fontSize:13.5 }}>
          Класс, оставлю
        </div>
      </div>

      <Group label="Пресеты" dark={dark}>
        <div style={{ padding:14, display:'grid', gridTemplateColumns:'repeat(3, 1fr)', gap:10 }}>
          {wallpapers.map(w => (
            <button key={w.id} onClick={()=>setSel(w.id)} className="press" style={{
              border:0, cursor:'pointer', background:'transparent', padding:0,
              display:'flex', flexDirection:'column', alignItems:'center', gap:6,
            }}>
              <div style={{
                width:'100%', aspectRatio:'3/4', borderRadius:10,
                background: dark ? w.bgDark : w.bg,
                border: sel===w.id ? `2.5px solid var(--accent)` : `1px solid ${dark?'rgba(255,255,255,0.08)':'rgba(0,0,0,0.08)'}`,
              }}/>
              <div style={{ fontSize:12, color: sel===w.id?'var(--accent)':(dark?'#fff':'#0a0a0a'), fontWeight: sel===w.id?600:500, textAlign:'center' }}>{w.name}</div>
            </button>
          ))}
        </div>
      </Group>

      <Group dark={dark}>
        <LineRow dark={dark} chevron onClick={()=>{}}
          title={<span style={{ color:'var(--accent)' }}>Выбрать из фото…</span>}
          subtitle="Используйте своё изображение" isLast
        />
      </Group>
    </SubShell>
  );
}

// ═══════════════════════ 13. HELP ═══════════════════════
function HelpScreen({ dark, onBack }) {
  const sec = dark ? '#9e9e9e' : '#707070';
  const faqs = [
    { q:'Как Koto работает без номера телефона?', a:'Ваш аккаунт — это локальная пара ключей, производная от 13-словной фразы. Сервер никогда не знает, кто вы: только то, что этот ключ существует.' },
    { q:'Что если я потеряю телефон?', a:'Установите Koto на другом устройстве и восстановитесь из 13 слов. Без фразы никто не сможет расшифровать сообщения — даже мы.' },
    { q:'Можно ли сменить Koto ID?', a:'Koto ID детерминирован от фразы, поэтому да: сгенерируйте новую фразу. Старый ID становится неактивным, а ваши контакты увидят уведомление о смене.' },
    { q:'Как связаться с поддержкой?', a:'Через внутренний чат @koto-support. Мы не отправляем e-mail и не звоним.' },
  ];
  const [open, setOpen] = useStateSS(null);

  return (
    <SubShell title="Справка" dark={dark} onBack={onBack}>
      <Group label="Быстрые действия" dark={dark}>
        <LineRow dark={dark} chevron onClick={()=>{}} title={<span style={{ display:'flex', alignItems:'center', gap:8 }}><Ico.Search size={18} color="var(--accent)"/> Открыть базу знаний</span>}/>
        <LineRow dark={dark} chevron onClick={()=>{}} title={<span style={{ display:'flex', alignItems:'center', gap:8 }}><Ico.Pencil size={18} color="var(--accent)"/> Написать в @koto-support</span>}/>
        <LineRow dark={dark} chevron onClick={()=>{}} title={<span style={{ display:'flex', alignItems:'center', gap:8 }}><Ico.Alert size={18} color="#ff9f0a"/> Сообщить о проблеме</span>} isLast/>
      </Group>

      <Group label="Частые вопросы" dark={dark}>
        {faqs.map((f,i) => (
          <div key={i} style={{ position:'relative' }}>
            <div onClick={()=>setOpen(open===i?null:i)} className="press" style={{
              padding:'14px 16px', cursor:'pointer', display:'flex', alignItems:'center', gap:8,
              minHeight:52,
            }}>
              <div style={{ flex:1, fontSize:14.5, fontWeight:500, letterSpacing:-0.1 }}>{f.q}</div>
              <div style={{
                transform: open===i?'rotate(90deg)':'rotate(0deg)',
                transition:'transform 180ms',
              }}>
                <Ico.Chevron size={14} color={sec}/>
              </div>
            </div>
            {open===i && (
              <div style={{ padding:'0 16px 14px', fontSize:13.5, color:sec, lineHeight:1.5 }}>{f.a}</div>
            )}
            {i < faqs.length-1 && <div style={{ position:'absolute', bottom:0, left:16, right:0, height:0.5, background: dark?'rgba(255,255,255,0.06)':'rgba(0,0,0,0.06)' }}/>}
          </div>
        ))}
      </Group>

      <Group label="Юридическое" dark={dark}>
        <LineRow dark={dark} chevron onClick={()=>{}} title="Условия использования"/>
        <LineRow dark={dark} chevron onClick={()=>{}} title="Политика приватности"/>
        <LineRow dark={dark} chevron onClick={()=>{}} title="Открытый исходный код" isLast detail="GPL v3"/>
      </Group>
    </SubShell>
  );
}

// ═══════════════════════ 14. ABOUT ═══════════════════════
function AboutScreen({ dark, onBack }) {
  const sec = dark ? '#9e9e9e' : '#707070';
  const text = dark ? '#fff' : '#0a0a0a';
  return (
    <SubShell title="О Koto" dark={dark} onBack={onBack}>
      <div style={{ padding:'28px 24px 20px', textAlign:'center' }}>
        <div style={{
          width:80, height:80, borderRadius:22, margin:'0 auto',
          background: 'linear-gradient(135deg, var(--accent), #ff9f6a)',
          display:'flex', alignItems:'center', justifyContent:'center',
          boxShadow:'0 10px 30px rgba(255,107,53,0.35)',
          overflow:'hidden',
        }}>
          <img src="assets/koto-cat.png" alt="" style={{ width:'82%', height:'82%', objectFit:'contain', filter:'drop-shadow(0 2px 4px rgba(0,0,0,0.25))' }}/>
        </div>
        <div style={{ marginTop:14, fontSize:24, fontWeight:800, letterSpacing:-0.6 }}>Koto</div>
        <div style={{ fontSize:14, color:sec, marginTop:2, fontVariantNumeric:'tabular-nums' }}>версия 26.4.1 · сборка 2604.12</div>
        <div style={{ marginTop:12, fontSize:13.5, color:sec, lineHeight:1.5, maxWidth:280, margin:'12px auto 0' }}>
          Безопасный мессенджер без номера телефона. Ключи живут только у вас.
        </div>
      </div>

      <Group label="Информация" dark={dark}>
        <LineRow dark={dark} chevron onClick={()=>{}} title="Что нового" detail="26.4"/>
        <LineRow dark={dark} chevron onClick={()=>{}} title="Благодарности"/>
        <LineRow dark={dark} chevron onClick={()=>{}} title="Лицензии" detail="47 зависимостей" isLast/>
      </Group>

      <Group label="Ссылки" dark={dark}>
        <LineRow dark={dark} chevron onClick={()=>{}} title="Сайт" detail="koto.app"/>
        <LineRow dark={dark} chevron onClick={()=>{}} title="Статус серверов" detail={<span style={{ color:'#34c759', display:'flex', alignItems:'center', gap:4 }}><span style={{ width:6, height:6, borderRadius:3, background:'#34c759' }}/> норма</span>}/>
        <LineRow dark={dark} chevron onClick={()=>{}} title="GitHub" detail="koto-app/koto" isLast/>
      </Group>

      <div style={{ padding:'16px 24px 40px', textAlign:'center', fontSize:11.5, color:sec, lineHeight:1.5 }}>
        © 2026 Koto Foundation<br/>
        Сделано с 🧡 без телеметрии и без номеров
      </div>
    </SubShell>
  );
}

// ═══════════════════════ 15. KotoID / Seed (simple) ═══════════════════════
function KotoIdScreen({ dark, onBack, profile }) {
  const id = profile?.kotoId || '05a9f2c4e7b1d038f5c26e9a48103b5d7c91e2d64a58fc03bd917e4a62c85b71f0';
  const sec = dark ? '#9e9e9e' : '#707070';
  const [copied, setCopied] = useStateSS(false);
  const copy = () => { navigator.clipboard?.writeText(id); setCopied(true); setTimeout(()=>setCopied(false), 1400); };
  const chunks = id.match(/.{1,8}/g) || [];
  return (
    <SubShell title="Koto ID" dark={dark} onBack={onBack}>
      <div style={{ padding:'20px 16px 6px' }}>
        <div style={{ background: dark?'#1a1a1c':'#fff', borderRadius:14, padding:'18px 16px' }}>
          <div style={{ fontSize:12, color:sec, letterSpacing:0.5, textTransform:'uppercase', fontWeight:600 }}>Ваш Koto ID</div>
          <div style={{
            marginTop:10, fontFamily:'ui-monospace, SFMono-Regular, monospace', fontSize:13.5,
            letterSpacing:0.6, lineHeight:1.7, wordBreak:'break-all', color: dark?'#fff':'#0a0a0a',
          }}>
            {chunks.map((c,i)=>(
              <span key={i} style={{ marginRight:6, color: i%2?'var(--accent)':undefined }}>{c}</span>
            ))}
          </div>
          <div style={{ display:'flex', gap:8, marginTop:14 }}>
            <button onClick={copy} className="press" style={{
              flex:1, border:0, cursor:'pointer', padding:'10px 14px', borderRadius:10,
              background:'var(--accent)', color:'#fff', fontSize:14, fontWeight:600, fontFamily:'inherit',
              display:'flex', alignItems:'center', justifyContent:'center', gap:6,
            }}>
              {copied ? <Ico.CheckCircle size={16} color="#fff"/> : <Ico.Copy size={16} color="#fff"/>}
              {copied ? 'Скопировано' : 'Скопировать'}
            </button>
            <button className="press" style={{
              border:0, cursor:'pointer', padding:'10px 14px', borderRadius:10,
              background: dark?'#2a2a2e':'#f2f2f2', color: dark?'#fff':'#0a0a0a', fontSize:14, fontWeight:600, fontFamily:'inherit',
              display:'flex', alignItems:'center', justifyContent:'center', gap:6,
            }}>
              <Ico.Qr size={16} color={dark?'#fff':'#0a0a0a'}/>
              QR
            </button>
          </div>
        </div>
      </div>
      <div style={{ padding:'12px 24px 20px', fontSize:13, color:sec, lineHeight:1.45 }}>
        Koto ID можно свободно делиться. По нему нельзя найти ваш номер, почту или местоположение — только начать шифрованный чат.
      </div>
    </SubShell>
  );
}

function SeedScreen({ dark, onBack }) {
  const words = ['сокол','океан','гранит','роса','палуба','вектор','карат','ладья','мотив','эхо','зимний','терем','каштан'];
  const [shown, setShown] = useStateSS(false);
  const sec = dark ? '#9e9e9e' : '#707070';
  return (
    <SubShell title="Фраза восстановления" dark={dark} onBack={onBack}>
      <div style={{ padding:'18px 24px 8px', fontSize:13.5, color:sec, lineHeight:1.5 }}>
        13 слов — единственный способ восстановить аккаунт. Никто, кроме вас, их не знает.
        Храните в менеджере паролей или на бумаге — никогда в облачной заметке.
      </div>
      <div style={{ margin:'4px 16px 16px', borderRadius:16, overflow:'hidden', background: dark?'#1a1a1c':'#fff' }}>
        <div style={{ position:'relative', padding:'14px 14px 10px' }}>
          <div style={{ display:'grid', gridTemplateColumns:'repeat(2, 1fr)', gap:'6px 12px', filter: shown?'none':'blur(7px)', transition:'filter 200ms' }}>
            {words.map((w,i) => (
              <div key={i} style={{ display:'flex', alignItems:'center', gap:8, padding:'6px 0' }}>
                <div style={{
                  width:22, height:22, borderRadius:11, flexShrink:0,
                  background: dark?'#2a2a2e':'#eceef2', color: sec, fontSize:11, fontWeight:600,
                  display:'flex', alignItems:'center', justifyContent:'center', fontVariantNumeric:'tabular-nums',
                }}>{i+1}</div>
                <div style={{ fontSize:15, fontWeight:500, letterSpacing:-0.1 }}>{w}</div>
              </div>
            ))}
          </div>
          {!shown && (
            <div
              onClick={()=>setShown(true)}
              style={{
                position:'absolute', inset:0, display:'flex', flexDirection:'column',
                alignItems:'center', justifyContent:'center', cursor:'pointer',
                background: dark?'rgba(26,26,28,0.4)':'rgba(255,255,255,0.4)',
              }}>
              <Ico.Lock size={24} color="var(--accent)"/>
              <div style={{ marginTop:8, fontSize:14, fontWeight:600, color:'var(--accent)' }}>Нажмите, чтобы показать</div>
            </div>
          )}
        </div>
      </div>
      <Group dark={dark}>
        <LineRow dark={dark} chevron onClick={()=>{}} title="Проверить фразу" subtitle="Мы попросим ввести 3 случайных слова"/>
        <LineRow dark={dark} chevron onClick={()=>{}} isLast danger title="Перегенерировать фразу" subtitle="Koto ID и все чаты обнулятся"/>
      </Group>
    </SubShell>
  );
}

// ═══════════════════════ 16. NOTIFICATIONS ═══════════════════════
function NotificationsScreen({ dark, onBack }) {
  const [st, setSt] = useStateSS({
    enabled:true, preview:'name-msg', sound:'чистый', vibrate:true,
    group:true, mentions:true, reactions:false, calls:true,
  });
  const up = (k,v) => setSt(s => ({...s, [k]:v}));
  return (
    <SubShell title="Уведомления" dark={dark} onBack={onBack}>
      <Group dark={dark}>
        <LineRow dark={dark} isLast title="Уведомления Koto" subtitle="Показывать пуши и баннеры iOS" trailing={<Toggle dark={dark} value={st.enabled} onChange={(v)=>up('enabled',v)}/>}/>
      </Group>

      {st.enabled && (
        <>
          <Group label="Что показывать" dark={dark}>
            <RadioList value={st.preview} onChange={(v)=>up('preview',v)} dark={dark} options={[
              { v:'name-msg', l:'Имя и сообщение', s:'«Алина: пойдём?»' },
              { v:'name-only', l:'Только имя', s:'«Алина · новое сообщение»' },
              { v:'none', l:'Без содержимого', s:'«Koto · новое сообщение»' },
            ]}/>
          </Group>

          <Group label="Звук и вибрация" dark={dark}>
            <LineRow dark={dark} chevron onClick={()=>{}} title="Звук" detail={st.sound}/>
            <LineRow dark={dark} title="Вибрация" isLast trailing={<Toggle dark={dark} value={st.vibrate} onChange={(v)=>up('vibrate',v)}/>}/>
          </Group>

          <Group label="Типы" dark={dark}>
            <LineRow dark={dark} title="Группировать по чатам" trailing={<Toggle dark={dark} value={st.group} onChange={(v)=>up('group',v)}/>}/>
            <LineRow dark={dark} title="Упоминания и ответы" subtitle="Даже если чат заглушён" trailing={<Toggle dark={dark} value={st.mentions} onChange={(v)=>up('mentions',v)}/>}/>
            <LineRow dark={dark} title="Реакции" trailing={<Toggle dark={dark} value={st.reactions} onChange={(v)=>up('reactions',v)}/>}/>
            <LineRow dark={dark} title="Входящие звонки" isLast trailing={<Toggle dark={dark} value={st.calls} onChange={(v)=>up('calls',v)}/>}/>
          </Group>

          <Group label="Не беспокоить" dark={dark} footer="В это время пуши приходят беззвучно и не будят экран.">
            <LineRow dark={dark} chevron onClick={()=>{}} title="Расписание" detail="22:00 — 08:00"/>
            <LineRow dark={dark} chevron onClick={()=>{}} isLast title="Исключения" detail="Избранные · звонки"/>
          </Group>
        </>
      )}
    </SubShell>
  );
}

// ═══════════════════════ 17. CALLS ═══════════════════════
function CallsScreen({ dark, onBack }) {
  const [st, setSt] = useStateSS({
    callkit:true, wifi:true, ringtone:'Вечер', noise:true, video:'auto', relay:false,
  });
  const up = (k,v) => setSt(s => ({...s, [k]:v}));
  return (
    <SubShell title="Звонки" dark={dark} onBack={onBack}>
      <Group label="Система" dark={dark} footer="Koto-звонки выглядят как обычные iOS-вызовы и работают с Bluetooth, AirPods и автомобильными системами.">
        <LineRow dark={dark} title="Интеграция с iOS" subtitle="Показывать в журнале звонков iPhone" isLast trailing={<Toggle dark={dark} value={st.callkit} onChange={(v)=>up('callkit',v)}/>}/>
      </Group>

      <Group label="Качество" dark={dark}>
        <LineRow dark={dark} chevron onClick={()=>{}} title="Качество видео" detail={st.video==='auto'?'Авто':'Высокое'}/>
        <LineRow dark={dark} title="Подавление шума" subtitle="Фильтрует клавиатуру, улицу, вентилятор" isLast trailing={<Toggle dark={dark} value={st.noise} onChange={(v)=>up('noise',v)}/>}/>
      </Group>

      <Group label="Приватность" dark={dark} footer="Через сервер Koto ваш IP не будет виден собеседнику — работает для всех входящих от незнакомцев.">
        <LineRow dark={dark} title="Скрывать IP-адрес" subtitle="Все звонки идут через серверы Koto" isLast trailing={<Toggle dark={dark} value={st.relay} onChange={(v)=>up('relay',v)}/>}/>
      </Group>

      <Group label="Рингтон" dark={dark}>
        <LineRow dark={dark} chevron onClick={()=>{}} title="Мелодия" detail={st.ringtone}/>
        <LineRow dark={dark} chevron onClick={()=>{}} isLast title="Вибрация при входящем" detail="Стандартная"/>
      </Group>
    </SubShell>
  );
}

// ═══════════════════════ 18. EDIT PROFILE ═══════════════════════
function ProfileEditScreen({ dark, onBack, profile }) {
  const text = dark ? '#fff' : '#0a0a0a';
  const sec = dark ? '#9e9e9e' : '#707070';
  const [name, setName] = useStateSS(profile?.name || 'Дмитрий К.');
  const [bio, setBio] = useStateSS('Дизайнер · чай, коты и книги');
  return (
    <SubShell title="Профиль" dark={dark} onBack={onBack}>
      <div style={{ padding:'24px 16px 12px', display:'flex', flexDirection:'column', alignItems:'center' }}>
        <div style={{ position:'relative' }}>
          <Avatar contact={{ initials: name[0], color:'var(--accent)' }} size={104}/>
          <button className="press" style={{
            position:'absolute', bottom:0, right:0,
            width:32, height:32, borderRadius:16, border:`3px solid ${dark?'#0b0b0c':'#f2f2f2'}`,
            background:'var(--accent)', color:'#fff', cursor:'pointer', padding:0,
            display:'flex', alignItems:'center', justifyContent:'center',
          }}>
            <Ico.Pencil size={14} color="#fff"/>
          </button>
        </div>
        <div style={{ marginTop:10, fontSize:13, color:sec }}>Нажмите, чтобы изменить фото</div>
      </div>

      <Group label="Имя" dark={dark} footer="Видно только тем, с кем вы в переписке. Meta-серверы Koto не хранят имена.">
        <div style={{ padding:'12px 14px' }}>
          <input value={name} onChange={(e)=>setName(e.target.value)} style={{
            width:'100%', border:0, background:'transparent', outline:'none',
            fontSize:16, color:text, fontFamily:'inherit', letterSpacing:-0.2,
          }}/>
        </div>
      </Group>

      <Group label="О себе" dark={dark}>
        <div style={{ padding:'12px 14px' }}>
          <textarea value={bio} onChange={(e)=>setBio(e.target.value)} rows={3} style={{
            width:'100%', border:0, background:'transparent', outline:'none',
            fontSize:14.5, color:text, fontFamily:'inherit', letterSpacing:-0.1, resize:'none', lineHeight:1.45,
          }}/>
        </div>
      </Group>
    </SubShell>
  );
}

// ═══════════════════════ Fallback ═══════════════════════
function PlaceholderSub({ title, dark, onBack }) {
  const sec = dark ? '#9e9e9e' : '#707070';
  return (
    <SubShell title={title} dark={dark} onBack={onBack}>
      <div style={{ padding:'60px 40px', textAlign:'center', color:sec, fontSize:14 }}>
        Этот раздел ещё в работе.
      </div>
    </SubShell>
  );
}

window.NotificationsScreen = NotificationsScreen;
window.CallsScreen = CallsScreen;
window.ProfileEditScreen = ProfileEditScreen;
window.PlaceholderSub = PlaceholderSub;

// Expose
window.DevicesScreen = DevicesScreen;
window.UsernameScreen = UsernameScreen;
window.PrivacyScreen = PrivacyScreen;
window.EphemeralSettings = EphemeralSettings;
window.ScreenLockSettings = ScreenLockSettings;
window.SealedScreen = SealedScreen;
window.StorageScreen = StorageScreen;
window.NetworkScreen = NetworkScreen;
window.AutoDLScreen = AutoDLScreen;
window.ThemeScreen = ThemeScreen;
window.FontScreen = FontScreen;
window.WallpaperScreen = WallpaperScreen;
window.HelpScreen = HelpScreen;
window.AboutScreen = AboutScreen;
window.KotoIdScreen = KotoIdScreen;
window.SeedScreen = SeedScreen;
