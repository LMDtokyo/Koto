/* global React, Ico, Avatar, getContact */
// Call.jsx — CallScreen v2 with rich states + visualizers + particles + video morph

const { useState: useStateCall, useEffect: useEffectCall, useRef: useRefCall, useMemo: useMemoCall } = React;

// ─── Audio "amplitude" simulator ──────────────────────────
// We don't have real mic input — we simulate believable speech amplitude:
// a moving average of randomized peaks with quiet pockets and bursts.
function useFakeAmplitude(active = true, fps = 30) {
  const [amp, setAmp] = useStateCall(0);
  const stateRef = useRefCall({ talking: false, untilT: 0, baseline: 0, t: 0 });

  useEffectCall(() => {
    if (!active) { setAmp(0); return; }
    let raf;
    const tick = () => {
      const s = stateRef.current;
      s.t += 1/fps;
      // alternate between talking ~3s and silence ~1.2s
      if (s.t > s.untilT) {
        s.talking = !s.talking;
        s.untilT = s.t + (s.talking ? 2.5 + Math.random()*2 : 0.6 + Math.random()*1);
      }
      // base sine + noise
      let target;
      if (s.talking) {
        target = 0.45 + 0.35*Math.abs(Math.sin(s.t*8 + Math.sin(s.t*1.5)*2)) + Math.random()*0.2;
      } else {
        target = 0.04 + Math.random()*0.06;
      }
      // smooth toward target
      s.baseline += (target - s.baseline)*0.35;
      setAmp(Math.max(0, Math.min(1, s.baseline)));
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [active, fps]);

  return amp;
}

// ─── Live ticking timer ───────────────────────────────────
function useLiveTimer(running) {
  const [ms, setMs] = useStateCall(0);
  useEffectCall(() => {
    if (!running) return;
    const start = performance.now();
    let raf;
    const tick = (t) => {
      setMs(t - start);
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [running]);
  return ms;
}

function fmtTime(ms) {
  const s = Math.floor(ms/1000);
  const m = Math.floor(s/60);
  const ss = (s%60).toString().padStart(2,'0');
  const mm = m.toString().padStart(2,'0');
  // tenths for liveliness
  const tenths = Math.floor((ms%1000)/100);
  return { mm, ss, tenths };
}

// ─── Aurora background — animated radial gradient ─────────
function AuroraBG({ accent, intensity = 0.5 }) {
  const a = 0.55 + intensity*0.4;
  const blur = 80 + intensity*40;
  return (
    <div style={{ position:'absolute', inset:0, overflow:'hidden', background:'#050508' }}>
      <div style={{
        position:'absolute', top:'-10%', left:'-10%', right:'-10%', bottom:'-10%',
        background: `radial-gradient(60% 40% at 50% 30%, ${accent} 0%, transparent 60%)`,
        opacity: a,
        filter: `blur(${blur*0.3}px)`,
        animation:'auroraDrift 16s ease-in-out infinite',
      }}/>
      <div style={{
        position:'absolute', top:'-20%', left:'-20%', right:'-20%', bottom:'-20%',
        background: `radial-gradient(50% 35% at 30% 60%, #af52de 0%, transparent 70%)`,
        opacity: 0.45,
        filter: `blur(${blur*0.4}px)`,
        animation:'auroraDrift 22s ease-in-out -6s infinite reverse',
      }}/>
      <div style={{
        position:'absolute', top:'-20%', left:'-20%', right:'-20%', bottom:'-20%',
        background: `radial-gradient(45% 30% at 70% 70%, #3276ff 0%, transparent 70%)`,
        opacity: 0.35,
        filter: `blur(${blur*0.45}px)`,
        animation:'auroraDrift 28s ease-in-out -12s infinite',
      }}/>
      {/* film grain */}
      <div style={{
        position:'absolute', inset:0, opacity:0.06, mixBlendMode:'overlay',
        backgroundImage:'radial-gradient(rgba(255,255,255,0.6) 0.5px, transparent 0.6px)',
        backgroundSize:'3px 3px',
      }}/>
    </div>
  );
}

// ─── Particles that float; speed reacts to amplitude ─────
function ParticleField({ amp, accent, count = 36 }) {
  const items = useMemoCall(() => Array.from({ length: count }, (_, i) => ({
    x: Math.random()*100,
    y: 50 + (Math.random()-0.5)*50,
    r: 1.2 + Math.random()*2.6,
    speed: 0.3 + Math.random()*1.2,
    seed: Math.random()*1000,
    hue: i%5===0 ? accent : '#ffffff',
  })), [count, accent]);

  const [t, setT] = useStateCall(0);
  useEffectCall(() => {
    let raf;
    const tick = () => { setT(performance.now()/1000); raf = requestAnimationFrame(tick); };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, []);

  const speedMult = 1 + amp*4;

  return (
    <div style={{ position:'absolute', inset:0, pointerEvents:'none', overflow:'hidden' }}>
      {items.map((p,i) => {
        const drift = Math.sin(t*p.speed*speedMult + p.seed)*30;
        const lift  = (t*p.speed*speedMult*8 + p.seed) % 120;
        const y = (p.y - lift + 120) % 120;
        const opacity = 0.15 + amp*0.65 + (1 - Math.abs(y-50)/60)*0.2;
        return (
          <div key={i} style={{
            position:'absolute',
            left: `${(p.x + drift*0.3 + 100) % 100}%`,
            top: `${y}%`,
            width: p.r*2 + amp*4,
            height: p.r*2 + amp*4,
            borderRadius: '50%',
            background: p.hue,
            boxShadow: `0 0 ${4 + amp*16}px ${p.hue}`,
            opacity: Math.max(0.05, Math.min(0.9, opacity)),
            transform: 'translate(-50%, -50%)',
          }}/>
        );
      })}
    </div>
  );
}

// ─── Speaker visualizer — voice amplitude bars ─────────────
function VoiceBars({ amp, color = '#fff', bars = 5 }) {
  return (
    <div style={{ display:'inline-flex', alignItems:'center', gap:3, height:18 }}>
      {Array.from({length:bars}).map((_,i) => {
        const phase = (i/bars)*Math.PI*2;
        const h = 4 + Math.abs(Math.sin(performance.now()/120 + phase))*amp*16 + amp*4;
        return (
          <div key={i} style={{
            width:2.5, height:Math.max(3, h), borderRadius:2, background:color,
            opacity: 0.5 + amp*0.5,
            transition:'height 80ms linear',
          }}/>
        );
      })}
    </div>
  );
}

// ─── Encryption shimmer for "connecting" state ────────────
function ShimmerText({ text }) {
  return (
    <span style={{
      backgroundImage: 'linear-gradient(90deg, rgba(255,255,255,0.4) 0%, rgba(255,255,255,1) 50%, rgba(255,255,255,0.4) 100%)',
      backgroundSize: '200% 100%',
      WebkitBackgroundClip: 'text', backgroundClip: 'text',
      WebkitTextFillColor: 'transparent',
      animation: 'shimmer 1.6s linear infinite',
    }}>{text}</span>
  );
}

// ─── Pulsing aura around avatar ────────────────────────────
function AvatarAura({ amp, accent, size, state }) {
  const ringScale = 1 + amp*0.18;
  const haloScale = 1.55 + amp*0.6;
  const opacity = 0.25 + amp*0.55;

  const ringStyles = (factor, dur) => ({
    position:'absolute', top:'50%', left:'50%',
    width: size*factor, height: size*factor,
    transform:'translate(-50%, -50%)',
    borderRadius:'50%',
    border:`1.5px solid ${accent}`,
    opacity: 0,
    animation: state==='connected' ? `none` : `pulseRing ${dur}s ease-out infinite`,
  });

  return (
    <>
      {/* glow halo */}
      <div style={{
        position:'absolute', top:'50%', left:'50%',
        width: size*haloScale, height: size*haloScale,
        transform:`translate(-50%, -50%) scale(${ringScale})`,
        borderRadius:'50%',
        background: `radial-gradient(circle, ${accent}80 0%, transparent 70%)`,
        opacity, filter:'blur(24px)',
        transition:'transform 100ms linear',
      }}/>
      {state!=='connected' && (
        <>
          <div style={ringStyles(1.4, 2.2)}/>
          <div style={{...ringStyles(1.4, 2.2), animationDelay:'0.7s'}}/>
          <div style={{...ringStyles(1.4, 2.2), animationDelay:'1.4s'}}/>
        </>
      )}
    </>
  );
}

// ─── Incoming swipe accept/reject pad ─────────────────────
function IncomingPad({ onAccept, onReject, video, accent }) {
  const [accept, setAccept] = useStateCall(0);
  const [reject, setReject] = useStateCall(0);
  const startA = useRefCall(null), startR = useRefCall(null);

  const handle = (e, which, set, start) => {
    if (e.type === 'pointerdown') start.current = e.clientY;
    else if (e.type === 'pointermove' && start.current != null) {
      const dy = start.current - e.clientY;
      const v = Math.max(0, Math.min(1, dy / 110));
      set(v);
    } else if (e.type === 'pointerup' || e.type === 'pointercancel') {
      if (start.current != null) {
        const dy = start.current - e.clientY;
        const v = Math.max(0, Math.min(1, dy / 110));
        if (v > 0.7) which === 'accept' ? onAccept() : onReject();
      }
      start.current = null;
      set(0);
    }
  };

  const Btn = ({ which, set, val, color, glyph, label, start }) => (
    <div style={{ display:'flex', flexDirection:'column', alignItems:'center', gap:8 }}>
      <div style={{ position:'relative', width:74, height:74 }}>
        <div style={{
          position:'absolute', inset:0, borderRadius:'50%',
          background: color,
          transform:`translateY(${-val*60}px) scale(${1+val*0.15})`,
          transition: val===0?'transform 240ms cubic-bezier(.2,.8,.2,1)':'none',
          boxShadow: `0 ${10+val*20}px ${24+val*30}px ${color}66`,
        }}/>
        <div style={{
          position:'absolute', inset:0, display:'flex', alignItems:'center', justifyContent:'center',
          color:'#fff', transform:`translateY(${-val*60}px)`,
          transition: val===0?'transform 240ms cubic-bezier(.2,.8,.2,1)':'none',
        }}>{glyph}</div>
        <div
          onPointerDown={(e)=>handle(e,which,set,start)}
          onPointerMove={(e)=>handle(e,which,set,start)}
          onPointerUp={(e)=>handle(e,which,set,start)}
          onPointerCancel={(e)=>handle(e,which,set,start)}
          style={{ position:'absolute', inset:-10, cursor:'grab', touchAction:'none' }}
        />
      </div>
      <div style={{ fontSize:11, color:'rgba(255,255,255,0.7)', letterSpacing:0.3 }}>{label}</div>
    </div>
  );

  return (
    <div style={{
      position:'absolute', bottom:54, left:0, right:0, padding:'0 36px',
      display:'flex', justifyContent:'space-between', alignItems:'flex-end',
    }}>
      <Btn which="reject" set={setReject} val={reject} start={startR}
        color="#ff3b30" label="↑ свайп — отклонить"
        glyph={<div style={{ transform:'rotate(135deg)' }}><Ico.Phone size={26} color="#fff"/></div>}/>
      <div style={{
        flex:1, display:'flex', flexDirection:'column', alignItems:'center',
        color:'rgba(255,255,255,0.55)', fontSize:11, paddingBottom:6,
      }}>
        <div style={{ width:40, height:2, borderRadius:2, background:'rgba(255,255,255,0.25)', marginBottom:6 }}/>
        свайп вверх
      </div>
      <Btn which="accept" set={setAccept} val={accept} start={startA}
        color="#34c759" label="↑ свайп — принять"
        glyph={video ? <Ico.Video size={26} color="#fff"/> : <Ico.Phone size={26} color="#fff"/>}/>
    </div>
  );
}

// ─── Main CallScreen ──────────────────────────────────────
function CallScreen({ contactId, video, dark, onEnd, incoming = false }) {
  const c = getContact(contactId);
  const accent = c.color || '#ff6b35';

  // States: incoming → outgoing(ringing) → connecting → connected → reconnecting → ended
  const [state, setState] = useStateCall(incoming ? 'incoming' : 'outgoing');
  const [showVideo, setShowVideo] = useStateCall(false);
  const [ended, setEnded] = useStateCall(null); // { duration, quality }
  const [muted, setMuted] = useStateCall(false);
  const [speakerOn, setSpeakerOn] = useStateCall(false);
  const [cameraOn, setCameraOn] = useStateCall(video);

  // amplitude only in connected state, only when "they" are speaking
  const amp = useFakeAmplitude(state === 'connected');
  const myAmp = useFakeAmplitude(state === 'connected' && !muted) * 0.6;

  // Auto-progress: outgoing → connecting → connected
  useEffectCall(() => {
    if (state === 'outgoing') {
      const t1 = setTimeout(() => setState('connecting'), 2200);
      const t2 = setTimeout(() => setState('connected'), 3800);
      return () => { clearTimeout(t1); clearTimeout(t2); };
    }
    if (state === 'incoming') {
      // auto-accept after 8s if ignored, for demo
      const t = setTimeout(() => setState('outgoing'), 12000);
      return () => clearTimeout(t);
    }
  }, [state]);

  // Once-in-a-while reconnecting blip
  useEffectCall(() => {
    if (state !== 'connected') return;
    const t = setTimeout(() => {
      setState('reconnecting');
      setTimeout(() => setState('connected'), 1800);
    }, 24000); // after 24s of demo-call
    return () => clearTimeout(t);
  }, [state]);

  // Video morph: when user enables, fade in 800ms
  useEffectCall(() => {
    if (cameraOn && state === 'connected') {
      const t = setTimeout(() => setShowVideo(true), 60);
      return () => clearTimeout(t);
    } else { setShowVideo(false); }
  }, [cameraOn, state]);

  const callMs = useLiveTimer(state === 'connected' || state === 'reconnecting');
  const { mm, ss, tenths } = fmtTime(callMs);

  const accept = () => setState('outgoing'); // becomes connecting → connected
  const reject = () => endNow();
  const endNow = () => {
    setEnded({
      duration: callMs > 0 ? `${mm}:${ss}` : '0:00',
      quality: callMs > 0 ? 'отлично' : (state==='outgoing' ? 'не отвечен' : 'отменён'),
      video: cameraOn,
    });
    setState('ended');
    setTimeout(() => onEnd && onEnd(), 1600);
  };

  const stateLabel =
    state === 'incoming'    ? (video ? 'входящий видеозвонок' : 'входящий вызов')
  : state === 'outgoing'    ? 'вызов…'
  : state === 'connecting'  ? <ShimmerText text="устанавливаем шифрование"/>
  : state === 'reconnecting'? <ShimmerText text="восстанавливаем связь…"/>
  : state === 'ended'       ? 'завершено'
  : null;

  return (
    <div style={{ height:'100%', color:'#fff', position:'relative', overflow:'hidden', background:'#050508' }}>
      <AuroraBG accent={accent} intensity={state==='connected' ? 0.4 + amp*0.6 : 0.45}/>
      <ParticleField amp={state==='connected' ? amp : 0.2} accent={accent}/>

      {/* Top status */}
      <div style={{ position:'absolute', top:0, left:0, right:0, paddingTop:62, textAlign:'center', zIndex:5 }}>
        <div style={{ fontSize:12, opacity:0.65, display:'inline-flex', alignItems:'center', gap:6, letterSpacing:0.3 }}>
          <Ico.Lock size={11} color="#fff"/> Koto · сквозное шифрование
        </div>
        <div style={{ fontSize:30, fontWeight:700, letterSpacing:-0.7, marginTop:10 }}>{c.name}</div>
        <div style={{ fontSize:14, opacity:0.85, marginTop:6, height:20, display:'flex', alignItems:'center', justifyContent:'center', gap:8 }}>
          {state === 'connected' ? (
            <>
              <span className="mono" style={{ fontSize:15, fontVariantNumeric:'tabular-nums', display:'inline-flex', alignItems:'center' }}>
                {mm}:{ss}
                <span style={{
                  display:'inline-block', width:8, textAlign:'left',
                  marginLeft:2, opacity:0.55, fontSize:11,
                  transform:'translateY(-1px)',
                }}>.{tenths}</span>
              </span>
              {amp > 0.15 && <VoiceBars amp={amp} color={accent}/>}
            </>
          ) : stateLabel}
        </div>
      </div>

      {/* Video stream — morphs from avatar */}
      {video && (
        <VideoStream
          contact={c} accent={accent}
          show={showVideo} state={state}
        />
      )}

      {/* Avatar — hides when video active */}
      {!showVideo && (
        <div style={{
          position:'absolute', top:'34%', left:'50%', transform:'translate(-50%, -50%)',
          width: 200, height: 200, transition:'opacity 480ms, transform 480ms',
          opacity: state==='ended' ? 0 : 1,
        }}>
          <AvatarAura amp={state==='connected' ? amp : 0.2} accent={accent} size={200} state={state}/>
          <div style={{
            position:'absolute', inset:30,
            transform:`scale(${1 + (state==='connected'?amp*0.04:0)})`,
            transition:'transform 80ms linear',
          }}>
            <Avatar contact={c} size={140}/>
          </div>
        </div>
      )}

      {/* Self preview when video on */}
      {showVideo && (
        <div style={{
          position:'absolute', top:130, right:18,
          width:108, height:144, borderRadius:18, overflow:'hidden',
          background:`linear-gradient(135deg, #2a2a2e, #0a0a0c)`,
          border:'1.5px solid rgba(255,255,255,0.18)',
          boxShadow:'0 12px 32px rgba(0,0,0,0.5)',
          animation:'fadeInScale 380ms cubic-bezier(.2,.8,.2,1)',
        }}>
          <div style={{ position:'absolute', inset:0, background:`radial-gradient(circle at 50% 35%, var(--accent)40, transparent 60%)` }}/>
          <div style={{ position:'absolute', inset:0, display:'flex', alignItems:'center', justifyContent:'center',
            fontSize:42, fontWeight:700, color:'rgba(255,255,255,0.95)',
            transform:`scale(${1 + myAmp*0.06})`,
            transition:'transform 80ms linear',
          }}>Я</div>
          {myAmp > 0.2 && (
            <div style={{ position:'absolute', bottom:8, left:8 }}>
              <VoiceBars amp={myAmp} color="#fff" bars={3}/>
            </div>
          )}
        </div>
      )}

      {/* Reconnecting toast */}
      {state==='reconnecting' && (
        <div style={{
          position:'absolute', top:170, left:0, right:0, display:'flex', justifyContent:'center',
        }}>
          <div style={{
            background:'rgba(0,0,0,0.55)', backdropFilter:'blur(18px)', WebkitBackdropFilter:'blur(18px)',
            padding:'8px 14px', borderRadius:20, fontSize:13, display:'flex', alignItems:'center', gap:8,
            border:'0.5px solid rgba(255,255,255,0.12)',
          }}>
            <ConnectingDot/> ищем сеть…
          </div>
        </div>
      )}

      {/* Ended summary card */}
      {state==='ended' && ended && (
        <div style={{ position:'absolute', inset:0, display:'flex', alignItems:'center', justifyContent:'center', zIndex:10 }}>
          <div style={{
            background:'rgba(20,20,22,0.85)', backdropFilter:'blur(28px)', WebkitBackdropFilter:'blur(28px)',
            padding:'24px 26px', borderRadius:24, textAlign:'center',
            border:'0.5px solid rgba(255,255,255,0.12)', minWidth:260,
            animation:'fadeInScale 320ms cubic-bezier(.2,.8,.2,1)',
          }}>
            <div style={{ fontSize:13, opacity:0.6, letterSpacing:0.5, textTransform:'uppercase', fontWeight:600 }}>Звонок завершён</div>
            <div className="mono" style={{ fontSize:36, fontWeight:700, marginTop:10, fontVariantNumeric:'tabular-nums' }}>{ended.duration}</div>
            <div style={{ fontSize:13, opacity:0.7, marginTop:6 }}>качество: {ended.quality}</div>
          </div>
        </div>
      )}

      {/* Controls (incoming = swipe pad; else = control bar) */}
      {state === 'incoming' ? (
        <IncomingPad onAccept={accept} onReject={reject} video={video} accent={accent}/>
      ) : state !== 'ended' && (
        <div style={{ position:'absolute', bottom:46, left:0, right:0, padding:'0 18px' }}>
          <div style={{
            background:'rgba(20,20,22,0.55)', backdropFilter:'blur(28px)', WebkitBackdropFilter:'blur(28px)',
            borderRadius:30, padding:'14px 12px', display:'flex', justifyContent:'space-around', alignItems:'center',
            border:'0.5px solid rgba(255,255,255,0.1)',
            boxShadow:'0 16px 48px rgba(0,0,0,0.4)',
          }}>
            <CallBtn label={muted?'Без зв.':'Микро'} active={!muted} onClick={()=>setMuted(m=>!m)}
              icon={muted ? <MicOffGlyph/> : <MicGlyph/>}/>
            <CallBtn label="Динамик" active={speakerOn} onClick={()=>setSpeakerOn(s=>!s)} icon={<SpeakerGlyph on={speakerOn}/>}/>
            <CallBtn label="Камера" active={cameraOn} onClick={()=>setCameraOn(v=>!v)} icon={<CameraGlyph on={cameraOn}/>}/>
            <CallBtn label="Эффекты" icon={<SparkleGlyph/>}/>
            <button onClick={endNow} className="press" style={{
              width:62, height:62, borderRadius:'50%', background:'#ff3b30', border:0, cursor:'pointer',
              display:'flex', alignItems:'center', justifyContent:'center',
              boxShadow:'0 8px 24px rgba(255,59,48,0.45)',
              transform:'scale(1)',
            }}>
              <div style={{ transform:'rotate(135deg)' }}><Ico.Phone size={26} color="#fff"/></div>
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

// ─── Video stream placeholder — morphs from avatar ────────
function VideoStream({ contact, accent, show, state }) {
  // Animated gradient as faux video
  return (
    <div style={{
      position:'absolute', inset:0,
      opacity: show ? 1 : 0,
      transition:'opacity 600ms cubic-bezier(.2,.8,.2,1)',
      zIndex: 1,
    }}>
      <div style={{
        position:'absolute', inset:0,
        background:`
          radial-gradient(circle at 30% 35%, ${accent}88 0%, transparent 60%),
          radial-gradient(circle at 70% 70%, #af52de88 0%, transparent 60%),
          linear-gradient(160deg, #1a1a22 0%, #0a0a0c 100%)
        `,
        animation:'auroraDrift 12s ease-in-out infinite',
      }}/>
      <div style={{
        position:'absolute', inset:0, display:'flex', alignItems:'center', justifyContent:'center',
        flexDirection:'column', gap:18,
      }}>
        <div style={{
          width:140, height:140, borderRadius:'50%',
          background:`radial-gradient(circle, ${accent}, transparent 70%)`,
          filter:'blur(40px)',
        }}/>
        <div style={{
          fontSize:11, opacity:0.5, position:'absolute', bottom:200, padding:'4px 10px',
          background:'rgba(0,0,0,0.4)', borderRadius:12, backdropFilter:'blur(12px)', WebkitBackdropFilter:'blur(12px)',
        }}>видеопоток · 720p</div>
      </div>
    </div>
  );
}

// ─── Control button ───────────────────────────────────────
function CallBtn({ label, active, onClick, icon }) {
  return (
    <button onClick={onClick} className="press" style={{
      width:56, textAlign:'center', background:'transparent', border:0, cursor:'pointer', color:'#fff',
      padding:0,
    }}>
      <div style={{
        width:48, height:48, borderRadius:'50%', margin:'0 auto 6px',
        background: active ? '#fff' : 'rgba(255,255,255,0.12)',
        border:'0.5px solid rgba(255,255,255,0.18)',
        display:'flex', alignItems:'center', justifyContent:'center',
        color: active ? '#0a0a0a' : '#fff',
        transition:'background 180ms, color 180ms',
      }}>{icon}</div>
      <div style={{ fontSize:11, fontWeight:500, opacity:0.85 }}>{label}</div>
    </button>
  );
}

// ─── Inline glyphs for control buttons ────────────────────
function MicGlyph() {
  return <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
    <rect x="9" y="3" width="6" height="11" rx="3" stroke="currentColor" strokeWidth="1.7"/>
    <path d="M5 11a7 7 0 0014 0M12 18v3" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round"/>
  </svg>;
}
function MicOffGlyph() {
  return <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
    <rect x="9" y="3" width="6" height="11" rx="3" stroke="currentColor" strokeWidth="1.7"/>
    <path d="M5 11a7 7 0 0014 0M12 18v3M3 3l18 18" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round"/>
  </svg>;
}
function SpeakerGlyph({ on }) {
  return <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
    <path d="M3 9v6h4l5 5V4L7 9H3z" stroke="currentColor" strokeWidth="1.7" strokeLinejoin="round"/>
    {on && <path d="M16 9a5 5 0 010 6M19 6a9 9 0 010 12" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round"/>}
  </svg>;
}
function CameraGlyph({ on }) {
  return <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
    <rect x="3" y="6" width="14" height="12" rx="2" stroke="currentColor" strokeWidth="1.7"/>
    <path d="M17 10l5-3v10l-5-3z" stroke="currentColor" strokeWidth="1.7" strokeLinejoin="round"/>
    {!on && <path d="M3 3l18 18" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round"/>}
  </svg>;
}
function SparkleGlyph() {
  return <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
    <path d="M12 3l1.5 4.5L18 9l-4.5 1.5L12 15l-1.5-4.5L6 9l4.5-1.5L12 3zM18 14l1 3 3 1-3 1-1 3-1-3-3-1 3-1 1-3z" stroke="currentColor" strokeWidth="1.4" strokeLinejoin="round"/>
  </svg>;
}

function ConnectingDot() {
  return (
    <div style={{ display:'inline-flex', gap:3 }}>
      {[0,1,2].map(i => (
        <div key={i} style={{
          width:5, height:5, borderRadius:3, background:'#fff',
          animation:`bounceDot 1.2s ease-in-out ${i*0.18}s infinite`,
        }}/>
      ))}
    </div>
  );
}

window.CallScreen = CallScreen;
