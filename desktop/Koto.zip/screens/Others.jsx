/* global React, Ico, Avatar, KOTO_CONTACTS, getContact */
// Screens: NewChat, ContactProfile, Call, Stories, SettingsSubscreens

const { useState: useStateX, useEffect: useEffectX } = React;

// ─── New chat ─────────────────────────────────────────────
function NewChatScreen({ dark, onBack, onOpenChat }) {
  const bg = dark ? '#0b0b0c' : '#ffffff';
  const surface = dark ? '#1a1a1c' : '#f2f2f2';
  const text = dark ? '#fff' : '#0a0a0a';
  const sec = dark ? '#9e9e9e' : '#707070';
  const [q, setQ] = useStateX('');
  const [searching, setSearching] = useStateX(false);
  const [idResult, setIdResult] = useStateX(null);

  const trimmed = q.trim();
  const isHexIdLike = /^05[0-9a-f]{2,}$/i.test(trimmed);
  const isFullId = /^05[0-9a-f]{64}$/i.test(trimmed);

  // Koto ID lookup (simulated)
  useEffectX(() => {
    if (!isHexIdLike || trimmed.length < 8) { setSearching(false); setIdResult(null); return; }
    setSearching(true);
    setIdResult(null);
    const t = setTimeout(() => {
      // Check if it matches an existing contact
      const known = KOTO_CONTACTS.find(c => c.kotoId.toLowerCase().startsWith(trimmed.toLowerCase()));
      if (known) {
        setIdResult({ kind: 'known', contact: known });
      } else if (isFullId) {
        // Simulated "stranger" profile
        const seed = trimmed.slice(2, 4);
        const n = parseInt(seed, 16) % 6;
        const stranger = {
          id: 'stranger_' + trimmed.slice(2, 10),
          name: 'Незнакомый пользователь',
          initials: 'K',
          color: ['#7c5cff','#00a676','#3276ff','#f0b400','#ff6b35','#e74c6f'][n],
          kotoId: trimmed,
          status: 'не в ваших контактах',
        };
        setIdResult({ kind: 'stranger', contact: stranger });
      } else {
        setIdResult({ kind: 'partial' });
      }
      setSearching(false);
    }, 450);
    return () => clearTimeout(t);
  }, [trimmed]);

  // Regular contact search (name)
  const contactMatches = !isHexIdLike && trimmed
    ? KOTO_CONTACTS.filter(c => c.name.toLowerCase().includes(trimmed.toLowerCase()))
    : KOTO_CONTACTS;

  const letters = {};
  contactMatches.forEach(c => {
    const l = c.name[0].toUpperCase();
    (letters[l] = letters[l] || []).push(c);
  });

  return (
    <div style={{ height:'100%', background:bg, color:text, display:'flex', flexDirection:'column' }}>
      <div style={{ paddingTop:59, display:'flex', alignItems:'center', padding:'59px 12px 8px' }}>
        <button onClick={onBack} className="press" style={{ border:0, background:'transparent', cursor:'pointer', padding:8, display:'flex', alignItems:'center', gap:2 }}>
          <Ico.Back size={24} color="var(--accent)"/>
          <span style={{ color:'var(--accent)', fontSize:17 }}>Отмена</span>
        </button>
        <div style={{ flex:1, textAlign:'center', fontSize:16, fontWeight:700 }}>Новый чат</div>
        <div style={{ width:80 }}/>
      </div>
      <div style={{ padding:'4px 16px 10px' }}>
        <div style={{
          background:surface, borderRadius:12, minHeight:38,
          display:'flex', alignItems:'center', padding:'6px 12px', gap:8,
        }}>
          <Ico.Search size={17} color={sec}/>
          <input
            value={q} onChange={e=>setQ(e.target.value)}
            placeholder="Имя, @username или Koto ID (05…)"
            style={{ flex:1, border:0, background:'transparent', outline:'none', color:text, fontSize:15, fontFamily:'inherit', minWidth:0 }}
          />
          {q && (
            <button onClick={()=>setQ('')} className="press" style={{ border:0, background:'transparent', padding:2, cursor:'pointer' }}>
              <Ico.Close size={18} color={sec}/>
            </button>
          )}
        </div>
        {isHexIdLike && (
          <div style={{ marginTop:6, fontSize:12, color:sec, display:'flex', alignItems:'center', gap:6, padding:'0 4px' }}>
            <Ico.Lock size={12} color={sec}/>
            Поиск по Koto ID · только точное совпадение вернёт профиль
          </div>
        )}
      </div>

      {/* Koto ID search result panel */}
      {isHexIdLike && (
        <div style={{ padding:'4px 16px 6px' }}>
          {searching && (
            <div style={{
              background:surface, borderRadius:14, padding:'14px 16px',
              display:'flex', alignItems:'center', gap:12, color:sec, fontSize:14,
            }}>
              <div className="koto-spin" style={{
                width:18, height:18, borderRadius:9,
                border: `2px solid ${dark?'#2a2a2e':'#dcdce0'}`,
                borderTopColor: 'var(--accent)',
              }}/>
              Поиск в сети Koto…
            </div>
          )}
          {!searching && idResult && idResult.kind === 'known' && (
            <div
              onClick={()=>onOpenChat(idResult.contact.id)}
              className="press"
              style={{
                background:surface, borderRadius:14, padding:'12px 14px',
                display:'flex', alignItems:'center', gap:12, cursor:'pointer',
                border:`1px solid ${dark?'rgba(255,255,255,0.06)':'rgba(0,0,0,0.05)'}`,
              }}
            >
              <Avatar contact={idResult.contact} size={44}/>
              <div style={{ flex:1, minWidth:0 }}>
                <div style={{ display:'flex', alignItems:'center', gap:6 }}>
                  <div style={{ fontSize:15.5, fontWeight:600, letterSpacing:-0.2 }}>{idResult.contact.name}</div>
                  <div style={{
                    fontSize:10.5, color:'#34c759', background:dark?'rgba(52,199,89,0.15)':'rgba(52,199,89,0.12)',
                    padding:'2px 6px', borderRadius:6, fontWeight:600, letterSpacing:0.2, textTransform:'uppercase',
                  }}>В контактах</div>
                </div>
                <div style={{ fontSize:12, color:sec, marginTop:2, fontVariantNumeric:'tabular-nums', fontFamily:'ui-monospace, SFMono-Regular, monospace' }}>
                  {idResult.contact.kotoId.slice(0,10)}…{idResult.contact.kotoId.slice(-6)}
                </div>
              </div>
              <Ico.ChevronRight size={18} color={sec}/>
            </div>
          )}
          {!searching && idResult && idResult.kind === 'stranger' && (
            <div style={{
              background:surface, borderRadius:14, padding:'14px 14px 12px',
              border:`1px solid ${dark?'rgba(255,159,10,0.25)':'rgba(255,159,10,0.35)'}`,
            }}>
              <div style={{ display:'flex', alignItems:'center', gap:12 }}>
                <Avatar contact={idResult.contact} size={44}/>
                <div style={{ flex:1, minWidth:0 }}>
                  <div style={{ fontSize:15.5, fontWeight:600, letterSpacing:-0.2 }}>Найден профиль</div>
                  <div style={{ fontSize:12, color:sec, marginTop:2, fontFamily:'ui-monospace, SFMono-Regular, monospace' }}>
                    {idResult.contact.kotoId.slice(0,14)}…{idResult.contact.kotoId.slice(-8)}
                  </div>
                </div>
              </div>
              <div style={{
                marginTop:10, padding:'8px 10px', borderRadius:10,
                background: dark?'rgba(255,159,10,0.12)':'rgba(255,159,10,0.1)',
                color: dark?'#ffbf5f':'#b36a00',
                fontSize:12, lineHeight:1.4, display:'flex', gap:8, alignItems:'flex-start',
              }}>
                <div style={{ flexShrink:0, marginTop:1 }}>
                  <Ico.Lock size={12} color={dark?'#ffbf5f':'#b36a00'}/>
                </div>
                Этот Koto ID не в ваших контактах. Сравните номер безопасности в первом чате.
              </div>
              <button
                onClick={()=>onOpenChat(idResult.contact.id)}
                className="press"
                style={{
                  marginTop:10, width:'100%', border:0, cursor:'pointer',
                  background:'var(--accent)', color:'#fff',
                  padding:'10px 14px', borderRadius:10,
                  fontSize:15, fontWeight:600, fontFamily:'inherit',
                }}
              >Начать чат</button>
            </div>
          )}
          {!searching && idResult && idResult.kind === 'partial' && (
            <div style={{
              background:surface, borderRadius:14, padding:'14px 16px', color:sec, fontSize:13.5, lineHeight:1.4,
            }}>
              Продолжайте вводить. Полный Koto ID — 66 символов (05 + 64 hex).
              Сейчас введено {trimmed.length} из 66.
              <div style={{
                marginTop:8, height:4, borderRadius:2,
                background: dark?'#2a2a2e':'#e2e2e6', overflow:'hidden',
              }}>
                <div style={{
                  width: `${(trimmed.length/66)*100}%`, height:'100%',
                  background:'var(--accent)', transition:'width 180ms',
                }}/>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Action tiles */}
      {!isHexIdLike && (
        <div style={{ padding:'6px 16px 12px', display:'flex', gap:10 }}>
          <ActionTile
            icon={<GroupGlyph color="var(--accent)"/>}
            title="Новая группа" dark={dark}
          />
          <ActionTile
            icon={<Ico.Qr size={22} color="var(--accent)"/>}
            title="Сканировать QR" dark={dark}
          />
          <ActionTile
            icon={<InviteGlyph color="var(--accent)"/>}
            title="Пригласить" dark={dark}
          />
        </div>
      )}

      {/* Contacts list */}
      {!isHexIdLike && (
        <div className="koto-scroll" style={{ flex:1, overflowY:'auto', paddingBottom:40 }}>
          {contactMatches.length === 0 && (
            <div style={{ padding:'40px 20px', textAlign:'center', color:sec, fontSize:14 }}>
              Никого не нашли. Попробуйте ввести Koto ID.
            </div>
          )}
          {Object.keys(letters).sort().map(l => (
            <div key={l}>
              <div style={{
                padding:'8px 20px 4px', fontSize:12, color:sec, fontWeight:600,
                background:dark?'#0b0b0c':'#fff',
              }}>{l}</div>
              {letters[l].map((c) => (
                <div
                  key={c.id}
                  onClick={()=>onOpenChat(c.id)}
                  className="press"
                  style={{
                    display:'flex', alignItems:'center', gap:12,
                    padding:'8px 20px', cursor:'pointer', minHeight:60,
                  }}
                >
                  <Avatar contact={c} size={44}/>
                  <div style={{ flex:1, minWidth:0 }}>
                    <div style={{ fontSize:15.5, fontWeight:600, letterSpacing:-0.2 }}>{c.name}</div>
                    <div style={{ fontSize:12.5, color:sec, marginTop:2, overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap' }}>
                      {c.status}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

// Line-art glyphs for NewChat action tiles
function GroupGlyph({ color }) {
  return (
    <svg width="22" height="22" viewBox="0 0 24 24" fill="none">
      <circle cx="9" cy="9" r="3.2" stroke={color} strokeWidth="1.8"/>
      <circle cx="16.5" cy="8" r="2.4" stroke={color} strokeWidth="1.8"/>
      <path d="M3 19c0-3 3-5 6-5s6 2 6 5M14.5 14c2.5 0 5 1.6 5 4" stroke={color} strokeWidth="1.8" strokeLinecap="round"/>
    </svg>
  );
}
function InviteGlyph({ color }) {
  return (
    <svg width="22" height="22" viewBox="0 0 24 24" fill="none">
      <path d="M12 4v12M6 10l6-6 6 6" stroke={color} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"/>
      <path d="M4 16v2a2 2 0 002 2h12a2 2 0 002-2v-2" stroke={color} strokeWidth="1.8" strokeLinecap="round"/>
    </svg>
  );
}

function ActionTile({ icon, title, dark }) {
  const surface = dark ? '#1a1a1c' : '#f2f2f2';
  return (
    <div className="press" style={{ flex:1, background:surface, borderRadius:14, padding:'14px 10px', textAlign:'center', cursor:'pointer' }}>
      <div style={{ fontSize:22, marginBottom:6 }}>{icon}</div>
      <div style={{ fontSize:12, fontWeight:600, letterSpacing:-0.1 }}>{title}</div>
    </div>
  );
}

// ─── Contact profile ─────────────────────────────────────
function ContactProfileScreen({ contactId, dark, onBack, onSafety, onEphemeral }) {
  const c = getContact(contactId);
  const bg = dark ? '#0b0b0c' : '#f2f2f2';
  const card = dark ? '#1a1a1c' : '#ffffff';
  const text = dark ? '#fff' : '#0a0a0a';
  const sec = dark ? '#9e9e9e' : '#707070';
  const [copied, setCopied] = useStateX(false);
  const isGroup = c.phone && c.phone.includes('групп');
  const isBot = !!c.isBot;

  return (
    <div style={{ height:'100%', background:bg, color:text, overflow:'auto' }} className="koto-scroll">
      <div style={{ paddingTop:59, display:'flex', alignItems:'center', padding:'59px 12px 8px' }}>
        <button onClick={onBack} className="press" style={{ border:0, background:'transparent', cursor:'pointer', padding:8, display:'flex', alignItems:'center', color:'var(--accent)' }}>
          <Ico.Back size={24} color="var(--accent)"/>
        </button>
        <div style={{ flex:1 }}/>
        <button className="press" style={{ border:0, background:'transparent', cursor:'pointer', padding:8, color:'var(--accent)', fontSize:15, fontWeight:500 }}>Изм.</button>
      </div>
      <div style={{ textAlign:'center', padding:'10px 24px 24px' }}>
        <div style={{ display:'inline-block', marginBottom:14 }}>
          <Avatar contact={c} size={112}/>
        </div>
        <div style={{ fontSize:26, fontWeight:700, letterSpacing:-0.5, display:'inline-flex', alignItems:'center', gap:6 }}>
          {c.name}
          {isBot && (
            <span style={{ background:c.color||'var(--accent)', color:'#fff', fontSize:9, fontWeight:800, padding:'2px 5px', borderRadius:4, letterSpacing:0.4, verticalAlign:'middle' }}>BOT</span>
          )}
        </div>
        {isBot ? (
          <>
            <div style={{ fontSize:14, color:sec, marginTop:4 }}>{c.handle || c.phone}</div>
            <div style={{ fontSize:14, color:text, marginTop:10, padding:'0 20px', lineHeight:1.45, maxWidth:300, marginLeft:'auto', marginRight:'auto', textWrap:'pretty' }}>
              {c.tagline}
            </div>
            <div style={{ fontSize:12, color:sec, marginTop:10, display:'inline-flex', alignItems:'center', gap:4 }}>
              👤 {c.users||'—'} · {c.category||'Бот'}
            </div>
          </>
        ) : isGroup ? (
          <div style={{ fontSize:14, color:sec, marginTop:4 }}>{c.phone}</div>
        ) : (
          <div
            onClick={() => { navigator.clipboard && navigator.clipboard.writeText(c.kotoId); setCopied(true); setTimeout(()=>setCopied(false),1500); }}
            className="mono press"
            style={{
              marginTop:8, display:'inline-block', cursor:'pointer',
              padding:'6px 12px', borderRadius:10,
              background: dark?'#1a1a1c':'#fff',
              fontSize:11, color:text, letterSpacing:0.3, maxWidth:280,
              wordBreak:'break-all', lineHeight:1.4,
            }}>
            {copied ? '✓ скопирован' : (c.kotoId ? c.kotoId.slice(0,12)+'…'+c.kotoId.slice(-8) : '')}
          </div>
        )}
        {!isBot && (
          <div style={{ fontSize:13, color:'var(--accent)', marginTop:8, display:'inline-flex', alignItems:'center', gap:4 }}>
            <Ico.Lock size={11} color="var(--accent)"/> end-to-end шифрование
          </div>
        )}
      </div>
      <div style={{ display:'flex', gap:10, padding:'0 20px 20px', justifyContent:'center' }}>
        {(isBot ? [
          { i: <Ico.Send size={20} color="var(--accent)"/>, l: 'Написать' },
          { i: <Ico.Plus size={22} color="var(--accent)"/>, l: 'В чат' },
          { i: <Ico.Mute size={22} color="var(--accent)"/>, l: 'Без звука' },
          { i: <Ico.Alert size={22} color="var(--accent)"/>, l: 'Жалоба' },
        ] : [
          { i: <Ico.Phone size={22} color="var(--accent)"/>, l: 'Аудио' },
          { i: <Ico.Video size={22} color="var(--accent)"/>, l: 'Видео' },
          { i: <Ico.Mute size={22} color="var(--accent)"/>, l: 'Без звука' },
          { i: <Ico.Search size={22} color="var(--accent)"/>, l: 'Поиск' },
        ]).map((b,i) => (
          <div key={i} className="press" style={{ flex:1, background:card, borderRadius:14, padding:'14px 6px', textAlign:'center', cursor:'pointer' }}>
            <div style={{ display:'flex', justifyContent:'center' }}>{b.i}</div>
            <div style={{ fontSize:11.5, fontWeight:600, marginTop:4, color:'var(--accent)' }}>{b.l}</div>
          </div>
        ))}
      </div>

      {isBot ? (
        <>
          <ProfileSection title="О боте" dark={dark}>
            <div style={{ padding:'14px 16px', fontSize:14, lineHeight:1.5, color:text, textWrap:'pretty' }}>
              {c.description || c.tagline}
            </div>
          </ProfileSection>
          {c.commands && c.commands.length > 0 && (
            <ProfileSection title="Команды" dark={dark}>
              {c.commands.map((cmd, i) => (
                <div key={cmd.c} style={{ display:'flex', alignItems:'baseline', gap:10, padding:'10px 14px', borderBottom: i<c.commands.length-1 ? `0.5px solid ${dark?'rgba(255,255,255,0.06)':'rgba(0,0,0,0.06)'}` : 'none' }}>
                  <div className="mono" style={{ fontSize:13, color:'var(--accent)', fontWeight:600, minWidth:78 }}>{cmd.c}</div>
                  <div style={{ fontSize:13.5, color:sec, flex:1 }}>{cmd.d}</div>
                </div>
              ))}
            </ProfileSection>
          )}
          {c.webApp && (
            <ProfileSection title="Мини-приложение" dark={dark}>
              <ProfileRow icon="▶" tint={c.color||'#ff6b35'} title={`Открыть «${c.webApp.name}»`} detail="WebApp" isLast dark={dark}/>
            </ProfileSection>
          )}
          <ProfileSection title="" dark={dark}>
            <ProfileRow icon="🔕" tint="#707070" title="Без звука" detail="выкл" dark={dark}/>
            <ProfileRow icon="⚠" tint="#ff9500" title="Пожаловаться" dark={dark}/>
            <ProfileRow icon="⊘" tint="#ff453a" title="Заблокировать и удалить" danger isLast dark={dark}/>
          </ProfileSection>
        </>
      ) : (
        <>
          <ProfileSection title="Безопасность" dark={dark}>
            <ProfileRow icon="✓" tint="#00a676" title="Проверить номер безопасности" detail="не проверено" onClick={onSafety} dark={dark}/>
            <ProfileRow icon="⏱" tint="#ff6b35" title="Исчезающие сообщения" detail="выкл" onClick={onEphemeral} dark={dark}/>
            <ProfileRow icon="🔕" tint="#707070" title="Без звука" detail="выкл" isLast dark={dark}/>
          </ProfileSection>

          <ProfileSection title="Медиа и файлы" dark={dark}>
            <ProfileRow icon="📷" tint="#3276ff" title="Фото и видео" detail="42" dark={dark}/>
            <ProfileRow icon="🔗" tint="#7c5cff" title="Ссылки" detail="12" dark={dark}/>
            <ProfileRow icon="📄" tint="#ff6b35" title="Документы" detail="3" isLast dark={dark}/>
          </ProfileSection>

          <ProfileSection title="" dark={dark}>
            <ProfileRow icon="⚠" tint="#ff453a" title="Заблокировать" danger isLast dark={dark}/>
          </ProfileSection>
        </>
      )}

      <div style={{ height:80 }}/>
    </div>
  );
}

function ProfileSection({ title, children, dark }) {
  const sec = dark ? '#9e9e9e' : '#707070';
  const card = dark ? '#1a1a1c' : '#ffffff';
  return (
    <div style={{ marginBottom:20 }}>
      {title && <div style={{ padding:'0 24px 6px', fontSize:12, fontWeight:600, color:sec, textTransform:'uppercase', letterSpacing:0.6 }}>{title}</div>}
      <div style={{ margin:'0 16px', background:card, borderRadius:16, overflow:'hidden' }}>{children}</div>
    </div>
  );
}

function ProfileRow({ icon, tint, title, detail, isLast, onClick, dark, danger }) {
  const text = dark ? '#fff' : '#0a0a0a';
  const sec = dark ? '#9e9e9e' : '#707070';
  const sep = dark ? 'rgba(255,255,255,0.06)' : 'rgba(0,0,0,0.06)';
  return (
    <div onClick={onClick} className="press" style={{ display:'flex', alignItems:'center', gap:12, padding:'10px 14px', cursor: onClick?'pointer':'default', minHeight:48, position:'relative' }}>
      <div style={{ width:28, height:28, borderRadius:7, background:tint, color:'#fff', display:'flex', alignItems:'center', justifyContent:'center', fontSize:14, fontWeight:700 }}>{icon}</div>
      <div style={{ flex:1, fontSize:15, color: danger?'#ff453a':text }}>{title}</div>
      {detail && <div style={{ fontSize:13.5, color:sec }}>{detail}</div>}
      {onClick && <Ico.Chevron size={13} color={dark?'#5e5e62':'#c7c7cc'}/>}
      {!isLast && <div style={{ position:'absolute', bottom:0, left:54, right:0, height:0.5, background:sep }}/>}
    </div>
  );
}

// ─── Call ────────────────────────────────────────────────
function CallScreen({ contactId, video, dark, onEnd }) {
  const c = getContact(contactId);
  const [elapsed, setElapsed] = useStateX(0);
  const [state, setState] = useStateX('ringing'); // ringing | connected
  useEffectX(() => {
    const t = setTimeout(() => setState('connected'), 2400);
    return () => clearTimeout(t);
  }, []);
  useEffectX(() => {
    if (state !== 'connected') return;
    const i = setInterval(() => setElapsed(e => e+1), 1000);
    return () => clearInterval(i);
  }, [state]);
  const mmss = `${Math.floor(elapsed/60).toString().padStart(2,'0')}:${(elapsed%60).toString().padStart(2,'0')}`;

  return (
    <div style={{ height:'100%', color:'#fff', position:'relative', overflow:'hidden',
      background: video
        ? `linear-gradient(160deg, ${c.color} 0%, #0a0a0a 100%)`
        : `radial-gradient(900px 700px at 50% 30%, ${c.color}, #0a0a0a 60%)`,
    }}>
      {/* decorative rings */}
      {state==='ringing' && (
        <>
          <Ring size={260} delay={0}/>
          <Ring size={380} delay={0.6}/>
          <Ring size={500} delay={1.2}/>
        </>
      )}
      <div style={{ position:'absolute', top:0, left:0, right:0, paddingTop:74, textAlign:'center' }}>
        <div style={{ fontSize:13, opacity:0.7, display:'inline-flex', alignItems:'center', gap:6 }}>
          <Ico.Lock size={11} color="#fff"/> Koto · {video?'Видеозвонок':'Аудио'}
        </div>
        <div style={{ fontSize:32, fontWeight:700, letterSpacing:-0.8, marginTop:8 }}>{c.name}</div>
        <div className="mono" style={{ fontSize:15, opacity:0.8, marginTop:4 }}>
          {state==='ringing' ? 'соединение…' : mmss}
        </div>
      </div>
      <div style={{ position:'absolute', top: 220, left:0, right:0, display:'flex', justifyContent:'center' }}>
        <div style={{ animation: state==='ringing' ? 'pulseAvatar 2s infinite' : 'none', borderRadius:'50%' }}>
          <Avatar contact={c} size={168}/>
        </div>
      </div>
      {video && state==='connected' && (
        <div style={{
          position:'absolute', bottom:180, right:20, width:110, height:148, borderRadius:18, overflow:'hidden',
          background: `linear-gradient(135deg, #ff6b35, #7c5cff)`, border:'2px solid rgba(255,255,255,0.2)',
          boxShadow:'0 8px 24px rgba(0,0,0,0.4)',
        }}>
          <div style={{ position:'absolute', inset:0, display:'flex', alignItems:'center', justifyContent:'center', color:'#fff', fontSize:34, fontWeight:700 }}>Я</div>
        </div>
      )}
      {/* Controls */}
      <div style={{ position:'absolute', bottom:54, left:0, right:0, padding:'0 24px' }}>
        <div style={{
          background:'rgba(20,20,22,0.7)', backdropFilter:'blur(24px)', WebkitBackdropFilter:'blur(24px)',
          borderRadius:28, padding:'16px 14px', display:'flex', justifyContent:'space-around', alignItems:'center',
          border:'0.5px solid rgba(255,255,255,0.08)',
        }}>
          <CallBtn label="Микро" active/>
          <CallBtn label="Динам."/>
          <CallBtn label="Видео" active={video}/>
          <button onClick={onEnd} className="press" style={{
            width:62, height:62, borderRadius:'50%', background:'#ff3b30', border:0, cursor:'pointer',
            display:'flex', alignItems:'center', justifyContent:'center',
            boxShadow:'0 6px 20px rgba(255,59,48,0.45)',
          }}>
            <div style={{ transform:'rotate(135deg)' }}><Ico.Phone size={26} color="#fff"/></div>
          </button>
        </div>
      </div>
    </div>
  );
}
function Ring({ size, delay }) {
  return <div style={{
    position:'absolute', top:'28%', left:'50%', width:size, height:size,
    borderRadius:'50%', border:'1px solid rgba(255,255,255,0.15)',
    transform:`translate(-50%, -50%)`,
    animation:`pulseAvatar 3s infinite ${delay}s`,
  }}/>;
}
function CallBtn({ label, active }) {
  return (
    <button className="press" style={{
      width:56, textAlign:'center', background:'transparent', border:0, cursor:'pointer', color:'#fff',
    }}>
      <div style={{
        width:44, height:44, borderRadius:'50%', margin:'0 auto 6px',
        background: active ? '#fff' : 'rgba(255,255,255,0.12)',
        border:'0.5px solid rgba(255,255,255,0.2)',
        display:'flex', alignItems:'center', justifyContent:'center',
      }}>
        <div style={{ width:18, height:18, borderRadius:4, background: active ? '#0a0a0a' : '#fff' }}/>
      </div>
      <div style={{ fontSize:11, fontWeight:500, opacity:0.9 }}>{label}</div>
    </button>
  );
}

// ─── Stories tab ─────────────────────────────────────────
function StoriesScreen({ dark, onBack }) {
  const bg = dark ? '#0b0b0c' : '#ffffff';
  const surface = dark ? '#1a1a1c' : '#f2f2f2';
  const text = dark ? '#fff' : '#0a0a0a';
  const sec = dark ? '#9e9e9e' : '#707070';

  const stories = KOTO_CONTACTS.slice(0,6).map((c,i) => ({
    ...c, seen: i>=3, time: ['5 мин','14 мин','1 ч','3 ч','5 ч','вчера'][i],
  }));

  return (
    <div style={{ height:'100%', background:bg, color:text, display:'flex', flexDirection:'column' }}>
      <div style={{ paddingTop:59, padding:'59px 16px 6px', display:'flex', alignItems:'center' }}>
        <button onClick={onBack} className="press" style={{ border:0, background:'transparent', cursor:'pointer', padding:6, color:'var(--accent)', display:'flex', alignItems:'center' }}>
          <Ico.Back size={24} color="var(--accent)"/>
        </button>
        <div style={{ flex:1 }}/>
        <button className="press" style={{ border:0, background:'transparent', cursor:'pointer', padding:6, color:'var(--accent)', fontSize:15 }}>Конфид.</button>
      </div>
      <div style={{ padding:'4px 20px 10px', fontSize:34, fontWeight:800, letterSpacing:-1 }}>Истории</div>
      <div style={{ padding:'0 16px 14px' }}>
        <div className="press" style={{
          background:surface, borderRadius:18, padding:14, display:'flex', alignItems:'center', gap:14, cursor:'pointer',
        }}>
          <div style={{ position:'relative' }}>
            <Avatar contact={{ initials:'Я', color:'var(--accent)' }} size={52}/>
            <div style={{ position:'absolute', right:-4, bottom:-4, width:22, height:22, borderRadius:'50%', background:'var(--accent)', border:`2px solid ${surface}`, color:'#fff', display:'flex', alignItems:'center', justifyContent:'center', fontSize:16, fontWeight:700, lineHeight:1 }}>+</div>
          </div>
          <div style={{ flex:1 }}>
            <div style={{ fontSize:15.5, fontWeight:600 }}>Моя история</div>
            <div style={{ fontSize:12.5, color:sec, marginTop:2 }}>Только выбранным получателям</div>
          </div>
        </div>
      </div>
      <div style={{ padding:'0 20px 6px', fontSize:12, fontWeight:600, color:sec, textTransform:'uppercase', letterSpacing:0.6 }}>Все истории</div>
      <div className="koto-scroll" style={{ flex:1, overflowY:'auto', padding:'4px 0 80px' }}>
        {stories.map(s => (
          <div key={s.id} className="press" style={{ display:'flex', alignItems:'center', gap:12, padding:'10px 20px', cursor:'pointer' }}>
            <div style={{
              padding:2, borderRadius:'50%',
              background: s.seen ? 'transparent' : `conic-gradient(from 180deg, #ff6b35, #ffaa4c, #ff6b35)`,
              border: s.seen ? `1.5px dashed ${sec}` : 0,
            }}>
              <div style={{ padding: s.seen ? 0 : 2, background:bg, borderRadius:'50%' }}>
                <Avatar contact={s} size={52}/>
              </div>
            </div>
            <div style={{ flex:1 }}>
              <div style={{ fontSize:15.5, fontWeight:600 }}>{s.name}</div>
              <div style={{ fontSize:12.5, color: s.seen ? sec : 'var(--accent)', marginTop:2 }}>
                {s.seen ? 'просмотрено · ' : 'новая · '}{s.time}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

window.NewChatScreen = NewChatScreen;
window.ContactProfileScreen = ContactProfileScreen;
window.CallScreen = CallScreen;
window.StoriesScreen = StoriesScreen;
