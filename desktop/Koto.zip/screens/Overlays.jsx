/* global React, Ico, Avatar, getContact */
// Overlays: Safety, ScreenLock, Ephemeral, MediaPicker, AttachSheet

const { useState: useStateO, useEffect: useEffectO } = React;

// ─── Safety number ───────────────────────────────────────
function SafetyScreen({ contactId, dark, onBack }) {
  const c = getContact(contactId);
  const bg = dark ? '#0b0b0c' : '#ffffff';
  const text = dark ? '#fff' : '#0a0a0a';
  const sec = dark ? '#9e9e9e' : '#707070';
  const card = dark ? '#1a1a1c' : '#f6f6f6';
  const [verified, setVerified] = useStateO(false);

  // Generate 12 x 5-digit blocks deterministically from id
  const blocks = [];
  let seed = c.id.split('').reduce((s,ch)=>s+ch.charCodeAt(0), 42);
  for (let i=0;i<12;i++) {
    seed = (seed * 9301 + 49297) % 233280;
    blocks.push(String(10000 + Math.floor((seed/233280)*89999)).slice(0,5));
  }

  return (
    <div style={{ height:'100%', background:bg, color:text, display:'flex', flexDirection:'column' }}>
      <div style={{ paddingTop:59, padding:'59px 12px 8px', display:'flex', alignItems:'center' }}>
        <button onClick={onBack} className="press" style={{ border:0, background:'transparent', cursor:'pointer', padding:8, display:'flex', alignItems:'center', color:'var(--accent)' }}>
          <Ico.Back size={24} color="var(--accent)"/>
          <span style={{ fontSize:17, marginLeft:2 }}>Назад</span>
        </button>
        <div style={{ flex:1, textAlign:'center', fontSize:16, fontWeight:700 }}>Номер безопасности</div>
        <div style={{ width:80 }}/>
      </div>
      <div className="koto-scroll" style={{ flex:1, overflow:'auto', padding:'0 20px 40px' }}>
        <div style={{ textAlign:'center', padding:'6px 0 14px' }}>
          <Avatar contact={c} size={60}/>
          <div style={{ fontSize:15, fontWeight:600, marginTop:8 }}>{c.name}</div>
          <div style={{ fontSize:12.5, color:sec, marginTop:3 }}>
            сверьте числа с {c.name.split(' ')[0]}, чтобы убедиться, что вы говорите именно с ним
          </div>
        </div>

        {/* QR */}
        <div style={{
          background:'#fff', borderRadius:22, padding:20, margin:'8px auto 18px',
          width:220, height:220, position:'relative', boxShadow:'0 8px 24px rgba(0,0,0,0.08)',
        }}>
          <QRPattern seed={c.id}/>
          <div style={{
            position:'absolute', inset:'50% 50% auto auto', transform:'translate(50%,-50%)',
            background:'linear-gradient(160deg, #ff8656 0%, #e5531e 100%)', width:44, height:44, borderRadius:12,
            display:'flex', alignItems:'center', justifyContent:'center',
            boxShadow:'0 4px 10px rgba(229,83,30,0.4), inset 0 1px 0 rgba(255,255,255,0.2)',
            overflow:'hidden',
          }}>
            <img src="assets/koto-cat.png" alt="Koto" style={{ width:34, height:34, objectFit:'contain' }}/>
          </div>
        </div>

        {/* numeric blocks */}
        <div className="mono" style={{
          background:card, borderRadius:16, padding:18, marginBottom:18,
          display:'grid', gridTemplateColumns:'repeat(4, 1fr)', gap:'10px 14px',
          fontSize:16, fontWeight:600, letterSpacing:0.5, textAlign:'center', color:text,
        }}>
          {blocks.map((b,i) => <div key={i}>{b}</div>)}
        </div>

        <button
          onClick={()=>setVerified(!verified)}
          className="press"
          style={{
            width:'100%', border:0, cursor:'pointer',
            background: verified ? '#00a676' : 'var(--accent)',
            color:'#fff', padding:'14px 16px', borderRadius:14,
            fontSize:15, fontWeight:600,
            display:'flex', alignItems:'center', justifyContent:'center', gap:8,
          }}>
          {verified ? <><Ico.Check size={16} color="#fff"/> Отмечено как проверено</> : 'Отметить как проверено'}
        </button>

        <div style={{ fontSize:12.5, color:sec, marginTop:14, lineHeight:1.5 }}>
          Если числа не совпадают — возможно, ключи были сброшены. Никогда не пересылайте их в других мессенджерах.
        </div>
      </div>
    </div>
  );
}
function QRPattern({ seed }) {
  const grid = 21;
  const cells = [];
  let s = seed.split('').reduce((a,c)=>a+c.charCodeAt(0)*31, 0);
  for (let y=0;y<grid;y++) for (let x=0;x<grid;x++) {
    s = (s*1103515245+12345)&0x7fffffff;
    const corner = (x<7&&y<7)||(x>grid-8&&y<7)||(x<7&&y>grid-8);
    cells.push({x,y,on: corner ? ((x===0||x===6||y===0||y===6)||(x>=2&&x<=4&&y>=2&&y<=4)) : (s%100)<50});
  }
  const size = 180, c = size/grid;
  return (
    <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`} style={{ position:'absolute', top:20, left:20 }}>
      {cells.filter(k=>k.on).map(k => <rect key={`${k.x}-${k.y}`} x={k.x*c} y={k.y*c} width={c} height={c} fill="#0a0a0a"/>)}
    </svg>
  );
}

// ─── Screen Lock (biometry splash) ───────────────────────
function ScreenLockScreen({ dark, onUnlock }) {
  const [unlocking, setUnlocking] = useStateO(false);
  return (
    <div style={{
      height:'100%', background: dark ? '#0a0a0a' : '#ffffff',
      display:'flex', flexDirection:'column', alignItems:'center', justifyContent:'center', position:'relative',
    }}>
      <div style={{
        width:96, height:96, borderRadius:26,
        background:'linear-gradient(160deg, #ff8656 0%, #ff6b35 60%, #e5531e 100%)',
        display:'flex', alignItems:'center', justifyContent:'center',
        boxShadow: '0 18px 44px rgba(255,107,53,0.45), inset 0 1px 0 rgba(255,255,255,0.25), inset 0 -2px 0 rgba(0,0,0,0.1)',
        marginBottom:18, animation: unlocking ? 'fadeScaleIn 400ms' : 'none',
        overflow:'hidden',
      }}>
        <img src="assets/koto-cat.png" alt="Koto" style={{ width:76, height:76, objectFit:'contain', filter:'drop-shadow(0 3px 6px rgba(0,0,0,0.25))' }}/>
      </div>
      <div style={{ fontSize:26, fontWeight:800, letterSpacing:-0.6, color: dark?'#fff':'#0a0a0a' }}>Koto</div>
      <div style={{ fontSize:13, color: dark?'#9e9e9e':'#707070', marginTop:6 }}>заблокировано · Face ID</div>

      <div style={{ position:'absolute', bottom:110, left:0, right:0, display:'flex', justifyContent:'center' }}>
        <button
          onClick={() => { setUnlocking(true); setTimeout(onUnlock, 900); }}
          className="press"
          style={{
            border:0, cursor:'pointer',
            background: unlocking ? '#00a676' : (dark?'#1a1a1c':'#f2f2f2'),
            color: unlocking ? '#fff' : (dark?'#fff':'#0a0a0a'),
            padding:'14px 22px', borderRadius:18,
            display:'flex', alignItems:'center', gap:10,
            fontSize:15, fontWeight:600,
            transition:'all 240ms',
          }}>
          <Ico.FaceId size={26} color={unlocking ? '#fff' : 'var(--accent)'}/>
          {unlocking ? 'разблокировано' : 'разблокировать Face ID'}
        </button>
      </div>
    </div>
  );
}

// ─── Ephemeral picker (sheet) ────────────────────────────
function EphemeralSheet({ dark, current, onPick, onClose }) {
  const options = [
    { v:0, l:'Выключено', s:'сообщения не удаляются'},
    { v:30, l:'30 секунд', s:''},
    { v:300, l:'5 минут', s:''},
    { v:3600, l:'1 час', s:'рекомендовано для быстрых переписок'},
    { v:28800, l:'8 часов', s:''},
    { v:86400, l:'24 часа', s:''},
    { v:604800, l:'1 неделя', s:''},
  ];
  return (
    <Sheet dark={dark} onClose={onClose} title="Исчезающие сообщения">
      <div style={{ fontSize:13, color: dark?'#9e9e9e':'#707070', padding:'0 4px 14px', lineHeight:1.5 }}>
        Сообщения будут автоматически удаляться у всех участников чата после того, как их прочитают.
      </div>
      {options.map((o,i) => (
        <div key={o.v} onClick={()=>onPick(o.v)} className="press" style={{
          display:'flex', alignItems:'center', gap:12, padding:'14px 4px', cursor:'pointer',
          borderBottom: i===options.length-1 ? 0 : `0.5px solid ${dark?'rgba(255,255,255,0.06)':'rgba(0,0,0,0.06)'}`,
        }}>
          <div style={{
            width:22, height:22, borderRadius:'50%',
            border: `2px solid ${current===o.v?'var(--accent)':(dark?'#3a3a3e':'#c7c7cc')}`,
            background: current===o.v ? 'var(--accent)' : 'transparent',
            display:'flex', alignItems:'center', justifyContent:'center',
          }}>
            {current===o.v && <div style={{ width:8, height:8, borderRadius:'50%', background:'#fff' }}/>}
          </div>
          <div style={{ flex:1 }}>
            <div style={{ fontSize:15.5, fontWeight:500 }}>{o.l}</div>
            {o.s && <div style={{ fontSize:12, color: dark?'#9e9e9e':'#707070', marginTop:2 }}>{o.s}</div>}
          </div>
        </div>
      ))}
    </Sheet>
  );
}

// ─── Attach action sheet ─────────────────────────────────
function AttachSheet({ dark, onClose, onMedia }) {
  const items = [
    { i: <Ico.Image size={22} color="var(--accent)"/>, l:'Галерея', onClick: onMedia },
    { i: <Ico.Camera size={22} color="var(--accent)"/>, l:'Камера', onClick: onMedia },
    { i: <Ico.File size={22} color="var(--accent)"/>, l:'Файл', onClick: onClose },
    { i: <Ico.Contact size={22} color="var(--accent)"/>, l:'Контакт', onClick: onClose },
    { i: <Ico.Location size={22} color="var(--accent)"/>, l:'Геопозиция', onClick: onClose },
    { i: <Ico.Gif size={22} color="var(--accent)"/>, l:'GIF', onClick: onClose },
  ];
  return (
    <Sheet dark={dark} onClose={onClose} title="Прикрепить">
      <div style={{ display:'grid', gridTemplateColumns:'repeat(3, 1fr)', gap:10, padding:'4px 0 8px' }}>
        {items.map((it,i)=>(
          <div key={i} onClick={it.onClick} className="press" style={{
            background: dark?'#222224':'#f2f2f2', borderRadius:14,
            padding:'16px 8px', textAlign:'center', cursor:'pointer',
          }}>
            <div style={{ display:'flex', justifyContent:'center', marginBottom:6 }}>{it.i}</div>
            <div style={{ fontSize:12.5, fontWeight:500 }}>{it.l}</div>
          </div>
        ))}
      </div>
    </Sheet>
  );
}

// ─── Media picker (fullscreen) ───────────────────────────
function MediaPickerScreen({ dark, onBack, onSend }) {
  const bg = dark ? '#0b0b0c' : '#ffffff';
  const text = dark ? '#fff' : '#0a0a0a';
  const sec = dark ? '#9e9e9e' : '#707070';
  const [selected, setSelected] = useStateO([]);

  // generate 24 fake thumbs with varied gradients
  const thumbs = Array.from({length:24}).map((_,i) => ({
    id:i,
    bg: `linear-gradient(${(i*37)%360}deg, hsl(${(i*33)%360} 60% 55%), hsl(${(i*33+60)%360} 60% 45%))`,
    isVideo: i%5===3,
    dur: ['0:12','0:34','1:08','0:22'][i%4],
  }));

  const toggle = (id) => setSelected(s => s.includes(id) ? s.filter(x=>x!==id) : [...s,id]);

  return (
    <div style={{ height:'100%', background:bg, color:text, display:'flex', flexDirection:'column' }}>
      <div style={{ paddingTop:59, padding:'59px 12px 8px', display:'flex', alignItems:'center' }}>
        <button onClick={onBack} className="press" style={{ border:0, background:'transparent', cursor:'pointer', padding:8, color:'var(--accent)', fontSize:15 }}>Отмена</button>
        <div style={{ flex:1, textAlign:'center' }}>
          <div style={{ fontSize:15, fontWeight:700 }}>Недавние</div>
          <div style={{ fontSize:11, color:sec, marginTop:2 }}>выбрано {selected.length}</div>
        </div>
        <button className="press" style={{ border:0, background:'transparent', cursor:'pointer', padding:8, color:sec, fontSize:15 }}>Альбомы</button>
      </div>
      <div className="koto-scroll" style={{ flex:1, overflow:'auto', padding:2 }}>
        <div style={{ display:'grid', gridTemplateColumns:'repeat(3, 1fr)', gap:2 }}>
          {thumbs.map(t => (
            <div key={t.id} onClick={()=>toggle(t.id)} style={{
              aspectRatio:'1 / 1', background:t.bg, position:'relative', cursor:'pointer',
              border: selected.includes(t.id) ? '3px solid var(--accent)' : 0,
            }}>
              {selected.includes(t.id) && (
                <div style={{ position:'absolute', top:6, right:6, width:22, height:22, borderRadius:'50%', background:'var(--accent)', color:'#fff', display:'flex', alignItems:'center', justifyContent:'center', fontSize:11, fontWeight:700 }}>
                  {selected.indexOf(t.id)+1}
                </div>
              )}
              {t.isVideo && (
                <div style={{ position:'absolute', bottom:6, right:8, color:'#fff', fontSize:11, fontWeight:600, textShadow:'0 1px 2px rgba(0,0,0,0.5)' }}>▶ {t.dur}</div>
              )}
            </div>
          ))}
        </div>
      </div>
      {/* send bar */}
      {selected.length > 0 && (
        <div style={{
          padding:'10px 16px 28px',
          background: dark ? 'rgba(11,11,12,0.92)' : 'rgba(255,255,255,0.92)',
          backdropFilter:'blur(20px)', WebkitBackdropFilter:'blur(20px)',
          borderTop:`0.5px solid ${dark?'rgba(255,255,255,0.08)':'rgba(0,0,0,0.08)'}`,
          display:'flex', gap:10,
        }}>
          <button className="press" style={{ flex:1, border:0, cursor:'pointer', background: dark?'#1a1a1c':'#f2f2f2', color:text, padding:'12px', borderRadius:12, fontSize:14.5, fontWeight:500 }}>Подпись…</button>
          <button onClick={onSend} className="press" style={{ flex:1, border:0, cursor:'pointer', background:'var(--accent)', color:'#fff', padding:'12px', borderRadius:12, fontSize:14.5, fontWeight:600 }}>
            Отправить ({selected.length})
          </button>
        </div>
      )}
    </div>
  );
}

// ─── Generic bottom sheet ────────────────────────────────
function Sheet({ dark, onClose, title, children }) {
  return (
    <div onClick={onClose} style={{
      position:'absolute', inset:0, background:'rgba(0,0,0,0.5)',
      backdropFilter:'blur(6px)', WebkitBackdropFilter:'blur(6px)',
      display:'flex', alignItems:'flex-end', zIndex:500,
      animation:'overlayIn 240ms',
    }}>
      <div onClick={e=>e.stopPropagation()} style={{
        width:'100%', background: dark?'#1a1a1c':'#ffffff',
        borderRadius:'22px 22px 0 0', padding:'10px 20px 36px',
        color: dark?'#fff':'#0a0a0a',
        animation:'sheetUp 320ms cubic-bezier(.2,.8,.2,1)',
        maxHeight:'80%', overflow:'auto',
      }} className="koto-scroll">
        <div style={{ width:36, height:4, borderRadius:2, background: dark?'#3a3a3e':'#d1d1d6', margin:'0 auto 14px' }}/>
        {title && <div style={{ fontSize:17, fontWeight:700, letterSpacing:-0.3, marginBottom:8 }}>{title}</div>}
        {children}
      </div>
    </div>
  );
}

window.SafetyScreen = SafetyScreen;
window.ScreenLockScreen = ScreenLockScreen;
window.EphemeralSheet = EphemeralSheet;
window.AttachSheet = AttachSheet;
window.MediaPickerScreen = MediaPickerScreen;
