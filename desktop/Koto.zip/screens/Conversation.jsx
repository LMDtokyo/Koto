/* global React, Ico, Avatar, TypingDots, Status, EphemeralRing, KOTO_MESSAGES, getContact, getBot, BotIntroCard, BotKeyboard, BotCard, PawketBoardSheet, KassaShopSheet, VerifiedTick */
// Conversation.jsx

const { useState: useStateC, useRef: useRefC, useEffect: useEffectC } = React;

function ConversationScreen({ chatId, dark, onBack, onOpenContact, onOpenCall, onOpenVideo, onOpenEphemeral, onOpenAttach, ephemeralOn }) {
  const contact = getContact(chatId);
  const bg = dark ? '#0b0b0c' : '#ffffff';
  const surface = dark ? '#1a1a1c' : '#f2f2f2';
  const text = dark ? '#fff' : '#0a0a0a';
  const sec = dark ? '#9e9e9e' : '#707070';
  const peerBubble = dark ? '#27272a' : '#ececec';

  const seed = KOTO_MESSAGES[chatId] || KOTO_MESSAGES.default;
  const [msgs, setMsgs] = useStateC(seed);
  const [draft, setDraft] = useStateC('');
  const isBot = !!(contact && contact.isBot);
  const [webApp, setWebApp] = useStateC(null);  // 'pawket-board' | 'kassa-shop'
  const [peerTyping, setPeerTyping] = useStateC(chatId === 'olya');
  const [reactionFor, setReactionFor] = useStateC(null); // { id, rect, self }
  const [actionSheet, setActionSheet] = useStateC(false);
  const scrollRef = useRefC(null);
  const pressTimer = useRefC(null);
  const bubbleRefs = useRefC({});
  const rootRef = useRefC(null);

  useEffectC(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTo({ top: scrollRef.current.scrollHeight, behavior: 'smooth' });
    }
  }, [msgs.length, peerTyping]);

  // Fake "delivered->read" progression for last self message
  useEffectC(() => {
    const last = msgs[msgs.length - 1];
    if (last && last.self && last.status === 'sent') {
      const t1 = setTimeout(() => {
        setMsgs(ms => ms.map((m,i)=> i===ms.length-1 ? { ...m, status: 'delivered' } : m));
      }, 900);
      const t2 = setTimeout(() => {
        setMsgs(ms => ms.map((m,i)=> i===ms.length-1 ? { ...m, status: 'read' } : m));
      }, 2400);
      return () => { clearTimeout(t1); clearTimeout(t2); };
    }
  }, [msgs]);

  const send = (overrideText) => {
    const draftText = overrideText != null ? overrideText : draft.trim();
    if (!draftText) return;
    const now = new Date();
    const time = `${now.getHours().toString().padStart(2,'0')}:${now.getMinutes().toString().padStart(2,'0')}`;
    setMsgs([...msgs, { id: 'new-'+Date.now(), self: true, text: draftText, time, status: 'sending' }]);
    if (overrideText == null) setDraft('');
    setTimeout(() => {
      setMsgs(ms => ms.map((m,i)=> i===ms.length-1 ? { ...m, status: 'sent' } : m));
    }, 300);

    if (isBot) {
      // Bot reply: typing dots, then card / answer
      setTimeout(() => setPeerTyping(true), 600);
      setTimeout(() => {
        setPeerTyping(false);
        const reply = botReply(chatId, draftText);
        const t = new Date();
        const tt = `${t.getHours().toString().padStart(2,'0')}:${t.getMinutes().toString().padStart(2,'0')}`;
        setMsgs(ms => [...ms, { id:'br-'+Date.now(), self:false, botId:chatId, time:tt, ...reply }]);
      }, 1400);
      return;
    }

    if (Math.random() > 0.3) {
      setTimeout(() => setPeerTyping(true), 1800);
      setTimeout(() => {
        setPeerTyping(false);
        const reply = pickReply(draftText);
        const t = new Date();
        const tt = `${t.getHours().toString().padStart(2,'0')}:${t.getMinutes().toString().padStart(2,'0')}`;
        setMsgs(ms => [...ms, { id: 'r-'+Date.now(), self: false, text: reply, time: tt }]);
      }, 4200);
    }
  };

  const handleBotCmd = (cmd, label) => {
    send(label || cmd);
  };
  const handleBotWebApp = (id) => {
    setWebApp(id);
  };

  const longPressStart = (mid, self) => {
    pressTimer.current = setTimeout(() => {
      const el = bubbleRefs.current[mid];
      const root = rootRef.current;
      if (el && root) {
        const er = el.getBoundingClientRect();
        const rr = root.getBoundingClientRect();
        setReactionFor({
          id: mid,
          self,
          top: er.top - rr.top,
          left: er.left - rr.left,
          width: er.width,
          height: er.height,
        });
      } else {
        setReactionFor({ id: mid, self });
      }
    }, 400);
  };
  const longPressEnd = () => {
    clearTimeout(pressTimer.current);
  };
  const toggleReaction = (mid, emoji) => {
    setMsgs(ms => ms.map(m => {
      if (m.id !== mid) return m;
      const rx = m.reactions || [];
      const i = rx.findIndex(r => r.emoji === emoji && r.mine);
      let next;
      if (i >= 0) {
        // remove mine
        const r = rx[i];
        if (r.count <= 1) next = rx.filter((_,j)=>j!==i);
        else next = rx.map((x,j)=>j===i?{...x,count:x.count-1,mine:false}:x);
      } else {
        const j = rx.findIndex(r => r.emoji === emoji);
        if (j >= 0) next = rx.map((x,k)=>k===j?{...x,count:x.count+1,mine:true}:x);
        else next = [...rx, { emoji, count:1, mine:true }];
      }
      return { ...m, reactions: next };
    }));
    setReactionFor(null);
  };

  // Group consecutive messages by author
  const visibleMsgs = isBot ? msgs.filter(m => !m.isBotIntro) : msgs;
  const rendered = [];
  for (let i=0; i<visibleMsgs.length; i++) {
    const m = visibleMsgs[i];
    const prev = visibleMsgs[i-1];
    const next = visibleMsgs[i+1];
    const startGroup = !prev || prev.self !== m.self || (prev.author !== m.author);
    const endGroup = !next || next.self !== m.self || (next.author !== m.author);
    rendered.push({ ...m, startGroup, endGroup });
  }

  return (
    <div ref={rootRef} style={{ height: '100%', background: bg, color: text, display: 'flex', flexDirection: 'column', position: 'relative', overflow: 'hidden' }}>
      {/* Nav bar */}
      <div style={{
        paddingTop: 59, flexShrink: 0,
        background: dark ? 'rgba(11,11,12,0.85)' : 'rgba(255,255,255,0.85)',
        backdropFilter: 'blur(20px)', WebkitBackdropFilter: 'blur(20px)',
        borderBottom: `0.5px solid ${dark ? 'rgba(255,255,255,0.08)' : 'rgba(0,0,0,0.08)'}`,
        zIndex: 10,
      }}>
        <div style={{ display: 'flex', alignItems: 'center', padding: '8px 12px 10px', gap: 6 }}>
          <button onClick={onBack} className="press" style={{ border:0, background:'transparent', padding:6, cursor:'pointer', display:'flex', alignItems:'center', gap:2 }}>
            <Ico.Back size={26} color="var(--accent)" />
          </button>
          <button
            onClick={onOpenContact}
            className="press"
            style={{ flex:1, border:0, background:'transparent', padding:0, cursor:'pointer', display:'flex', alignItems:'center', gap:10 }}
          >
            <Avatar contact={contact} size={36} online={contact.status==='в сети'} />
            <div style={{ textAlign: 'left', overflow: 'hidden' }}>
              <div style={{ fontSize: 15, fontWeight: 600, letterSpacing: -0.2, color: text, overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap', display:'flex', alignItems:'center', gap:6 }}>
                {contact.name}
                {ephemeralOn && <Ico.Timer size={13} color="var(--accent)" />}
              </div>
              <div style={{ fontSize: 12, color: sec, marginTop: 1 }}>{contact.status}</div>
            </div>
          </button>
          <button onClick={onOpenCall} className="press" style={{ border:0, background:'transparent', padding:8, cursor:'pointer' }}>
            <Ico.Phone size={22} color="var(--accent)" />
          </button>
          <button onClick={onOpenVideo} className="press" style={{ border:0, background:'transparent', padding:8, cursor:'pointer' }}>
            <Ico.Video size={22} color="var(--accent)" />
          </button>
        </div>
      </div>

      {/* Messages */}
      <div ref={scrollRef} className="koto-scroll" style={{
        flex: 1, overflowY: 'auto', padding: '14px 12px 8px',
        background: dark ? 'radial-gradient(1200px 600px at 50% -100px, #181820, #0b0b0c 55%)' : 'radial-gradient(1200px 600px at 50% -100px, #fff8f4, #ffffff 55%)',
      }}>
        {/* E2EE banner */}
        <div style={{ textAlign: 'center', margin: '6px 0 18px' }}>
          <div style={{
            display: 'inline-flex', alignItems: 'center', gap: 6,
            padding: '7px 12px', background: dark ? 'rgba(255,107,53,0.12)' : 'rgba(255,107,53,0.1)',
            color: 'var(--accent)', borderRadius: 12,
            fontSize: 12, fontWeight: 500,
          }}>
            <Ico.Lock size={12} color="var(--accent)" />
            {isBot ? 'Боты получают только то, что вы им пишете' : 'Сообщения зашифрованы end-to-end'}
          </div>
        </div>

        {isBot && typeof BotIntroCard === 'function' && (
          <BotIntroCard botId={chatId} dark={dark} onCmd={handleBotCmd} onWebApp={handleBotWebApp}/>
        )}

        {ephemeralOn && (
          <div style={{ textAlign: 'center', margin: '0 0 16px' }}>
            <div style={{
              display: 'inline-flex', alignItems: 'center', gap: 6,
              padding: '6px 12px', background: surface, color: sec,
              borderRadius: 10, fontSize: 11.5,
            }}>
              <Ico.Timer size={12} color={sec} />
              Вы включили исчезающие сообщения · 1 час
            </div>
          </div>
        )}

        {rendered.map(m => (
          <Bubble
            key={m.id} msg={m} dark={dark} peerBubble={peerBubble}
            bubbleRef={(el) => { if (el) bubbleRefs.current[m.id] = el; }}
            hidden={reactionFor && reactionFor.id === m.id}
            onLongPressStart={() => longPressStart(m.id, m.self)}
            onLongPressEnd={longPressEnd}
            onToggleReaction={toggleReaction}
            onBotCmd={handleBotCmd}
            onBotWebApp={handleBotWebApp}
          />
        ))}

        {peerTyping && (
          <div style={{ display: 'flex', marginTop: 4, marginBottom: 4 }}>
            <div style={{
              background: peerBubble, padding: '10px 14px',
              borderRadius: '18px 18px 18px 4px',
              display: 'flex', alignItems: 'center', gap: 4,
              animation: 'bubblePop 240ms cubic-bezier(.2,.8,.2,1)',
            }}>
              <TypingDots color="var(--accent)" size={6} />
            </div>
          </div>
        )}
      </div>

      {/* Reaction overlay with positioned bubble */}
      {reactionFor && (() => {
        const msg = msgs.find(m => m.id === reactionFor.id);
        if (!msg) return null;
        const self = reactionFor.self;
        const hasPos = reactionFor.top !== undefined;
        const bubbleTop = hasPos ? reactionFor.top : 200;
        const bubbleLeft = hasPos ? reactionFor.left : 40;
        const bubbleW = hasPos ? reactionFor.width : 200;
        const bubbleH = hasPos ? reactionFor.height : 40;
        const pickerBottom = bubbleTop - 56;
        const menuTop = bubbleTop + bubbleH + 12;
        const mine = (e) => (msg.reactions || []).some(r => r.emoji === e && r.mine);
        const actions = self
          ? [
              { label: 'Ответить', icon: 'Reply' },
              { label: 'Переслать', icon: 'Forward' },
              { label: 'Копировать', icon: 'Copy' },
              { label: 'Редактировать', icon: 'Edit' },
              { label: 'Удалить', icon: 'Trash', danger: true },
            ]
          : [
              { label: 'Ответить', icon: 'Reply' },
              { label: 'Переслать', icon: 'Forward' },
              { label: 'Копировать', icon: 'Copy' },
              { label: 'Закрепить', icon: 'Pin' },
              { label: 'Сообщить', icon: 'Alert', danger: true },
            ];
        return (
          <div
            onClick={() => setReactionFor(null)}
            style={{
              position: 'absolute', inset: 0,
              background: dark ? 'rgba(0,0,0,0.55)' : 'rgba(20,20,22,0.42)',
              backdropFilter: 'blur(10px)', WebkitBackdropFilter: 'blur(10px)',
              zIndex: 100, animation: 'overlayIn 180ms ease-out',
            }}
          >
            {/* Reaction picker */}
            <div
              onClick={(e) => e.stopPropagation()}
              style={{
                position: 'absolute',
                top: Math.max(70, pickerBottom),
                [self ? 'right' : 'left']: self ? 20 : 20,
                background: dark ? 'rgba(42,42,46,0.95)' : 'rgba(255,255,255,0.98)',
                borderRadius: 999, padding: '8px 12px',
                display: 'flex', gap: 6,
                boxShadow: '0 12px 32px rgba(0,0,0,0.35)',
                backdropFilter: 'blur(20px)', WebkitBackdropFilter: 'blur(20px)',
                animation: 'reactPickerIn 260ms cubic-bezier(.2,.8,.2,1)',
                transformOrigin: self ? 'top right' : 'top left',
              }}
            >
              {['❤️','🔥','😂','👍','😮','🙏'].map((e, i) => (
                <button
                  key={e}
                  onClick={(ev) => { ev.stopPropagation(); toggleReaction(reactionFor.id, e); }}
                  className="press"
                  style={{
                    border: 0, background: mine(e) ? 'rgba(255,107,53,0.18)' : 'transparent',
                    fontSize: 26, cursor: 'pointer', padding: 4,
                    borderRadius: 999, width: 38, height: 38,
                    display: 'flex', alignItems: 'center', justifyContent: 'center',
                    animation: `emojiPop 320ms cubic-bezier(.2,.8,.2,1) ${i * 30}ms both`,
                  }}
                >{e}</button>
              ))}
            </div>

            {/* Frozen bubble at position */}
            <div
              onClick={(e) => e.stopPropagation()}
              style={{
                position: 'absolute',
                top: bubbleTop, left: bubbleLeft,
                width: bubbleW, minHeight: bubbleH,
                pointerEvents: 'none',
                animation: 'bubbleLift 260ms cubic-bezier(.2,.8,.2,1)',
                filter: 'drop-shadow(0 12px 28px rgba(0,0,0,0.35))',
              }}
            >
              <FrozenBubble msg={msg} dark={dark} peerBubble={peerBubble} />
            </div>

            {/* Actions menu */}
            <div
              onClick={(e) => e.stopPropagation()}
              style={{
                position: 'absolute',
                top: Math.min(menuTop, 560),
                [self ? 'right' : 'left']: 20,
                width: 220,
                background: dark ? 'rgba(42,42,46,0.95)' : 'rgba(255,255,255,0.98)',
                borderRadius: 14,
                boxShadow: '0 12px 32px rgba(0,0,0,0.35)',
                backdropFilter: 'blur(20px)', WebkitBackdropFilter: 'blur(20px)',
                overflow: 'hidden',
                animation: 'actionMenuIn 220ms cubic-bezier(.2,.8,.2,1) 40ms both',
                transformOrigin: self ? 'top right' : 'top left',
              }}
            >
              {actions.map((a, i) => {
                const Glyph = ACTION_GLYPHS[a.icon];
                const color = a.danger ? '#ff453a' : (dark ? '#fff' : '#0a0a0a');
                return (
                  <button
                    key={a.label}
                    onClick={() => setReactionFor(null)}
                    className="press"
                    style={{
                      display: 'flex', alignItems: 'center', justifyContent: 'space-between',
                      width: '100%', border: 0, background: 'transparent', cursor: 'pointer',
                      padding: '12px 14px', color,
                      fontSize: 15, fontFamily: 'inherit', textAlign: 'left',
                      borderTop: i > 0 ? `0.5px solid ${dark ? 'rgba(255,255,255,0.08)' : 'rgba(0,0,0,0.08)'}` : 'none',
                    }}
                  >
                    <span>{a.label}</span>
                    {Glyph && <Glyph size={18} color={color} />}
                  </button>
                );
              })}
            </div>
          </div>
        );
      })()}

      {/* Composer */}
      <div style={{
        flexShrink: 0,
        padding: '8px 10px 28px',
        background: dark ? 'rgba(11,11,12,0.9)' : 'rgba(255,255,255,0.9)',
        backdropFilter: 'blur(20px)', WebkitBackdropFilter: 'blur(20px)',
        borderTop: `0.5px solid ${dark ? 'rgba(255,255,255,0.08)' : 'rgba(0,0,0,0.08)'}`,
      }}>
        <div style={{ display: 'flex', alignItems: 'flex-end', gap: 6 }}>
          <button onClick={onOpenAttach} className="press" style={{
            width: 36, height: 36, borderRadius: '50%', border: 0,
            background: surface, cursor: 'pointer',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            flexShrink: 0,
          }}>
            <Ico.Plus size={22} color="var(--accent)" />
          </button>
          <div style={{
            flex: 1, background: surface, borderRadius: 20,
            minHeight: 36, padding: '6px 10px 6px 14px',
            display: 'flex', alignItems: 'center', gap: 6,
            border: `1px solid ${draft.trim() ? 'rgba(255,107,53,0.35)' : 'transparent'}`,
            transition: 'border-color 220ms ease, box-shadow 220ms ease',
            boxShadow: draft.trim() ? '0 0 0 3px rgba(255,107,53,0.08)' : 'none',
          }}>
            <input
              value={draft}
              onChange={e => setDraft(e.target.value)}
              onKeyDown={e => { if (e.key==='Enter') send(); }}
              placeholder={isBot ? `Написать ${contact?.name || 'боту'}…` : 'Сообщение'}
              style={{
                flex: 1, border: 0, background: 'transparent', outline: 'none',
                color: text, fontSize: 15, fontFamily: 'inherit', padding: '4px 0',
                minWidth: 0,
              }}
            />
            <button className="press" style={{ border:0, background:'transparent', padding:2, cursor:'pointer' }}>
              <Ico.Sticker size={20} color={sec} />
            </button>
          </div>
          <button onClick={() => send()} className="press" style={{
            width: 36, height: 36, borderRadius: '50%', border: 0,
            background: draft.trim() ? 'var(--accent)' : 'transparent',
            cursor: 'pointer',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            flexShrink: 0, position: 'relative',
            transform: draft.trim() ? 'scale(1)' : 'scale(0.92)',
            boxShadow: draft.trim() ? '0 4px 14px rgba(255,107,53,0.35)' : 'none',
            transition: 'background 220ms, transform 240ms cubic-bezier(.2,.8,.2,1), box-shadow 220ms',
          }}>
            <span style={{
              position:'absolute', inset:0, display:'flex', alignItems:'center', justifyContent:'center',
              transition:'opacity 180ms, transform 200ms cubic-bezier(.2,.8,.2,1)',
              opacity: draft.trim() ? 0 : 1,
              transform: draft.trim() ? 'scale(0.5) rotate(-20deg)' : 'scale(1)',
            }}>
              <Ico.Mic size={22} color="var(--accent)" />
            </span>
            <span style={{
              position:'absolute', inset:0, display:'flex', alignItems:'center', justifyContent:'center',
              transition:'opacity 180ms, transform 200ms cubic-bezier(.2,.8,.2,1)',
              opacity: draft.trim() ? 1 : 0,
              transform: draft.trim() ? 'scale(1)' : 'scale(0.5) rotate(20deg)',
            }}>
              <Ico.Send size={18} color="#fff" />
            </span>
          </button>
        </div>
      </div>

      {/* Bot WebApps */}
      {webApp === 'pawket-board' && typeof PawketBoardSheet === 'function' && (
        <PawketBoardSheet dark={dark} onClose={() => setWebApp(null)}/>
      )}
      {webApp === 'kassa-shop' && typeof KassaShopSheet === 'function' && (
        <KassaShopSheet dark={dark} onClose={() => setWebApp(null)}/>
      )}
    </div>
  );
}

function Bubble({ msg, dark, peerBubble, onLongPressStart, onLongPressEnd, bubbleRef, hidden, onToggleReaction, onBotCmd, onBotWebApp }) {
  const self = msg.self;
  const bg = self ? 'var(--accent)' : peerBubble;
  const color = self ? '#fff' : (dark ? '#fff' : '#0a0a0a');
  const sec = self ? 'rgba(255,255,255,0.75)' : (dark ? '#9e9e9e' : '#707070');

  if (msg.typing) {
    return (
      <div style={{ display: 'flex', marginTop: 4 }}>
        <div style={{ background: peerBubble, padding: '10px 14px', borderRadius: '18px 18px 18px 4px' }}>
          <TypingDots color="var(--accent)" size={6}/>
        </div>
      </div>
    );
  }

  const radius = self
    ? (msg.endGroup ? '18px 4px 18px 18px' : '18px 18px 4px 18px')
    : (msg.endGroup ? '18px 18px 18px 4px' : '18px 18px 18px 4px');

  const hasRx = msg.reactions && msg.reactions.length > 0;

  return (
    <div style={{
      display: 'flex', justifyContent: self ? 'flex-end' : 'flex-start',
      marginTop: msg.startGroup ? 10 : 2,
      marginBottom: hasRx ? 14 : 0,
      animation: self ? 'bubblePopSelf 220ms cubic-bezier(.2,.8,.2,1) both' : 'bubblePop 240ms cubic-bezier(.2,.8,.2,1) both',
      visibility: hidden ? 'hidden' : 'visible',
    }}>
      <div
        ref={bubbleRef}
        className="koto-bubble"
        onMouseDown={onLongPressStart} onMouseUp={onLongPressEnd} onMouseLeave={onLongPressEnd}
        onTouchStart={onLongPressStart} onTouchEnd={onLongPressEnd}
        style={{
          maxWidth: '78%', position: 'relative',
          background: bg, color,
          padding: '8px 12px 6px',
          borderRadius: radius,
          fontSize: 15.5, lineHeight: '21px', letterSpacing: -0.15,
          boxShadow: self ? '0 1px 2px rgba(0,0,0,0.06)' : 'none',
          cursor: 'pointer',
          transition: 'transform 180ms cubic-bezier(.2,.8,.2,1)',
        }}
      >
        {msg.author && !self && msg.startGroup && (
          <div style={{ fontSize: 12.5, fontWeight: 700, color: msg.authorColor, marginBottom: 2 }}>
            {msg.author}
          </div>
        )}
        {msg.text && <div style={{ whiteSpace: 'pre-wrap' }}>{msg.text}</div>}
        {msg.card && typeof BotCard === 'function' && (
          <div style={{ marginTop: msg.text ? 8 : 0 }}>
            <BotCard card={msg.card} dark={dark}/>
          </div>
        )}
        {msg.buttons && typeof BotKeyboard === 'function' && (
          <BotKeyboard buttons={msg.buttons} dark={dark}
            onCmd={onBotCmd || (() => {})}
            onWebApp={onBotWebApp || (() => {})}/>
        )}
        <div style={{
          display: 'flex', alignItems: 'center', gap: 4, justifyContent: 'flex-end',
          marginTop: 2, fontSize: 10.5, color: sec, fontVariantNumeric: 'tabular-nums',
        }}>
          {msg.ephemeral && <EphemeralRing pct={msg.ephemeralPct||0.5} size={11} color={sec} />}
          <span>{msg.time}</span>
          {self && <Status status={msg.status || 'sent'} dark={dark} />}
        </div>
        {hasRx && (
          <div style={{
            position: 'absolute', bottom: -12, [self?'left':'right']: 8,
            display: 'flex', gap: 4,
          }}>
            {msg.reactions.map(r => (
              <button
                key={r.emoji}
                onClick={(ev) => { ev.stopPropagation(); onToggleReaction(msg.id, r.emoji); }}
                className="press"
                style={{
                  border: r.mine ? `1px solid var(--accent)` : `0.5px solid ${dark ? 'rgba(255,255,255,0.1)' : 'rgba(0,0,0,0.08)'}`,
                  background: r.mine
                    ? (dark ? 'rgba(255,107,53,0.22)' : 'rgba(255,107,53,0.14)')
                    : (dark ? '#2a2a2c' : '#fff'),
                  color: dark ? '#fff' : '#0a0a0a',
                  padding: '2px 7px 2px 5px', borderRadius: 999,
                  fontSize: 12, fontFamily: 'inherit', cursor: 'pointer',
                  boxShadow: '0 2px 6px rgba(0,0,0,0.12)',
                  display: 'flex', alignItems: 'center', gap: 3,
                  fontVariantNumeric: 'tabular-nums',
                  animation: 'reactionChipIn 280ms cubic-bezier(.2,.8,.2,1)',
                }}
              >
                <span style={{ fontSize: 13 }}>{r.emoji}</span>
                {r.count > 1 && <span style={{ fontWeight: 600 }}>{r.count}</span>}
              </button>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

// Bubble replica shown frozen in reaction overlay (no interactions, no ref)
function FrozenBubble({ msg, dark, peerBubble }) {
  const self = msg.self;
  const bg = self ? 'var(--accent)' : peerBubble;
  const color = self ? '#fff' : (dark ? '#fff' : '#0a0a0a');
  const sec = self ? 'rgba(255,255,255,0.75)' : (dark ? '#9e9e9e' : '#707070');
  const radius = self
    ? '18px 4px 18px 18px'
    : '18px 18px 18px 4px';
  return (
    <div style={{
      background: bg, color,
      padding: '8px 12px 6px',
      borderRadius: radius,
      fontSize: 15.5, lineHeight: '21px', letterSpacing: -0.15,
      width: '100%', boxSizing: 'border-box',
    }}>
      {msg.author && !self && (
        <div style={{ fontSize: 12.5, fontWeight: 700, color: msg.authorColor, marginBottom: 2 }}>
          {msg.author}
        </div>
      )}
      <div style={{ whiteSpace: 'pre-wrap' }}>{msg.text}</div>
      <div style={{
        display: 'flex', alignItems: 'center', gap: 4, justifyContent: 'flex-end',
        marginTop: 2, fontSize: 10.5, color: sec, fontVariantNumeric: 'tabular-nums',
      }}>
        <span>{msg.time}</span>
      </div>
    </div>
  );
}

// Line-art glyphs for the action menu
const ACTION_GLYPHS = {
  Reply: ({ size=18, color='#000' }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none">
      <path d="M10 8V5l-6 6 6 6v-3c4 0 7 1 10 5-1-7-5-11-10-11z" stroke={color} strokeWidth="1.6" strokeLinejoin="round" fill="none"/>
    </svg>
  ),
  Forward: ({ size=18, color='#000' }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none">
      <path d="M14 8V5l6 6-6 6v-3c-4 0-7 1-10 5 1-7 5-11 10-11z" stroke={color} strokeWidth="1.6" strokeLinejoin="round" fill="none"/>
    </svg>
  ),
  Copy: ({ size=18, color='#000' }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none">
      <rect x="8" y="8" width="11" height="12" rx="2" stroke={color} strokeWidth="1.6"/>
      <path d="M16 8V6a2 2 0 0 0-2-2H6a2 2 0 0 0-2 2v10a2 2 0 0 0 2 2h2" stroke={color} strokeWidth="1.6"/>
    </svg>
  ),
  Edit: ({ size=18, color='#000' }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none">
      <path d="M4 20h4l10-10-4-4L4 16v4z" stroke={color} strokeWidth="1.6" strokeLinejoin="round"/>
      <path d="M14 6l4 4" stroke={color} strokeWidth="1.6"/>
    </svg>
  ),
  Trash: ({ size=18, color='#000' }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none">
      <path d="M5 7h14M10 7V5a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1v2M7 7l1 12a2 2 0 0 0 2 2h4a2 2 0 0 0 2-2l1-12" stroke={color} strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
  ),
  Pin: ({ size=18, color='#000' }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none">
      <path d="M9 3h6l-1 5 3 3-6 1-1 6-3-3-5 1 3-3-2-4 6-1 0-5z" stroke={color} strokeWidth="1.6" strokeLinejoin="round"/>
    </svg>
  ),
  Alert: ({ size=18, color='#000' }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none">
      <path d="M12 3l10 18H2L12 3z" stroke={color} strokeWidth="1.6" strokeLinejoin="round"/>
      <path d="M12 10v5M12 18v.01" stroke={color} strokeWidth="1.6" strokeLinecap="round"/>
    </svg>
  ),
};

function pickReply(draft) {
  const lower = draft.toLowerCase();
  if (lower.includes('?')) return 'да, конечно';
  if (lower.length < 8) return 'ок 👌';
  return 'принял, посмотрю и вернусь';
}

window.ConversationScreen = ConversationScreen;

function botReply(botId, userText) {
  if (botId === 'botforge' && window.BotForge) {
    return window.BotForge.reply(userText);
  }
  const lower = (userText||'').toLowerCase();

  if (botId === 'pawket') {
    if (lower.includes('weather') || lower.includes('погод')) {
      return {
        text: 'Москва, прогноз на сегодня:',
        card: { kind:'weather', city:'Москва', temp:'+14°', cond:'☁️ облачно', hi:'+16°', lo:'+8°', hourly:[10,12,14,15,14,13,11,10] },
        buttons: [[{ label:'На неделю', cmd:'/weather week' }, { label:'Сменить город', cmd:'/city' }]],
      };
    }
    if (lower.includes('rates') || lower.includes('курс')) {
      return {
        text: '💱 Курсы ЦБ на сегодня:\n\n  USD  →  91.40 ₽   ▲ 0.3%\n  EUR  →  98.72 ₽   ▼ 0.1%\n  CNY  →  12.66 ₽   ▲ 0.2%',
        buttons: [[{ label:'BTC/ETH', cmd:'/crypto' }, { label:'Алерт', cmd:'/alert' }]],
      };
    }
    if (lower.includes('note') || lower.includes('заметк')) {
      return {
        text: 'Открыл доску с заметками 🗒',
        buttons: [[{ label:'🧠 Открыть доску', webapp:'pawket-board', primary:true }]],
      };
    }
    if (lower.includes('remind') || lower.includes('напомн')) {
      return {
        text: '⏰ Напомню. Когда?',
        buttons: [
          [{ label:'через 15 мин', cmd:'/remind 15m' }, { label:'через 1 ч', cmd:'/remind 1h' }],
          [{ label:'завтра в 9', cmd:'/remind 9am' }, { label:'выбрать…', webapp:'pawket-board' }],
        ],
      };
    }
    return {
      text: 'Мрр… попробуй одну из команд:',
      buttons: [
        [{ label:'☀️ /weather', cmd:'/weather' }, { label:'💱 /rates', cmd:'/rates' }],
        [{ label:'🧠 Открыть доску', webapp:'pawket-board', primary:true }],
      ],
    };
  }

  if (botId === 'kassa') {
    return {
      text: 'Открываю магазин 🎫',
      buttons: [[{ label:'🛒 Магазин Касса', webapp:'kassa-shop', primary:true }]],
    };
  }
  if (botId === 'meow-quiz') {
    return { text:'Раунд начнётся в 18:30. Зови друзей! 🐱', buttons:[[{label:'+ Пригласить', cmd:'/invite'}]] };
  }
  if (botId === 'rates') {
    return { text:'USD 91.40 ▲ 0.3%\nEUR 98.72 ▼ 0.1%\nCNY 12.66 ▲ 0.2%', buttons:[[{label:'Алерт',cmd:'/alert'},{label:'График',cmd:'/chart'}]] };
  }

  return { text:'…' };
}
