/* global React */
// bot-forge.jsx — BotFather-clone logic for @botforge
// Exposes:
//   window.BotForge.reply(userText)          -> { text, buttons?, card? }
//   window.BotForge.getIntro()               -> intro message payload
//   window.BotForge.listBots()               -> array of user-created bots
//   window.BotForge.reset()
//
// Persists state in localStorage under 'koto.botforge'.

(function () {
  const LS_KEY = 'koto.botforge';

  // --- Persistence ---------------------------------------------------------

  function load() {
    try {
      const raw = localStorage.getItem(LS_KEY);
      if (raw) return JSON.parse(raw);
    } catch (e) {}
    return { bots: [], step: null, draft: null, selectedBotId: null, pendingAction: null };
  }
  function save() {
    try { localStorage.setItem(LS_KEY, JSON.stringify(state)); } catch (e) {}
  }

  let state = load();

  // --- Helpers -------------------------------------------------------------

  function makeToken(botId) {
    // Fake BotFather-style token: <numeric id>:<33 char base64>
    const num = 1000000000 + Math.floor(Math.random() * 8999999999);
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789_-';
    let tail = '';
    for (let i = 0; i < 35; i++) tail += chars[Math.floor(Math.random() * chars.length)];
    return `${num}:${tail}`;
  }

  function findBot(idOrHandle) {
    if (!idOrHandle) return null;
    const k = idOrHandle.replace(/^@/, '').toLowerCase();
    return state.bots.find(b => b.id === k || b.username.toLowerCase() === k) || null;
  }

  function isValidUsername(u) {
    // Telegram rule: 5-32 chars, ends with "bot", letters/digits/_
    if (!u) return false;
    const s = u.replace(/^@/, '');
    if (!/^[A-Za-z][A-Za-z0-9_]{4,31}$/.test(s)) return false;
    if (!/bot$/i.test(s)) return false;
    return true;
  }

  function usernameTaken(u) {
    const s = u.replace(/^@/, '').toLowerCase();
    return state.bots.some(b => b.username.toLowerCase() === s);
  }

  function resetFlow() {
    state.step = null;
    state.draft = null;
    state.pendingAction = null;
    state.selectedBotId = null;
    save();
  }

  // --- Reply primitives ----------------------------------------------------

  const mainKeyboard = () => [
    [{ label: '/newbot', cmd: '/newbot' }, { label: '/mybots', cmd: '/mybots' }],
    [{ label: '/help', cmd: '/help' }],
  ];

  function intro() {
    return {
      text:
        'Здравствуйте! Я BotForge — помогу вам создать новых ботов и управлять существующими. ' +
        'Вот, что я умею:\n\n' +
        '/newbot — создать нового бота\n' +
        '/mybots — редактировать ваших ботов\n' +
        '/setname — изменить имя бота\n' +
        '/setdescription — изменить описание\n' +
        '/setuserpic — аватар\n' +
        '/token — показать API-токен\n' +
        '/deletebot — удалить бота\n' +
        '/cancel — отменить текущее действие\n' +
        '/help — показать это сообщение',
      buttons: mainKeyboard(),
    };
  }

  function botCard(bot) {
    return {
      text:
        `🤖 @${bot.username}\n` +
        `${bot.name}\n\n` +
        (bot.description ? bot.description + '\n\n' : '') +
        `Создан ${bot.createdAt}\n` +
        `Пользователей: ${bot.users}`,
      buttons: [
        [{ label: 'Редактировать имя', cmd: `/setname ${bot.username}` },
         { label: 'Описание', cmd: `/setdescription ${bot.username}` }],
        [{ label: 'Аватар', cmd: `/setuserpic ${bot.username}` },
         { label: 'Токен', cmd: `/token ${bot.username}` }],
        [{ label: '🗑  Удалить', cmd: `/deletebot ${bot.username}` }],
        [{ label: '◀  К списку', cmd: '/mybots' }],
      ],
    };
  }

  function listBotsMsg() {
    if (state.bots.length === 0) {
      return {
        text: 'У вас пока нет ботов. Создадим первого?',
        buttons: [[{ label: '➕ /newbot', cmd: '/newbot', primary: true }]],
      };
    }
    const rows = state.bots.map(b => [{ label: `@${b.username}`, cmd: `/bot ${b.username}` }]);
    rows.push([{ label: '➕ Новый бот', cmd: '/newbot' }]);
    return {
      text: `Ваши боты (${state.bots.length}):\nВыберите бота для управления.`,
      buttons: rows,
    };
  }

  // --- FSM steps -----------------------------------------------------------

  function startNewBot() {
    state.step = 'ask_name';
    state.draft = {};
    save();
    return {
      text:
        'Хорошо. Давайте создадим нового бота.\n' +
        'Как будем его называть? Это имя увидят пользователи в списке чатов.',
      buttons: [[{ label: '❌ /cancel', cmd: '/cancel' }]],
    };
  }

  function handleName(text) {
    const name = text.trim();
    if (name.length < 3 || name.length > 64) {
      return { text: 'Имя должно быть от 3 до 64 символов. Попробуйте ещё раз.' };
    }
    if (name.startsWith('/')) {
      return { text: 'Это похоже на команду. Введите имя бота (обычный текст).' };
    }
    state.draft.name = name;
    state.step = 'ask_username';
    save();
    return {
      text:
        `Отлично. Теперь давайте придумаем username для бота @${name}. ` +
        'Он должен заканчиваться на `bot`. Например: TetrisBot или tetris_bot.',
      buttons: [[{ label: '❌ /cancel', cmd: '/cancel' }]],
    };
  }

  function handleUsername(text) {
    const raw = text.trim().replace(/^@/, '');
    if (!isValidUsername(raw)) {
      return {
        text:
          'Извините, это имя не подходит. Оно должно:\n' +
          '• быть от 5 до 32 символов\n' +
          '• начинаться с буквы\n' +
          '• содержать только латиницу, цифры и `_`\n' +
          '• заканчиваться на `bot`\n\n' +
          'Попробуйте ещё раз.',
      };
    }
    if (usernameTaken(raw)) {
      return {
        text: `Извините, @${raw} уже занят. Придумайте другое имя.`,
      };
    }
    const bot = {
      id: raw.toLowerCase(),
      username: raw,
      name: state.draft.name,
      description: '',
      token: makeToken(raw),
      createdAt: new Date().toLocaleDateString('ru-RU', { day: 'numeric', month: 'long', year: 'numeric' }),
      users: 0,
    };
    state.bots.push(bot);
    state.step = null;
    state.draft = null;
    save();
    return {
      text:
        `Готово! Поздравляю с новым ботом. Вы можете найти его по адресу @${bot.username}.\n\n` +
        `Используйте этот токен, чтобы подключить HTTP API:\n\n` +
        '```\n' + bot.token + '\n```\n\n' +
        'Храните токен в тайне — он даёт контроль над ботом.\n\n' +
        'Документация: koto.im/bots',
      buttons: [
        [{ label: `⚙️  @${bot.username}`, cmd: `/bot ${bot.username}`, primary: true }],
        [{ label: '➕ Ещё одного', cmd: '/newbot' },
         { label: '📋 /mybots', cmd: '/mybots' }],
      ],
    };
  }

  // Step: editing name / description / userpic / deleting — via pendingAction
  function handlePendingAction(text) {
    const { action, botId } = state.pendingAction;
    const bot = state.bots.find(b => b.id === botId);
    if (!bot) { resetFlow(); return { text: 'Бот не найден. /cancel', buttons: mainKeyboard() }; }

    if (action === 'setname') {
      const v = text.trim();
      if (v.length < 3 || v.length > 64) return { text: 'Длина 3–64. Попробуйте ещё раз.' };
      bot.name = v; resetFlow(); save();
      return {
        text: `Готово. Новое имя @${bot.username}: ${v}`,
        buttons: [[{ label: `⚙️  @${bot.username}`, cmd: `/bot ${bot.username}` }]],
      };
    }
    if (action === 'setdescription') {
      const v = text.trim();
      if (v.length > 512) return { text: 'Слишком длинно (макс. 512). Попробуйте короче.' };
      bot.description = v; resetFlow(); save();
      return {
        text: `Описание @${bot.username} обновлено.`,
        buttons: [[{ label: `⚙️  @${bot.username}`, cmd: `/bot ${bot.username}` }]],
      };
    }
    if (action === 'setuserpic') {
      resetFlow(); save();
      return {
        text: `Аватар для @${bot.username} обновлён. (В прототипе — заглушка.)`,
        buttons: [[{ label: `⚙️  @${bot.username}`, cmd: `/bot ${bot.username}` }]],
      };
    }
    if (action === 'deletebot_confirm') {
      const v = text.trim();
      if (v.toLowerCase() === 'yes' || v.toLowerCase() === 'да') {
        state.bots = state.bots.filter(b => b.id !== botId);
        resetFlow(); save();
        return {
          text: `Бот @${bot.username} удалён.`,
          buttons: [[{ label: '➕ /newbot', cmd: '/newbot' }, { label: '📋 /mybots', cmd: '/mybots' }]],
        };
      }
      resetFlow(); save();
      return { text: 'Отменено. Бот не удалён.', buttons: mainKeyboard() };
    }
    resetFlow();
    return intro();
  }

  // --- Command router ------------------------------------------------------

  function parseCmd(text) {
    const t = (text || '').trim();
    if (!t.startsWith('/')) return null;
    const [cmd, ...rest] = t.split(/\s+/);
    return { cmd: cmd.toLowerCase(), arg: rest.join(' ').trim() };
  }

  function cmdNewbot() { return startNewBot(); }

  function cmdMybots() { resetFlow(); return listBotsMsg(); }

  function cmdHelp() { resetFlow(); return intro(); }

  function cmdCancel() {
    const was = state.step || state.pendingAction;
    resetFlow();
    if (!was) return { text: 'Нечего отменять.', buttons: mainKeyboard() };
    return { text: 'Отменено.', buttons: mainKeyboard() };
  }

  function cmdStart() { resetFlow(); return intro(); }

  function cmdBot(arg) {
    const bot = findBot(arg);
    if (!bot) return { text: 'Бот не найден. /mybots', buttons: mainKeyboard() };
    return botCard(bot);
  }

  function requireBotArg(arg, action, askText) {
    const bot = findBot(arg);
    if (bot) {
      state.step = 'pending';
      state.pendingAction = { action, botId: bot.id };
      save();
      return { text: askText(bot), buttons: [[{ label: '❌ /cancel', cmd: '/cancel' }]] };
    }
    // No arg: show chooser
    if (state.bots.length === 0) {
      return {
        text: 'У вас ещё нет ботов. Создадим первого?',
        buttons: [[{ label: '➕ /newbot', cmd: '/newbot', primary: true }]],
      };
    }
    const rows = state.bots.map(b => [{ label: `@${b.username}`, cmd: `/${action} ${b.username}` }]);
    return { text: 'Выберите бота:', buttons: rows };
  }

  function cmdSetname(arg) {
    return requireBotArg(arg, 'setname', (b) => `Введите новое имя для @${b.username}.\nТекущее: ${b.name}`);
  }
  function cmdSetdescription(arg) {
    return requireBotArg(arg, 'setdescription', (b) => `Введите описание для @${b.username}.\nТекущее: ${b.description || '— пусто —'}`);
  }
  function cmdSetuserpic(arg) {
    return requireBotArg(arg, 'setuserpic', (b) => `Отправьте картинку для аватара @${b.username}.\n(В прототипе — любой текст подтвердит действие.)`);
  }

  function cmdToken(arg) {
    const bot = findBot(arg);
    if (!bot) {
      if (state.bots.length === 0) return { text: 'У вас нет ботов. /newbot', buttons: mainKeyboard() };
      const rows = state.bots.map(b => [{ label: `@${b.username}`, cmd: `/token ${b.username}` }]);
      return { text: 'Токен какого бота показать?', buttons: rows };
    }
    return {
      text:
        `Токен для @${bot.username}:\n\n` +
        '```\n' + bot.token + '\n```\n\n' +
        'Храните его в секрете — он даёт полный доступ к боту.',
      buttons: [
        [{ label: '🔄 Пересоздать', cmd: `/revoke ${bot.username}` }],
        [{ label: `◀  @${bot.username}`, cmd: `/bot ${bot.username}` }],
      ],
    };
  }

  function cmdRevoke(arg) {
    const bot = findBot(arg);
    if (!bot) return { text: 'Бот не найден.', buttons: mainKeyboard() };
    bot.token = makeToken(bot.username);
    save();
    return {
      text:
        `Готово. Новый токен для @${bot.username}:\n\n` +
        '```\n' + bot.token + '\n```\n\n' +
        'Старый токен больше не работает.',
      buttons: [[{ label: `◀  @${bot.username}`, cmd: `/bot ${bot.username}` }]],
    };
  }

  function cmdDeletebot(arg) {
    const bot = findBot(arg);
    if (!bot) {
      if (state.bots.length === 0) return { text: 'У вас нет ботов.', buttons: mainKeyboard() };
      const rows = state.bots.map(b => [{ label: `@${b.username}`, cmd: `/deletebot ${b.username}` }]);
      return { text: 'Какого бота удалить?', buttons: rows };
    }
    state.step = 'pending';
    state.pendingAction = { action: 'deletebot_confirm', botId: bot.id };
    save();
    return {
      text:
        `Вы уверены? Это действие нельзя отменить.\n` +
        `Напишите «да» или «yes», чтобы удалить @${bot.username}.`,
      buttons: [
        [{ label: '✅ Да, удалить', cmd: '/confirm-delete' },
         { label: '❌ Отмена', cmd: '/cancel' }],
      ],
    };
  }

  // --- Public entry --------------------------------------------------------

  function reply(userText) {
    const parsed = parseCmd(userText);

    // Shortcut: confirm-delete
    if (parsed && parsed.cmd === '/confirm-delete' && state.pendingAction?.action === 'deletebot_confirm') {
      return handlePendingAction('да');
    }

    // Commands always interrupt the current flow, except /cancel-able steps
    if (parsed) {
      const cmd = parsed.cmd;
      const arg = parsed.arg;

      // These commands reset any ongoing step
      if (cmd === '/cancel') return cmdCancel();
      if (cmd === '/start') return cmdStart();
      if (cmd === '/help') return cmdHelp();
      if (cmd === '/newbot') { resetFlow(); return cmdNewbot(); }
      if (cmd === '/mybots') return cmdMybots();
      if (cmd === '/bot') return cmdBot(arg);
      if (cmd === '/setname') { resetFlow(); return cmdSetname(arg); }
      if (cmd === '/setdescription') { resetFlow(); return cmdSetdescription(arg); }
      if (cmd === '/setuserpic') { resetFlow(); return cmdSetuserpic(arg); }
      if (cmd === '/token') { resetFlow(); return cmdToken(arg); }
      if (cmd === '/revoke') { resetFlow(); return cmdRevoke(arg); }
      if (cmd === '/deletebot') { resetFlow(); return cmdDeletebot(arg); }

      // Unknown command
      return {
        text: `Я не знаю команду ${cmd}. Вот что я умею:`,
        buttons: mainKeyboard(),
      };
    }

    // Plain text — feed into active FSM step
    if (state.step === 'ask_name') return handleName(userText);
    if (state.step === 'ask_username') return handleUsername(userText);
    if (state.step === 'pending' && state.pendingAction) return handlePendingAction(userText);

    // No step: default
    return {
      text: 'Я вас не понял. Отправьте /help, чтобы посмотреть список команд.',
      buttons: mainKeyboard(),
    };
  }

  window.BotForge = {
    reply,
    getIntro: intro,
    listBots: () => state.bots.slice(),
    reset: () => { state = { bots: [], step: null, draft: null, selectedBotId: null, pendingAction: null }; save(); },
  };
})();
