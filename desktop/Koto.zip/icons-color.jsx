/* global React */
// Colorful SVG icons — iOS Settings style, rounded squircle background + glyph

function IcoTile({ size = 30, from, to, children, shadow = true }) {
  const r = Math.round(size * 0.28);
  return (
    <div style={{
      width: size, height: size, borderRadius: r,
      background: `linear-gradient(160deg, ${from} 0%, ${to} 100%)`,
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      flexShrink: 0, position: 'relative', overflow: 'hidden',
      boxShadow: shadow ? '0 1px 2px rgba(0,0,0,0.06), inset 0 1px 0 rgba(255,255,255,0.18), inset 0 -1px 0 rgba(0,0,0,0.06)' : 'none',
    }}>
      {children}
    </div>
  );
}

const IC = {
  // Account
  KotoId: (p = {}) => (
    <IcoTile {...p} from="#ff8656" to="#e5531e">
      <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
        <rect x="3" y="5" width="18" height="14" rx="3" stroke="#fff" strokeWidth="2"/>
        <circle cx="9" cy="12" r="2.2" stroke="#fff" strokeWidth="2"/>
        <path d="M6.4 16.4c.6-1.2 1.6-1.8 2.6-1.8s2 .6 2.6 1.8M14 10h4M14 13h3" stroke="#fff" strokeWidth="2" strokeLinecap="round"/>
      </svg>
    </IcoTile>
  ),
  Seed: (p = {}) => (
    <IcoTile {...p} from="#2dd36f" to="#0b9247">
      <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
        <circle cx="9" cy="12" r="3.2" stroke="#fff" strokeWidth="2"/>
        <path d="M12 12h9M16 9v6M19 10.5v3" stroke="#fff" strokeWidth="2" strokeLinecap="round"/>
      </svg>
    </IcoTile>
  ),
  Devices: (p = {}) => (
    <IcoTile {...p} from="#5aa9ff" to="#2166e0">
      <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
        <rect x="2" y="6" width="12" height="9" rx="1.5" stroke="#fff" strokeWidth="2"/>
        <rect x="15" y="9" width="7" height="12" rx="1.5" stroke="#fff" strokeWidth="2"/>
        <path d="M5 18h5M18.5 17.8v.01" stroke="#fff" strokeWidth="2" strokeLinecap="round"/>
      </svg>
    </IcoTile>
  ),
  Username: (p = {}) => (
    <IcoTile {...p} from="#a995ff" to="#6b46ff">
      <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
        <circle cx="12" cy="12" r="4" stroke="#fff" strokeWidth="2"/>
        <path d="M16 12v1.5a2 2 0 104 0V12a8 8 0 10-2.5 5.8" stroke="#fff" strokeWidth="2" strokeLinecap="round"/>
      </svg>
    </IcoTile>
  ),

  // Privacy
  Privacy: (p = {}) => (
    <IcoTile {...p} from="#2dd36f" to="#0b9247">
      <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
        <path d="M12 3l7.5 2.8v6.4c0 4.4-3.2 8-7.5 9-4.3-1-7.5-4.6-7.5-9V5.8L12 3z" stroke="#fff" strokeWidth="2" strokeLinejoin="round"/>
        <path d="M8.5 12l2.5 2.5 4.5-5" stroke="#fff" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
      </svg>
    </IcoTile>
  ),
  Ephemeral: (p = {}) => (
    <IcoTile {...p} from="#ff8656" to="#e5531e">
      <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
        <circle cx="12" cy="13" r="7.5" stroke="#fff" strokeWidth="2"/>
        <path d="M12 9v4l2.5 2M9.5 3h5M12 6V3" stroke="#fff" strokeWidth="2" strokeLinecap="round"/>
      </svg>
    </IcoTile>
  ),
  ScreenLock: (p = {}) => (
    <IcoTile {...p} from="#7e8cff" to="#4258e0">
      <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
        <rect x="5" y="10.5" width="14" height="9.5" rx="2" stroke="#fff" strokeWidth="2"/>
        <path d="M8 10.5V8a4 4 0 018 0v2.5" stroke="#fff" strokeWidth="2"/>
        <circle cx="12" cy="15" r="1.3" fill="#fff"/>
      </svg>
    </IcoTile>
  ),
  Safety: (p = {}) => (
    <IcoTile {...p} from="#3be3c9" to="#0e9b86">
      <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
        <path d="M12 3l7.5 2.8v6.4c0 4.4-3.2 8-7.5 9-4.3-1-7.5-4.6-7.5-9V5.8L12 3z" stroke="#fff" strokeWidth="2" strokeLinejoin="round"/>
        <path d="M10 11h4M11 14h2" stroke="#fff" strokeWidth="2" strokeLinecap="round"/>
      </svg>
    </IcoTile>
  ),
  Sealed: (p = {}) => (
    <IcoTile {...p} from="#a1a6ad" to="#595e66">
      <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
        <path d="M2.5 12c1.8-4 5.3-6.5 9.5-6.5s7.7 2.5 9.5 6.5c-1.8 4-5.3 6.5-9.5 6.5S4.3 16 2.5 12z" stroke="#fff" strokeWidth="2" strokeLinejoin="round"/>
        <path d="M4 4l16 16" stroke="#fff" strokeWidth="2" strokeLinecap="round"/>
      </svg>
    </IcoTile>
  ),

  // Data
  Storage: (p = {}) => (
    <IcoTile {...p} from="#5aa9ff" to="#2166e0">
      <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
        <path d="M7 15a4 4 0 01-.4-7.97A6 6 0 0118 9.2 4 4 0 0117 15H7z" stroke="#fff" strokeWidth="2" strokeLinejoin="round"/>
      </svg>
    </IcoTile>
  ),
  Network: (p = {}) => (
    <IcoTile {...p} from="#ff8656" to="#e5531e">
      <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
        <path d="M5 17h2v4H5zM10 13h2v8h-2zM15 9h2v12h-2zM20 5v16" stroke="#fff" strokeWidth="2.2" strokeLinecap="round"/>
      </svg>
    </IcoTile>
  ),
  AutoDL: (p = {}) => (
    <IcoTile {...p} from="#2dd36f" to="#0b9247">
      <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
        <path d="M12 4v11M7 10l5 5 5-5M5 19h14" stroke="#fff" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round"/>
      </svg>
    </IcoTile>
  ),

  // Appearance
  Theme: (p = {}) => (
    <IcoTile {...p} from="#a995ff" to="#6b46ff">
      <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
        <path d="M12 3a9 9 0 100 18c5 0 9-4 9-9 0-2-1-2.5-2-2.5h-2.5c-1 0-1.8.8-1.8 1.8 0 .4.1.8.3 1.1.5.8.4 1.9-.5 2.3-.4.2-.9.2-1.5.2z" stroke="#fff" strokeWidth="2" strokeLinejoin="round"/>
        <circle cx="7.5" cy="12" r="1.2" fill="#fff"/>
        <circle cx="10" cy="7.5" r="1.2" fill="#fff"/>
        <circle cx="14.5" cy="7.2" r="1.2" fill="#fff"/>
      </svg>
    </IcoTile>
  ),
  Font: (p = {}) => (
    <IcoTile {...p} from="#ff8656" to="#e5531e">
      <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
        <path d="M5 19l4.5-12 4.5 12M7 15h5M14.5 19l3-8 3 8M15.5 16.5h4" stroke="#fff" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
      </svg>
    </IcoTile>
  ),
  Wallpaper: (p = {}) => (
    <IcoTile {...p} from="#3be3c9" to="#0e9b86">
      <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
        <rect x="3" y="4" width="18" height="16" rx="2.5" stroke="#fff" strokeWidth="2"/>
        <circle cx="9" cy="10" r="1.6" fill="#fff"/>
        <path d="M4 17l4-4 5 4 3-3 4 4" stroke="#fff" strokeWidth="2" strokeLinejoin="round"/>
      </svg>
    </IcoTile>
  ),

  // Notifications
  Bell: (p = {}) => (
    <IcoTile {...p} from="#ff8656" to="#e5531e">
      <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
        <path d="M18 9a6 6 0 10-12 0c0 6-2.5 8-2.5 8h17s-2.5-2-2.5-8M10 20a2 2 0 004 0" stroke="#fff" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
      </svg>
    </IcoTile>
  ),
  Calls: (p = {}) => (
    <IcoTile {...p} from="#7e8cff" to="#4258e0">
      <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
        <path d="M20 17v2a2 2 0 01-2 2 16 16 0 01-14-14 2 2 0 012-2h2a2 2 0 012 1.7c.1.9.3 1.7.6 2.5a2 2 0 01-.5 2.1L9 12a12 12 0 005 5l1.7-1.3a2 2 0 012.1-.5c.8.3 1.6.5 2.5.6A2 2 0 0120 17z" stroke="#fff" strokeWidth="2" strokeLinejoin="round"/>
      </svg>
    </IcoTile>
  ),

  // Help
  Help: (p = {}) => (
    <IcoTile {...p} from="#a1a6ad" to="#595e66">
      <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
        <circle cx="12" cy="12" r="9" stroke="#fff" strokeWidth="2"/>
        <path d="M9.5 9.5a2.5 2.5 0 115 .5c0 1.5-2.5 1.5-2.5 3.5M12 17v.01" stroke="#fff" strokeWidth="2" strokeLinecap="round"/>
      </svg>
    </IcoTile>
  ),
  About: (p = {}) => (
    <IcoTile {...p} from="#5aa9ff" to="#2166e0">
      <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
        <circle cx="12" cy="12" r="9" stroke="#fff" strokeWidth="2"/>
        <path d="M12 11v6M12 8v.01" stroke="#fff" strokeWidth="2" strokeLinecap="round"/>
      </svg>
    </IcoTile>
  ),

  Logout: (p = {}) => (
    <IcoTile {...p} from="#ff6b6b" to="#d12c2c">
      <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
        <path d="M14 4h3a2 2 0 012 2v12a2 2 0 01-2 2h-3M9 8l-4 4 4 4M5 12h11" stroke="#fff" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
      </svg>
    </IcoTile>
  ),
};

window.IC = IC;
