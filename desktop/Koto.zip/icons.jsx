/* global React */
// icons.jsx — Koto icon set (line icons, stroke 1.8, 24px)

const Ico = {
  Back: ({ size = 24, color = 'currentColor' }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none">
      <path d="M15 5l-7 7 7 7" stroke={color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
  ),
  Chevron: ({ size = 16, color = 'currentColor' }) => (
    <svg width={size} height={size} viewBox="0 0 16 16" fill="none">
      <path d="M6 3l5 5-5 5" stroke={color} strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
  ),
  Pencil: ({ size = 22, color = 'currentColor' }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none">
      <path d="M14.5 4.5l5 5M4 20l4-1 11.5-11.5a2.12 2.12 0 10-3-3L5 16l-1 4z" stroke={color} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
  ),
  Camera: ({ size = 22, color = 'currentColor' }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none">
      <path d="M3 8.5A1.5 1.5 0 014.5 7H7l1.5-2.2A1 1 0 019.33 4.3h5.34a1 1 0 01.83.5L17 7h2.5A1.5 1.5 0 0121 8.5V18a2 2 0 01-2 2H5a2 2 0 01-2-2V8.5z" stroke={color} strokeWidth="1.8" strokeLinejoin="round"/>
      <circle cx="12" cy="13" r="3.5" stroke={color} strokeWidth="1.8"/>
    </svg>
  ),
  Search: ({ size = 20, color = 'currentColor' }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none">
      <circle cx="11" cy="11" r="7" stroke={color} strokeWidth="1.8"/>
      <path d="M20 20l-3.5-3.5" stroke={color} strokeWidth="1.8" strokeLinecap="round"/>
    </svg>
  ),
  Phone: ({ size = 22, color = 'currentColor' }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none">
      <path d="M22 16.92v3a2 2 0 01-2.18 2 19.86 19.86 0 01-8.63-3.07 19.5 19.5 0 01-6-6A19.86 19.86 0 012.12 4.18 2 2 0 014.11 2h3a2 2 0 012 1.72c.127.96.361 1.903.7 2.81a2 2 0 01-.45 2.11L8.09 9.91a16 16 0 006 6l1.27-1.27a2 2 0 012.11-.45c.907.339 1.85.573 2.81.7A2 2 0 0122 16.92z" stroke={color} strokeWidth="1.8" strokeLinejoin="round"/>
    </svg>
  ),
  Video: ({ size = 22, color = 'currentColor' }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none">
      <path d="M23 7l-7 5 7 5V7z" stroke={color} strokeWidth="1.8" strokeLinejoin="round"/>
      <rect x="1" y="5" width="15" height="14" rx="2" stroke={color} strokeWidth="1.8"/>
    </svg>
  ),
  Plus: ({ size = 22, color = 'currentColor' }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none">
      <path d="M12 5v14M5 12h14" stroke={color} strokeWidth="2" strokeLinecap="round"/>
    </svg>
  ),
  Mic: ({ size = 22, color = 'currentColor' }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none">
      <rect x="9" y="3" width="6" height="12" rx="3" stroke={color} strokeWidth="1.8"/>
      <path d="M5 11a7 7 0 0014 0M12 18v3" stroke={color} strokeWidth="1.8" strokeLinecap="round"/>
    </svg>
  ),
  Send: ({ size = 20, color = 'currentColor' }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none">
      <path d="M12 19V5M6 11l6-6 6 6" stroke={color} strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
  ),
  Check: ({ size = 14, color = 'currentColor' }) => (
    <svg width={size} height={size} viewBox="0 0 14 14" fill="none">
      <path d="M2 7.5l3 3 7-7" stroke={color} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
  ),
  DoubleCheck: ({ size = 16, color = 'currentColor' }) => (
    <svg width={size} height={size} viewBox="0 0 16 16" fill="none">
      <path d="M1 8l3 3 6-6" stroke={color} strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round"/>
      <path d="M6 11l3-3M9 8l6-6" stroke={color} strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
  ),
  Clock: ({ size = 14, color = 'currentColor' }) => (
    <svg width={size} height={size} viewBox="0 0 14 14" fill="none">
      <circle cx="7" cy="7" r="5.5" stroke={color} strokeWidth="1.4"/>
      <path d="M7 4v3l2 1.5" stroke={color} strokeWidth="1.4" strokeLinecap="round"/>
    </svg>
  ),
  Lock: ({ size = 14, color = 'currentColor' }) => (
    <svg width={size} height={size} viewBox="0 0 14 14" fill="none">
      <rect x="2.5" y="6" width="9" height="6" rx="1.2" stroke={color} strokeWidth="1.3"/>
      <path d="M4.5 6V4.5a2.5 2.5 0 015 0V6" stroke={color} strokeWidth="1.3"/>
    </svg>
  ),
  Timer: ({ size = 18, color = 'currentColor' }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none">
      <circle cx="12" cy="13" r="8" stroke={color} strokeWidth="1.8"/>
      <path d="M12 9v4l2.5 2M9 2h6M12 5V2" stroke={color} strokeWidth="1.8" strokeLinecap="round"/>
    </svg>
  ),
  Bell: ({ size = 22, color = 'currentColor' }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none">
      <path d="M18 8a6 6 0 10-12 0c0 7-3 9-3 9h18s-3-2-3-9M10 21a2 2 0 004 0" stroke={color} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
  ),
  Shield: ({ size = 22, color = 'currentColor' }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none">
      <path d="M12 2l8 3v7c0 5-4 9-8 10-4-1-8-5-8-10V5l8-3z" stroke={color} strokeWidth="1.8" strokeLinejoin="round"/>
      <path d="M8 12l3 3 5-5" stroke={color} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
  ),
  User: ({ size = 22, color = 'currentColor' }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none">
      <circle cx="12" cy="8" r="4" stroke={color} strokeWidth="1.8"/>
      <path d="M4 21c1.5-4 4.5-6 8-6s6.5 2 8 6" stroke={color} strokeWidth="1.8" strokeLinecap="round"/>
    </svg>
  ),
  Database: ({ size = 22, color = 'currentColor' }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none">
      <ellipse cx="12" cy="5" rx="8" ry="2.5" stroke={color} strokeWidth="1.8"/>
      <path d="M4 5v6c0 1.4 3.6 2.5 8 2.5s8-1.1 8-2.5V5M4 11v6c0 1.4 3.6 2.5 8 2.5s8-1.1 8-2.5v-6" stroke={color} strokeWidth="1.8"/>
    </svg>
  ),
  Palette: ({ size = 22, color = 'currentColor' }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none">
      <path d="M12 22a10 10 0 110-20c5 0 10 4 10 9 0 2.5-2 4-4.5 4H15c-1 0-1.8.8-1.8 1.8 0 .4.2.8.4 1.1.6.8.4 1.9-.5 2.3-.4.2-.7.2-1.1.2z" stroke={color} strokeWidth="1.8" strokeLinejoin="round"/>
      <circle cx="6.5" cy="12" r="1.3" fill={color}/>
      <circle cx="9.5" cy="7.5" r="1.3" fill={color}/>
      <circle cx="15" cy="7" r="1.3" fill={color}/>
      <circle cx="18" cy="11" r="1.3" fill={color}/>
    </svg>
  ),
  Link: ({ size = 22, color = 'currentColor' }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none">
      <path d="M10 14a5 5 0 007 0l3-3a5 5 0 10-7-7l-1 1M14 10a5 5 0 00-7 0l-3 3a5 5 0 107 7l1-1" stroke={color} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
  ),
  Sticker: ({ size = 22, color = 'currentColor' }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none">
      <path d="M14 3H6a3 3 0 00-3 3v12a3 3 0 003 3h8l7-7V6a3 3 0 00-3-3h-4" stroke={color} strokeWidth="1.8" strokeLinejoin="round"/>
      <path d="M14 21v-4a3 3 0 013-3h4" stroke={color} strokeWidth="1.8" strokeLinejoin="round"/>
    </svg>
  ),
  Gif: ({ size = 22, color = 'currentColor' }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none">
      <rect x="2" y="5" width="20" height="14" rx="3" stroke={color} strokeWidth="1.8"/>
      <text x="12" y="15.5" textAnchor="middle" fontSize="7" fontWeight="700" fill={color} fontFamily="-apple-system">GIF</text>
    </svg>
  ),
  Image: ({ size = 22, color = 'currentColor' }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none">
      <rect x="3" y="4" width="18" height="16" rx="2" stroke={color} strokeWidth="1.8"/>
      <circle cx="9" cy="10" r="1.6" stroke={color} strokeWidth="1.6"/>
      <path d="M4 17l4-4 5 4 3-3 4 4" stroke={color} strokeWidth="1.6" strokeLinejoin="round"/>
    </svg>
  ),
  File: ({ size = 22, color = 'currentColor' }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none">
      <path d="M14 3H7a2 2 0 00-2 2v14a2 2 0 002 2h10a2 2 0 002-2V8l-5-5z" stroke={color} strokeWidth="1.8" strokeLinejoin="round"/>
      <path d="M14 3v5h5" stroke={color} strokeWidth="1.8" strokeLinejoin="round"/>
    </svg>
  ),
  Contact: ({ size = 22, color = 'currentColor' }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none">
      <rect x="3" y="4" width="18" height="16" rx="3" stroke={color} strokeWidth="1.8"/>
      <circle cx="12" cy="11" r="3" stroke={color} strokeWidth="1.8"/>
      <path d="M7 17c1-2 3-3 5-3s4 1 5 3" stroke={color} strokeWidth="1.8" strokeLinecap="round"/>
    </svg>
  ),
  Location: ({ size = 22, color = 'currentColor' }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none">
      <path d="M12 22s7-6 7-12a7 7 0 10-14 0c0 6 7 12 7 12z" stroke={color} strokeWidth="1.8" strokeLinejoin="round"/>
      <circle cx="12" cy="10" r="2.5" stroke={color} strokeWidth="1.8"/>
    </svg>
  ),
  Face: ({ size = 20, color = 'currentColor' }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none">
      <circle cx="12" cy="12" r="9.5" stroke={color} strokeWidth="1.6"/>
      <circle cx="9" cy="10" r="0.9" fill={color}/>
      <circle cx="15" cy="10" r="0.9" fill={color}/>
      <path d="M8.5 14.5c1 1.2 2.2 1.8 3.5 1.8s2.5-.6 3.5-1.8" stroke={color} strokeWidth="1.6" strokeLinecap="round"/>
    </svg>
  ),
  Qr: ({ size = 22, color = 'currentColor' }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none">
      <rect x="3" y="3" width="7" height="7" stroke={color} strokeWidth="1.8"/>
      <rect x="14" y="3" width="7" height="7" stroke={color} strokeWidth="1.8"/>
      <rect x="3" y="14" width="7" height="7" stroke={color} strokeWidth="1.8"/>
      <rect x="6" y="6" width="1" height="1" fill={color}/>
      <rect x="17" y="6" width="1" height="1" fill={color}/>
      <rect x="6" y="17" width="1" height="1" fill={color}/>
      <path d="M14 14h3v3h-3zM20 14v3M14 20h3M17 17v4h4" stroke={color} strokeWidth="1.8"/>
    </svg>
  ),
  Mute: ({ size = 16, color = 'currentColor' }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none">
      <path d="M18 8a6 6 0 10-12 0c0 7-3 9-3 9h18s-3-2-3-9M10 21a2 2 0 004 0M4 4l16 16" stroke={color} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
  ),
  Pin: ({ size = 14, color = 'currentColor' }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none">
      <path d="M12 2l3 6 6 1-4.5 4.5L18 20l-6-3-6 3 1.5-6.5L3 9l6-1 3-6z" fill={color}/>
    </svg>
  ),
  FaceId: ({ size = 44, color = 'currentColor' }) => (
    <svg width={size} height={size} viewBox="0 0 44 44" fill="none">
      <path d="M6 14V8a2 2 0 012-2h6M38 14V8a2 2 0 00-2-2h-6M6 30v6a2 2 0 002 2h6M38 30v6a2 2 0 01-2 2h-6" stroke={color} strokeWidth="2" strokeLinecap="round"/>
      <path d="M16 18v3M28 18v3M22 18v6l-2 1.5M16 28c2 1.5 4 2 6 2s4-.5 6-2" stroke={color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
  ),
  ArrowUpRight: ({ size = 14, color = 'currentColor' }) => (
    <svg width={size} height={size} viewBox="0 0 14 14" fill="none">
      <path d="M4 10l6-6M5 4h5v5" stroke={color} strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
  ),
  Archive: ({ size = 22, color = 'currentColor' }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none">
      <rect x="3" y="4" width="18" height="4" rx="1" stroke={color} strokeWidth="1.8"/>
      <path d="M5 8v10a2 2 0 002 2h10a2 2 0 002-2V8M10 12h4" stroke={color} strokeWidth="1.8" strokeLinecap="round"/>
    </svg>
  ),
  CheckEnvelope: ({ size = 22, color = 'currentColor' }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none">
      <path d="M4 7l8 5 8-5" stroke={color} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"/>
      <rect x="3" y="5" width="18" height="14" rx="2" stroke={color} strokeWidth="1.8"/>
    </svg>
  ),
  Unarchive: ({ size = 22, color = 'currentColor' }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none">
      <rect x="3" y="4" width="18" height="4" rx="1" stroke={color} strokeWidth="1.8"/>
      <path d="M5 8v10a2 2 0 002 2h10a2 2 0 002-2V8" stroke={color} strokeWidth="1.8" strokeLinecap="round"/>
      <path d="M12 18V12M9 15l3-3 3 3" stroke={color} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
  ),
  CheckCircle: ({ size = 22, color = 'currentColor' }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none">
      <circle cx="12" cy="12" r="9" stroke={color} strokeWidth="1.8"/>
      <path d="M8 12.5l2.5 2.5L16 9.5" stroke={color} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
  ),
  DotCircle: ({ size = 22, color = 'currentColor' }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none">
      <circle cx="12" cy="12" r="9" stroke={color} strokeWidth="1.8"/>
      <circle cx="12" cy="12" r="3" fill={color}/>
    </svg>
  ),
  Trash: ({ size = 22, color = 'currentColor' }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none">
      <path d="M5 7h14M10 7V5a1 1 0 011-1h2a1 1 0 011 1v2M7 7l1 12a2 2 0 002 2h4a2 2 0 002-2l1-12" stroke={color} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
  ),
  ChevronRight: ({ size = 16, color = 'currentColor' }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none">
      <path d="M9 6l6 6-6 6" stroke={color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
  ),
  Globe: ({ size = 22, color = 'currentColor' }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none">
      <circle cx="12" cy="12" r="9" stroke={color} strokeWidth="1.8"/>
      <path d="M3 12h18M12 3a14 14 0 010 18M12 3a14 14 0 000 18" stroke={color} strokeWidth="1.8"/>
    </svg>
  ),
  Close: ({ size = 18, color = 'currentColor' }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none">
      <circle cx="12" cy="12" r="10" fill={color} opacity="0.15"/>
      <path d="M8 8l8 8M16 8l-8 8" stroke={color} strokeWidth="1.8" strokeLinecap="round"/>
    </svg>
  ),
  Copy: ({ size = 18, color = 'currentColor' }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none">
      <rect x="8" y="8" width="12" height="13" rx="2.2" stroke={color} strokeWidth="1.7"/>
      <path d="M16 8V5.5A1.5 1.5 0 0014.5 4H5.5A1.5 1.5 0 004 5.5v11A1.5 1.5 0 005.5 18H8" stroke={color} strokeWidth="1.7" strokeLinecap="round"/>
    </svg>
  ),
  Alert: ({ size = 20, color = 'currentColor' }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none">
      <path d="M12 3.5L22 20H2L12 3.5z" stroke={color} strokeWidth="1.7" strokeLinejoin="round"/>
      <path d="M12 10v5" stroke={color} strokeWidth="1.7" strokeLinecap="round"/>
      <circle cx="12" cy="17.5" r="1" fill={color}/>
    </svg>
  ),
};

window.Ico = Ico;
