/* global React, ReactDOM, KotoFrame, ChatListScreen, ArchiveScreen, ConversationScreen, SettingsScreen, NewChatScreen, ContactProfileScreen, CallScreen, StoriesScreen, SafetyScreen, ScreenLockScreen, BotCatalogScreen, BotForgeScreen, EphemeralSheet, AttachSheet, MediaPickerScreen, WelcomeScreen, RegisterScreen, LoginScreen, Ico, useTweaks, TweaksPanel, TweakSection, TweakSlider, TweakToggle, TweakColor, DevicesScreen, UsernameScreen, PrivacyScreen, EphemeralSettings, ScreenLockSettings, SealedScreen, StorageScreen, NetworkScreen, AutoDLScreen, ThemeScreen, FontScreen, WallpaperScreen, HelpScreen, AboutScreen, KotoIdScreen, SeedScreen, NotificationsScreen, CallsScreen, ProfileEditScreen, PlaceholderSub */
// app.jsx — Koto root / router

const { useState: useStateA, useEffect: useEffectA } = React;

const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "accent": "#ff6b35",
  "dark": false,
  "density": 72,
  "startAt": "welcome"
}/*EDITMODE-END*/;

function App() {
  const [t, setTweak] = useTweaks(TWEAK_DEFAULTS);
  const { accent, dark, density, startAt } = t;

  useEffectA(() => {
    document.documentElement.style.setProperty('--accent', accent);
    document.documentElement.style.setProperty('--frame-bg', dark ? '#0b0b0c' : '#ffffff');
    document.body.classList.toggle('dark-host', dark);
  }, [accent, dark]);

  const [profile, setProfile] = useStateA(null); // {name, kotoId}

  const initial = () => {
    if (startAt === 'list') { return [{ kind:'list' }]; }
    if (startAt === 'lock') { return [{ kind:'lock' }]; }
    return [{ kind:'welcome' }];
  };
  const [stack, setStack] = useStateA(initial);
  const [anim, setAnim] = useStateA({ dir: 'none' });

  // If startAt is 'list' but no profile — auto-fake one
  useEffectA(() => {
    if (startAt === 'list' && !profile) {
      setProfile({ name: 'Дмитрий К.', kotoId: '05a9f2c4e7b1d038f5c26e9a48103b5d7c91e2d64a58fc03bd917e4a62c85b71f0' });
    }
  }, []);

  const push = (screen) => { setAnim({ dir:'push' }); setStack(s => [...s, screen]); };
  const pop = () => { if (stack.length<=1) return; setAnim({ dir:'pop' }); setStack(s => s.slice(0,-1)); };
  const resetTo = (screen) => { setAnim({ dir:'none' }); setStack([screen]); };

  const [sheet, setSheet] = useStateA(null);
  const [ephemeralOn, setEphemeralOn] = useStateA(false);

  // chat-row states (shared with archive)
  const [archived, setArchived] = useStateA({});
  const [mutedMap, setMutedMap] = useStateA({});
  const [pinnedMap, setPinnedMap] = useStateA({});
  const [readOverrides, setReadOverrides] = useStateA({});

  const current = stack[stack.length-1];

  const renderScreen = (s) => {
    switch (s.kind) {
      case 'welcome':
        return <WelcomeScreen dark={dark}
          onCreate={() => push({ kind:'register' })}
          onRestore={() => push({ kind:'login' })}
        />;
      case 'register':
        return <RegisterScreen dark={dark} onBack={pop}
          onDone={(p) => { setProfile(p); resetTo({ kind:'lock' }); }}
        />;
      case 'login':
        return <LoginScreen dark={dark} onBack={pop}
          onDone={(p) => { setProfile(p); resetTo({ kind:'lock' }); }}
        />;
      case 'lock':
        return <ScreenLockScreen dark={dark} onUnlock={() => resetTo({ kind:'list' })}/>;
      case 'list':
        return <ChatListScreen
          dark={dark} density={density}
          onOpenChat={(id) => push({ kind:'chat', id })}
          onOpenSettings={() => push({ kind:'settings' })}
          onOpenNewChat={() => push({ kind:'newchat' })}
          onOpenStories={() => push({ kind:'stories' })}
          onOpenCamera={() => push({ kind:'media' })}
          onOpenBots={() => push({ kind:'bots' })}
          onOpenArchive={() => push({ kind:'archive' })}
          archived={archived} setArchived={setArchived}
          muted={mutedMap} setMuted={setMutedMap}
          pinned={pinnedMap} setPinned={setPinnedMap}
          readOverrides={readOverrides} setReadOverrides={setReadOverrides}
        />;
      case 'archive':
        return <ArchiveScreen
          dark={dark} density={density}
          onBack={pop}
          onOpenChat={(id) => push({ kind:'chat', id })}
          archived={archived} setArchived={setArchived}
          muted={mutedMap} setMuted={setMutedMap}
          pinnedMap={pinnedMap} setPinnedMap={setPinnedMap}
          readOverrides={readOverrides} setReadOverrides={setReadOverrides}
        />;
      case 'chat':
        return <ConversationScreen
          chatId={s.id} dark={dark} ephemeralOn={ephemeralOn}
          onBack={pop}
          onOpenContact={() => push({ kind:'contact', id: s.id })}
          onOpenCall={() => push({ kind:'call', id: s.id, video:false })}
          onOpenVideo={() => push({ kind:'call', id: s.id, video:true })}
          onOpenEphemeral={() => setSheet('ephemeral')}
          onOpenAttach={() => setSheet('attach')}
        />;
      case 'settings':
        return <SettingsScreen
          dark={dark} onBack={pop} profile={profile}
          onToggleTheme={() => setTweak('dark', !dark)}
          onOpenSection={(k) => push({ kind:'settings-sub', section:k })}
          onLogout={() => { setProfile(null); resetTo({ kind:'welcome' }); }}
        />;
      case 'settings-sub': {
        const common = { dark, onBack:pop };
        switch (s.section) {
          case 'kotoid':     return <KotoIdScreen    {...common} profile={profile}/>;
          case 'seed':       return <SeedScreen      {...common}/>;
          case 'devices':    return <DevicesScreen   {...common}/>;
          case 'username':   return <UsernameScreen  {...common}/>;
          case 'privacy':    return <PrivacyScreen   {...common}/>;
          case 'ephemeral':  return <EphemeralSettings {...common}/>;
          case 'screenlock': return <ScreenLockSettings {...common}/>;
          case 'safety':     return <SafetyScreen contactId={'alina'} {...common}/>;
          case 'sealed':     return <SealedScreen    {...common}/>;
          case 'storage':    return <StorageScreen   {...common}/>;
          case 'network':    return <NetworkScreen   {...common}/>;
          case 'auto':       return <AutoDLScreen    {...common}/>;
          case 'font':       return <FontScreen      {...common}/>;
          case 'wallpaper':  return <WallpaperScreen {...common}/>;
          case 'help':       return <HelpScreen      {...common}/>;
          case 'about':      return <AboutScreen     {...common}/>;
          case 'theme':      return <ThemeScreen     {...common} accent={accent} onAccent={(v)=>setTweak('accent',v)} onToggleTheme={()=>setTweak('dark', !dark)}/>;
          case 'notifications': return <NotificationsScreen {...common}/>;
          case 'calls':      return <CallsScreen     {...common}/>;
          case 'profile':    return <ProfileEditScreen {...common} profile={profile}/>;
          default: return <PlaceholderSub title="Настройки" {...common}/>;
        }
      }
      case 'newchat':
        return <NewChatScreen dark={dark} onBack={pop} onOpenChat={(id)=>{ resetTo({kind:'list'}); setTimeout(()=>push({ kind:'chat', id }), 80); }}/>;
      case 'contact':
        return <ContactProfileScreen contactId={s.id} dark={dark} onBack={pop}
          onSafety={() => push({ kind:'safety', id: s.id })}
          onEphemeral={() => setSheet('ephemeral')}
        />;
      case 'call':
        return <CallScreen contactId={s.id} video={s.video} dark={dark} onEnd={pop}/>;
      case 'stories':
        return <StoriesScreen dark={dark} onBack={pop}/>;
      case 'safety':
        return <SafetyScreen contactId={s.id} dark={dark} onBack={pop}/>;
      case 'media':
        return <MediaPickerScreen dark={dark} onBack={pop} onSend={pop}/>;
      case 'bots':
        return <BotCatalogScreen dark={dark} onBack={pop}
          onOpenBot={(id)=>push({ kind:'chat', id })}
          onOpenForge={()=>push({ kind:'forge' })}
        />;
      case 'forge':
        return <BotForgeScreen dark={dark} onBack={pop}
          onCreated={()=>{ resetTo({kind:'list'}); setTimeout(()=>push({kind:'chat', id:'pawket'}), 80); }}
        />;
      default: return null;
    }
  };

  return (
    <div style={{ position:'relative', display:'flex', alignItems:'center', justifyContent:'center', width:'100vw', height:'100vh' }}>
      <KotoFrame dark={dark}>
        <div key={stack.length+'-'+current.kind+'-'+(current.id||'')} style={{
          position:'absolute', inset:0,
          animation: anim.dir==='push'
            ? 'slideInRight 300ms cubic-bezier(.2,.8,.2,1)'
            : anim.dir==='pop' ? 'slideInLeft 260ms cubic-bezier(.2,.8,.2,1)' : 'none',
        }}>
          {renderScreen(current)}
        </div>

        {sheet==='attach' && (
          <AttachSheet dark={dark} onClose={()=>setSheet(null)} onMedia={()=>{ setSheet(null); push({ kind:'media' }); }}/>
        )}
        {sheet==='ephemeral' && (
          <EphemeralSheet dark={dark} current={ephemeralOn?3600:0}
            onPick={(v)=>{ setEphemeralOn(v>0); setSheet(null); }}
            onClose={()=>setSheet(null)}/>
        )}
      </KotoFrame>

      <div style={{
        position:'fixed', bottom:12, left:0, right:0, textAlign:'center',
        fontSize:11, color: dark?'#5e5e62':'#9e9e9e', fontFamily:'-apple-system',
        letterSpacing:0.5, pointerEvents:'none',
      }}>
        koto · без телефона · только ваша фраза · откройте Tweaks для темы и старта
      </div>

      <TweaksPanel>
        <TweakSection label="Тема"/>
        <TweakToggle label="Тёмная тема" value={dark} onChange={(v)=>setTweak('dark', v)}/>
        <TweakColor label="Акцент" value={accent} onChange={(v)=>setTweak('accent', v)}/>
        <TweakSection label="Список чатов"/>
        <TweakSlider label="Плотность" value={density} min={60} max={88} step={2} unit="px" onChange={(v)=>setTweak('density', v)}/>
        <TweakSection label="Стартовый экран"/>
        <TweakToggle label="Показать welcome → register → login" value={startAt==='welcome'} onChange={(v)=>setTweak('startAt', v?'welcome':'list')}/>
      </TweaksPanel>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<App/>);
